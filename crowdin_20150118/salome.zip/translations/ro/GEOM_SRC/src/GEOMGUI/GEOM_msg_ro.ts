<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ro" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>BRep_API: command not done</source>
      <translation>Eroare: nu se poate construi obiectul</translation>
    </message>
    <message>
      <source>PAL_NOT_DONE_ERROR</source>
      <translation>Operaţie abandonată</translation>
    </message>
    <message>
      <source>CHANGE_ORIENTATION_NEW_OBJ_NAME</source>
      <translation>Întoarce</translation>
    </message>
    <message>
      <source>EDGE_WIDTH_TLT</source>
      <translation>Select Edge Width</translation>
    </message>
    <message>
      <source>ISOS_WIDTH_TLT</source>
      <translation>Selectaţi lăţimea ISO-ului</translation>
    </message>
    <message>
      <source>CLOSE_CONTOUR_NEW_OBJ_NAME</source>
      <translation>Contur închis</translation>
    </message>
    <message>
      <source>DEP_OBJECT</source>
      <translation>Unul sau mai multe obiecte selectate sunt folosite pentru a crea altele sau fac referire la alte module. Eliminarea acestor obiecte poate duce la arhivarea python incorectă. Încă doriţi să ştergeţi aceste obiecte?</translation>
    </message>
    <message>
      <source>DEVIDE_EDGE_NEW_OBJECT_NAME</source>
      <translation>Obiect nou</translation>
    </message>
    <message>
      <source>ERROR_SHAPE_TYPE</source>
      <translation>Selecţie a unui obiect de alt tip! Vă rugăm să selectaţi faţa, membrana sau solidul şi încercaţi din nou</translation>
    </message>
    <message>
      <source> iErr : 10</source>
      <translation>Clasificatorul este nul</translation>
    </message>
    <message>
      <source> iErr : 11</source>
      <translation>Forma este nulă</translation>
    </message>
    <message>
      <source> iErr : 12</source>
      <translation>Tip de sub-formă nepermis</translation>
    </message>
    <message>
      <source> iErr : 13</source>
      <translation>Stare nepermisă</translation>
    </message>
    <message>
      <source> iErr : 15</source>
      <translation>Tip de suprafaţă nepermis</translation>
    </message>
    <message>
      <source> iErr : 20</source>
      <translation>Triangulatia nu este găsită</translation>
    </message>
    <message>
      <source> iErr : 30</source>
      <translation>Nu pot obţine linia de la legătură</translation>
    </message>
    <message>
      <source> iErr : 40</source>
      <translation>Un punct nu poate fi clasificat</translation>
    </message>
    <message>
      <source> iErr : 41</source>
      <translation>Invalid Data for Classifier</translation>
    </message>
    <message>
      <source>GEOM_2D_CONTINUTY</source>
      <translation>continuitate 2D</translation>
    </message>
    <message>
      <source>GEOM_2D_CURVE_MODE</source>
      <translation>Modul 2D curbă</translation>
    </message>
    <message>
      <source>GEOM_2D_TOLERANCE</source>
      <translation>2D tolerance</translation>
    </message>
    <message>
      <source>GEOM_3D_CONTINUTY</source>
      <translation>continuitate 3D</translation>
    </message>
    <message>
      <source>GEOM_3D_CURVE_MODE</source>
      <translation>Modul de curbe 3D </translation>
    </message>
    <message>
      <source>GEOM_3D_TOLERANCE</source>
      <translation>Toleranţă 3D</translation>
    </message>
    <message>
      <source>GEOM_3_POINTS</source>
      <translation>3 points</translation>
    </message>
    <message>
      <source>GEOM_ADD_POINT</source>
      <translation>Adaugă punct</translation>
    </message>
    <message>
      <source>GEOM_ANGLE</source>
      <translation>Unghi :</translation>
    </message>
    <message>
      <source>GEOM_ANGLES</source>
      <translation>Angles</translation>
    </message>
    <message>
      <source>GEOM_ANGLE_2</source>
      <translation>Angle 2 :</translation>
    </message>
    <message>
      <source>GEOM_ANGLE_1</source>
      <translation>Angle</translation>
    </message>
    <message>
      <source>GEOM_ANGLE_STEP</source>
      <translation>Pas unghiular:</translation>
    </message>
    <message>
      <source>GEOM_ARC_ELLIPSE</source>
      <translation>Arc of ellipse</translation>
    </message>
    <message>
      <source>GEOM_ARC</source>
      <translation>Arc</translation>
    </message>
    <message>
      <source>GEOM_ARCHIMEDE</source>
      <translation>Ahimede</translation>
    </message>
    <message>
      <source>GEOM_ARCHIMEDE_TITLE</source>
      <translation>Construcţie arhimede</translation>
    </message>
    <message>
      <source>GEOM_ARC_TITLE</source>
      <translation>Construcţia arcului</translation>
    </message>
    <message>
      <source>GEOM_ARGUMENTS</source>
      <translation>Argumente</translation>
    </message>
    <message>
      <source>GEOM_AXE_MIRROR</source>
      <translation>Axis Mirror</translation>
    </message>
    <message>
      <source>GEOM_AXIS</source>
      <translation>Axis</translation>
    </message>
    <message>
      <source>GEOM_BASE</source>
      <translation>Bază</translation>
    </message>
    <message>
      <source>GEOM_BASE_OBJECT</source>
      <translation>Obiectul de bază</translation>
    </message>
    <message>
      <source>GEOM_BASE_POINT</source>
      <translation>Base Point</translation>
    </message>
    <message>
      <source>GEOM_BEZIER</source>
      <translation>Bezier</translation>
    </message>
    <message>
      <source>GEOM_BINORMAL</source>
      <translation>BiNormal</translation>
    </message>
    <message>
      <source>GEOM_BLOCK</source>
      <translation>Solid hexagonal</translation>
    </message>
    <message>
      <source>GEOM_BLOCKS_COMPOUND</source>
      <translation>Bloc compus</translation>
    </message>
    <message>
      <source>GEOM_BLOCK_EXPLODE</source>
      <translation>Bloc secundar</translation>
    </message>
    <message>
      <source>GEOM_BLOCK_EXPLODE_TITLE</source>
      <translation>Selecţie sub-bloc</translation>
    </message>
    <message>
      <source>GEOM_BLOCK_MULTITRSF</source>
      <translation>Multi-transformare bloc</translation>
    </message>
    <message>
      <source>GEOM_BLOCK_MULTITRSF_DOUBLE</source>
      <translation>Multi-transformare dublă</translation>
    </message>
    <message>
      <source>GEOM_BLOCK_MULTITRSF_SIMPLE</source>
      <translation>Multi-transformare simplă</translation>
    </message>
    <message>
      <source>GEOM_BLOCK_MULTITRSF_TITLE</source>
      <translation>Multi-transformare în bloc</translation>
    </message>
    <message>
      <source>GEOM_BLOCK_TITLE</source>
      <translation>Construcţie solid hexagonal</translation>
    </message>
    <message>
      <source>GEOM_BNDBOX</source>
      <translation>Cutie de încadrare</translation>
    </message>
    <message>
      <source>GEOM_BNDBOX_OBJDIM</source>
      <translation>Object And Its Dimensions</translation>
    </message>
    <message>
      <source>GEOM_BNDBOX_TITLE</source>
      <translation>Informaţii despre cutia de încadrare</translation>
    </message>
    <message>
      <source>GEOM_BOX</source>
      <translation>Box</translation>
    </message>
    <message>
      <source>GEOM_BOX_OBJ</source>
      <translation>Dimensiunile la origine</translation>
    </message>
    <message>
      <source>GEOM_BOX_TITLE</source>
      <translation>Construcţie cutie</translation>
    </message>
    <message>
      <source>GEOM_BSplineRestriction</source>
      <translation>Restricţie BSpline</translation>
    </message>
    <message>
      <source>GEOM_BUT_APPLY</source>
      <translation>&amp;Aplică</translation>
    </message>
    <message>
      <source>GEOM_BUT_CANCEL</source>
      <translation>&amp;Revocare</translation>
    </message>
    <message>
      <source>GEOM_BUT_CLOSE</source>
      <translation>&amp;Închide</translation>
    </message>
    <message>
      <source>GEOM_BUT_CLOSE_SKETCH</source>
      <translation>Schiţa de închidere</translation>
    </message>
    <message>
      <source>GEOM_BUT_END_SKETCH</source>
      <translation>Schiţa de validare</translation>
    </message>
    <message>
      <source>GEOM_BUT_EXPLODE</source>
      <translation>&amp;Explodează</translation>
    </message>
    <message>
      <source>GEOM_BUT_HELP</source>
      <translation>&amp;Ajutor</translation>
    </message>
    <message>
      <source>GEOM_BUT_NO</source>
      <translation>&amp;Nu</translation>
    </message>
    <message>
      <source>GEOM_BUT_OK</source>
      <translation>&amp;Ok</translation>
    </message>
    <message>
      <source>GEOM_BUT_APPLY_AND_CLOSE</source>
      <translation>A&amp;plică şi închide</translation>
    </message>
    <message>
      <source>GEOM_BUT_YES</source>
      <translation>&amp;Da</translation>
    </message>
    <message>
      <source>GEOM_BY_LENGTH</source>
      <translation>După lungime</translation>
    </message>
    <message>
      <source>GEOM_BY_PARAMETER</source>
      <translation>După parametru</translation>
    </message>
    <message>
      <source>GEOM_CENTER</source>
      <translation>Centru</translation>
    </message>
    <message>
      <source>GEOM_CENTER_DEFAULT</source>
      <translation>(Originea implicită)</translation>
    </message>
    <message>
      <source>GEOM_CENTER_POINT</source>
      <translation>Center Point</translation>
    </message>
    <message>
      <source>GEOM_CENTRAL_POINT</source>
      <translation>Central Point</translation>
    </message>
    <message>
      <source>GEOM_CHAMFER</source>
      <translation>Şanfren</translation>
    </message>
    <message>
      <source>GEOM_CHAMFER_ABORT</source>
      <translation>Şanfrenul nu poate fi calculat cu %1 şi %2</translation>
    </message>
    <message>
      <source>GEOM_CHAMFER_ALL</source>
      <translation>Şanfren de pe întreaga formă</translation>
    </message>
    <message>
      <source>GEOM_CHAMFER_EDGES</source>
      <translation>Şanfren pe marginile selectate</translation>
    </message>
    <message>
      <source>GEOM_CHAMFER_FACES</source>
      <translation>Şanfren pe feţele selectate</translation>
    </message>
    <message>
      <source>GEOM_CHAMFER_TITLE</source>
      <translation>Construire şanfren</translation>
    </message>
    <message>
      <source>GEOM_CHANGE_ORIENTATION</source>
      <translation>Obiecte la care se va schimba orientarea</translation>
    </message>
    <message>
      <source>GEOM_CHANGE_DIRECTION</source>
      <translation>Change direction</translation>
    </message>
    <message>
      <source>GEOM_CHANGE_ORIENTATION_TITLE</source>
      <translation>Change orientation</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_COMPOUND</source>
      <translation>Verifică şi schimbă blocul compus</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_COMPOUND_FAILED</source>
      <translation>Verificare eşuată</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_COMPOUND_ERRORS</source>
      <translation>Errors</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_COMPOUND_HAS_ERRORS</source>
      <translation>Blocul compus are erori</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_COMPOUND_HAS_NO_ERRORS</source>
      <translation>Componentele blocului nu are erori</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_COMPOUND_SUBSHAPES</source>
      <translation>Forme secundare incriminate</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_NOT_BLOCK</source>
      <translation>Not a Block</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_EXTRA_EDGE</source>
      <translation>Extra Edge</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_INVALID_CONNECTION</source>
      <translation>Invalid Connection # %1</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_NOT_CONNECTED</source>
      <translation>Not Connected</translation>
    </message>
    <message>
      <source>GEOM_CHECK_BLOCKS_NOT_GLUED</source>
      <translation>Nu este lipit # %1</translation>
    </message>
    <message>
      <source>GEOM_GETNONBLOCKS_TITLE</source>
      <translation>Get non-hexahedral solids and non-quadrangular faces</translation>
    </message>
    <message>
      <source>GEOM_GETNONBLOCKS</source>
      <translation>Get non blocks</translation>
    </message>
    <message>
      <source>GEOM_NONBLOCKS</source>
      <translation>NonBlocksGroup</translation>
    </message>
    <message>
      <source>GEOM_CHECK_INFOS</source>
      <translation>Object And Its Topological Information</translation>
    </message>
    <message>
      <source>GEOM_CHECK_SELF_INTERSECTIONS</source>
      <translation>Detect Self-intersections</translation>
    </message>
    <message>
      <source>GEOM_CHECK_SELF_INTERSECTIONS_FAILED</source>
      <translation>Detection of self-intersections failed</translation>
    </message>
    <message>
      <source>GEOM_NO_SELF_INTERSECTIONS</source>
      <translation>There are no self-intersections in the shape</translation>
    </message>
    <message>
      <source>GEOM_SELF_INTERSECTIONS_FOUND</source>
      <translation>Some self-intersections detected</translation>
    </message>
    <message>
      <source>GEOM_CHECK_SELF_INTERSECTIONS_ERRORS</source>
      <translation>Warning: there were errors during the operation, so the list may be incomplete.</translation>
    </message>
    <message>
      <source>GEOM_CIRCLE</source>
      <translation>Circle</translation>
    </message>
    <message>
      <source>GEOM_CIRCLE_TITLE</source>
      <translation>Construire cerc </translation>
    </message>
    <message>
      <source>GEOM_CLOSECONTOUR_TITLE</source>
      <translation>Închide contur</translation>
    </message>
    <message>
      <source>GEOM_CMASS</source>
      <translation>Center Of Mass</translation>
    </message>
    <message>
      <source>GEOM_CMASS_TITLE</source>
      <translation>Construirea centrului de masă</translation>
    </message>
    <message>
      <source>GEOM_COMMON</source>
      <translation>Common</translation>
    </message>
    <message>
      <source>GEOM_COMMON_TITLE</source>
      <translation>Comun obiectelor</translation>
    </message>
    <message>
      <source>GEOM_COMPOUND</source>
      <translation>Compound</translation>
    </message>
    <message>
      <source>GEOM_COMPOUNDSOLID</source>
      <translation>Solid compus</translation>
    </message>
    <message>
      <source>GEOM_COMPOUND_TITLE</source>
      <translation>Crearea unui compus</translation>
    </message>
    <message>
      <source>GEOM_CONE</source>
      <translation>Cone</translation>
    </message>
    <message>
      <source>GEOM_CONE_TITLE</source>
      <translation>Construire con</translation>
    </message>
    <message>
      <source>GEOM_CONFIRM</source>
      <translation>Confirmă operaţiunea</translation>
    </message>
    <message>
      <source>GEOM_CONFIRM_INFO</source>
      <translation>Forma conţine %1 forme secundare!</translation>
    </message>
    <message>
      <source>GEOM_COOR</source>
      <translation>Coord. :</translation>
    </message>
    <message>
      <source>GEOM_COORDINATES</source>
      <translation>Coordinate</translation>
    </message>
    <message>
      <source>GEOM_COORDINATES_RES</source>
      <translation>Rezultatul coordonatelor</translation>
    </message>
    <message>
      <source>GEOM_CREATE_COPY</source>
      <translation>Creare copie</translation>
    </message>
    <message>
      <source>GEOM_CREATE_SINGLE_SOLID</source>
      <translation>Creeaţi un singur solid </translation>
    </message>
    <message>
      <source>GEOM_CURVE</source>
      <translation>Curbă</translation>
    </message>
    <message>
      <source>GEOM_CURVE_CONTINUTY</source>
      <translation>Curbă de continuitate</translation>
    </message>
    <message>
      <source>GEOM_CURVE_TITLE</source>
      <translation>Construcţia curbei</translation>
    </message>
    <message>
      <source>GEOM_CUT</source>
      <translation>Taiere</translation>
    </message>
    <message>
      <source>GEOM_CUT_TITLE</source>
      <translation>Tăiere de obiecte</translation>
    </message>
    <message>
      <source>GEOM_CYLINDER</source>
      <translation>Cylinder</translation>
    </message>
    <message>
      <source>GEOM_CYLINDER_TITLE</source>
      <translation>Construcţia cilindrului</translation>
    </message>
    <message>
      <source>GEOM_CYLINDER_ANGLE_ERR</source>
      <translation>GEOM_CYLINDER_ANGLE_ERR</translation>
    </message>
    <message>
      <source>GEOM_D1</source>
      <translation>D1 :</translation>
    </message>
    <message>
      <source>GEOM_D2</source>
      <translation>D2 :</translation>
    </message>
    <message>
      <source>GEOM_DETECT</source>
      <translation>Detectă</translation>
    </message>
    <message>
      <source>GEOM_DIAGONAL_POINTS</source>
      <translation>Puncte diagonale</translation>
    </message>
    <message>
      <source>GEOM_DISK</source>
      <translation>Disk</translation>
    </message>
    <message>
      <source>GEOM_DISK_TITLE</source>
      <translation>Construcţia discului</translation>
    </message>
    <message>
      <source>GEOM_DIMENSIONS</source>
      <translation>Dimensions</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_DIST</source>
      <translation>Distanţă</translation>
    </message>
    <message>
      <source>GEOM_DISTANCE</source>
      <translation>Distanţă</translation>
    </message>
    <message>
      <source>GEOM_DIVIDE_EDGE_TITLE</source>
      <translation>Adaugare punct</translation>
    </message>
    <message>
      <source>GEOM_DX</source>
      <translation>Dx :</translation>
    </message>
    <message>
      <source>GEOM_DY</source>
      <translation>Dy :</translation>
    </message>
    <message>
      <source>GEOM_DZ</source>
      <translation>Dz :</translation>
    </message>
    <message>
      <source>GEOM_DropSmallEdges</source>
      <translation>DropSmallEdges</translation>
    </message>
    <message>
      <source>GEOM_DRAFT_ANGLE</source>
      <translation>Draft angle:</translation>
    </message>
    <message>
      <source>GEOM_EDGE</source>
      <translation>Margine</translation>
    </message>
    <message>
      <source>GEOM_EDGE_TITLE</source>
      <translation>Creare unghi</translation>
    </message>
    <message>
      <source>GEOM_ELLIPSE</source>
      <translation>Ellipse</translation>
    </message>
    <message>
      <source>GEOM_ELLIPSE_ERROR_1</source>
      <translation>Error creating ellipse.  Reason: minor radius is greater than major radius.</translation>
    </message>
    <message>
      <source>GEOM_ELLIPSE_TITLE</source>
      <translation>Construcţie elipsă</translation>
    </message>
    <message>
      <source>GEOM_END_LCS</source>
      <translation>End LCS</translation>
    </message>
    <message>
      <source>GEOM_ERROR</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>GEOM_ERROR_STATUS</source>
      <translation>Statutul operaţiei</translation>
    </message>
    <message>
      <source>GEOM_ERR_GET_ENGINE</source>
      <translation>Failed to obtain GEOM Engine component.  Reload Geometry module and try again.</translation>
    </message>
    <message>
      <source>GEOM_ERR_LIB_NOT_FOUND</source>
      <translation>GUI library corresponding to the user action can not be found or loaded</translation>
    </message>
    <message>
      <source>GEOM_EXTRUDED_CUT_TITLE</source>
      <translation>Extruded cut</translation>
    </message>
    <message>
      <source>GEOM_EXTRUDED_CUT</source>
      <translation>Extruded_cut</translation>
    </message>
    <message>
      <source>GEOM_EXTRUDED_BOSS_TITLE</source>
      <translation>Extruded boss</translation>
    </message>
    <message>
      <source>GEOM_EXTRUDED_BOSS</source>
      <translation>Extruded_boss</translation>
    </message>
    <message>
      <source>GEOM_EXTRUSION</source>
      <translation>Extrusion</translation>
    </message>
    <message>
      <source>GEOM_EXTRUSION_BSV</source>
      <translation>Base Shapes + Vector</translation>
    </message>
    <message>
      <source>GEOM_EXTRUSION_BSV_2P</source>
      <translation>Base Shapes + 2 Points</translation>
    </message>
    <message>
      <source>GEOM_EXTRUSION_DXDYDZ</source>
      <translation>Base Shapes + DX DY DZ Vector</translation>
    </message>
    <message>
      <source>GEOM_EXTRUSION_TITLE</source>
      <translation>Construction by Extrusion</translation>
    </message>
    <message>
      <source>GEOM_SCALE_PRISM</source>
      <translation>Scale the face opposite to the base</translation>
    </message>
    <message>
      <source>GEOM_FACE</source>
      <translation>Faţă</translation>
    </message>
    <message>
      <source>GEOM_CS</source>
      <translation>Sistem de coordonate</translation>
    </message>
    <message>
      <source>GEOM_GCS</source>
      <translation>Global coordinate system</translation>
    </message>
    <message>
      <source>GEOM_LCS</source>
      <translation>Sistem local de coordonate</translation>
    </message>
    <message>
      <source>GEOM_LOCATIONS</source>
      <translation>Locaţii</translation>
    </message>
    <message>
      <source>GEOM_FACES</source>
      <translation>Feţe</translation>
    </message>
    <message>
      <source>GEOM_FACE_FFW</source>
      <translation>Face creation from wires and/or edges</translation>
    </message>
    <message>
      <source>GEOM_FACE_OPT</source>
      <translation>Try to create a planar face</translation>
    </message>
    <message>
      <source>MAKE_FACE_TOLERANCE_TOO_BIG</source>
      <translation>Cannot build a planar face: required tolerance is         too big. Non-planar face is built.</translation>
    </message>
    <message>
      <source>GEOM_FACE_OR_LCS</source>
      <translation>Face or LCS</translation>
    </message>
    <message>
      <source>GEOM_FACE_SELECTION</source>
      <translation>Selectare faţă</translation>
    </message>
    <message>
      <source>GEOM_FACE_TITLE</source>
      <translation>Crearea unei feţe</translation>
    </message>
    <message>
      <source>GEOM_RECTANGLE_TITLE</source>
      <translation>Construire drepunghi</translation>
    </message>
    <message>
      <source>GEOM_RECTANGLE</source>
      <translation>Rectangle</translation>
    </message>
    <message>
      <source>GEOM_FILLET</source>
      <translation>Fillet</translation>
    </message>
    <message>
      <source>GEOM_FILLET_2D</source>
      <translation>Fillet 2D</translation>
    </message>
    <message>
      <source>GEOM_FILLET_1D</source>
      <translation>Fillet 1D</translation>
    </message>
    <message>
      <source>GEOM_FILLET_1D_IGNORE_SECANT</source>
      <translation>Fuse collinear edges to allow bigger radius</translation>
    </message>
    <message>
      <source>GEOM_FILLET_ABORT</source>
      <translation>Fillet can't be computed with radius %1</translation>
    </message>
    <message>
      <source>GEOM_FILLET_ALL</source>
      <translation>Fillet On Whole Shape</translation>
    </message>
    <message>
      <source>GEOM_FILLET_EDGES</source>
      <translation>Fillet On Selected Edges</translation>
    </message>
    <message>
      <source>GEOM_FILLET_FACES</source>
      <translation>Fillet On Selected Faces</translation>
    </message>
    <message>
      <source>GEOM_FILLET_TITLE</source>
      <translation>Fillet Construction</translation>
    </message>
    <message>
      <source>GEOM_FILLET_2D_TITLE</source>
      <translation>2D Fillet Construction</translation>
    </message>
    <message>
      <source>GEOM_FILLET_1D_TITLE</source>
      <translation>1D Fillet Construction</translation>
    </message>
    <message>
      <source>GEOM_FILLING</source>
      <translation>Filling</translation>
    </message>
    <message>
      <source>GEOM_FILLING_ARG</source>
      <translation>Arguments And Parameters</translation>
    </message>
    <message>
      <source>GEOM_FILLING_COMPOUND</source>
      <translation>Input compound</translation>
    </message>
    <message>
      <source>GEOM_FILLING_MAX_DEG</source>
      <translation>Max deg</translation>
    </message>
    <message>
      <source>GEOM_FILLING_MIN_DEG</source>
      <translation>Min deg</translation>
    </message>
    <message>
      <source>GEOM_FILLING_NB_ITER</source>
      <translation>Nb. Iter :</translation>
    </message>
    <message>
      <source>GEOM_FILLING_TITLE</source>
      <translation>Filling Surface With Edges</translation>
    </message>
    <message>
      <source>GEOM_FILLING_TOL_2D</source>
      <translation>Tol. 2D :</translation>
    </message>
    <message>
      <source>GEOM_FILLING_TOL_3D</source>
      <translation>Tol. 3D :</translation>
    </message>
    <message>
      <source>GEOM_FREE_BOUNDARIES</source>
      <translation>Frontiere libere</translation>
    </message>
    <message>
      <source>GEOM_FREE_BOUNDS_ERROR</source>
      <translation>Object is not selected</translation>
    </message>
    <message>
      <source>GEOM_FREE_BOUNDS_MSG</source>
      <translation>Number of free boundaries detected: %1 (%2 closed, %3 open)</translation>
    </message>
    <message>
      <source>GEOM_FREE_BOUNDS_TLT</source>
      <translation>Detectarea frontierelor libere</translation>
    </message>
    <message>
      <source>GEOM_FREE_FACES</source>
      <translation>Feţe libere</translation>
    </message>
    <message>
      <source>GEOM_FREE_FACES_TITLE</source>
      <translation>Feţe libere</translation>
    </message>
    <message>
      <source>GEOM_FUSE</source>
      <translation>Fuse</translation>
    </message>
    <message>
      <source>GEOM_FUSE_TITLE</source>
      <translation>Fuse Objects</translation>
    </message>
    <message>
      <source>GEOM_FixFaceSize</source>
      <translation>FixFaceSize</translation>
    </message>
    <message>
      <source>GEOM_FixShape</source>
      <translation>FixShape</translation>
    </message>
    <message>
      <source>GEOM_GLUE</source>
      <translation>Lipeşte</translation>
    </message>
    <message>
      <source>GEOM_GLUE_FACES_TITLE</source>
      <translation>Lipeşte feţe</translation>
    </message>
    <message>
      <source>GEOM_GLUE_EDGES_TITLE</source>
      <translation>Lipeşte muchiile</translation>
    </message>
    <message>
      <source>GLUE_ERROR_STICKED_SHAPES</source>
      <translation>The tolerance value is too big. Sticked shapes are detected.</translation>
    </message>
    <message>
      <source>GEOM_LIMIT_TOLERANCE_TITLE</source>
      <translation>Limitează toleranţa</translation>
    </message>
    <message>
      <source>GEOM_HEIGHT</source>
      <translation>Înălţime :</translation>
    </message>
    <message>
      <source>GEOM_HEXAGON</source>
      <translation>Hexagon</translation>
    </message>
    <message>
      <source>GEOM_HOLES</source>
      <translation>Holes</translation>
    </message>
    <message>
      <source>GEOM_INIT_SHAPE</source>
      <translation>Initial shape</translation>
    </message>
    <message>
      <source>GEOM_IDENTICAL_NAMES_SELECT_BY_MOUSE</source>
      <translation>Identical names : select by mouse !</translation>
    </message>
    <message>
      <source>GEOM_IMPORT</source>
      <translation>Imported_Shape</translation>
    </message>
    <message>
      <source>GEOM_INCORRECT_INPUT</source>
      <translation>Incorrect Input Data!</translation>
    </message>
    <message>
      <source>GEOM_INERTIA_CONSTR</source>
      <translation>Matrix And Moments Of Inertia</translation>
    </message>
    <message>
      <source>GEOM_INERTIA_TITLE</source>
      <translation>Calculul inerţiei</translation>
    </message>
    <message>
      <source>GEOM_INF_LOADED</source>
      <translation>Fiţierul %1 este încărcat.</translation>
    </message>
    <message>
      <source>GEOM_INTERNAL_WIRES</source>
      <translation>Internal wires</translation>
    </message>
    <message>
      <source>GEOM_INTERPOL</source>
      <translation>Interpolation</translation>
    </message>
    <message>
      <source>GEOM_KEEP_OBJECT</source>
      <translation>Keep Object</translation>
    </message>
    <message>
      <source>GEOM_LENGTH</source>
      <translation>Lungimea :</translation>
    </message>
    <message>
      <source>GEOM_LINE</source>
      <translation>Line</translation>
    </message>
    <message>
      <source>GEOM_LINE_TITLE</source>
      <translation>Construirea liniei</translation>
    </message>
    <message>
      <source>GEOM_MAIN_OBJECT</source>
      <translation>Main Object</translation>
    </message>
    <message>
      <source>GEOM_MARKER</source>
      <translation>Marker</translation>
    </message>
    <message>
      <source>GEOM_MARKER_TITLE</source>
      <translation>Create marker</translation>
    </message>
    <message>
      <source>GEOM_MATERIAL_ID</source>
      <translation>ID-ul materialului:</translation>
    </message>
    <message>
      <source>GEOM_MATERIAL_MATERIAL</source>
      <translation>Material</translation>
    </message>
    <message>
      <source>GEOM_MATERIAL_SET</source>
      <translation>&lt;&lt; Set</translation>
    </message>
    <message>
      <source>GEOM_MATERIAL_SHAPE</source>
      <translation>Shapes</translation>
    </message>
    <message>
      <source>GEOM_MATERIAL_TITLE</source>
      <translation>Define materials for Dominant Fuse</translation>
    </message>
    <message>
      <source>GEOM_MATRIX</source>
      <translation>Matrice :</translation>
    </message>
    <message>
      <source>GEOM_MAX</source>
      <translation>Max :</translation>
    </message>
    <message>
      <source>GEOM_MAX_3D_TOLERANCE</source>
      <translation>Toleranţa 3D maximă</translation>
    </message>
    <message>
      <source>GEOM_MAX_TOLERANCE</source>
      <translation>Toleranţa maximă</translation>
    </message>
    <message>
      <source>GEOM_MEN_ALL_FILES</source>
      <translation>Toate fişierele ( * )</translation>
    </message>
    <message>
      <source>GEOM_MEN_ANGLE</source>
      <translation>Unghi:</translation>
    </message>
    <message>
      <source>GEOM_MEN_COMPONENT</source>
      <translation>Geometry</translation>
    </message>
    <message>
      <source>GEOM_MEN_ENTER_ANGLE</source>
      <translation>Introduce un unghi în grade</translation>
    </message>
    <message>
      <source>GEOM_MEN_ISOS</source>
      <translation>Select Number Of Isos</translation>
    </message>
    <message>
      <source>GEOM_MEN_ISOU</source>
      <translation>Isos U :</translation>
    </message>
    <message>
      <source>GEOM_MEN_ISOV</source>
      <translation>Isos V :</translation>
    </message>
    <message>
      <source>GEOM_MEN_POPUP_NAME</source>
      <translation>%1 Objects</translation>
    </message>
    <message>
      <source>GEOM_MEN_SHADING</source>
      <translation>Shading</translation>
    </message>
    <message>
      <source>GEOM_MEN_SHADING_WITH_EDGES</source>
      <translation>Shading With Edges</translation>
    </message>
    <message>
      <source>GEOM_MEN_SKETCHER_X</source>
      <translation>Enter a Length to Set X</translation>
    </message>
    <message>
      <source>GEOM_MEN_SKETCHER_Y</source>
      <translation>Enter a Length to Set Y</translation>
    </message>
    <message>
      <source>GEOM_MEN_STEP_LABEL</source>
      <translation>Step :</translation>
    </message>
    <message>
      <source>GEOM_MEN_TRANSPARENCY</source>
      <translation>Transparency</translation>
    </message>
    <message>
      <source>GEOM_MEN_TRANSPARENCY_LABEL</source>
      <translation>Transparenţă :</translation>
    </message>
    <message>
      <source>GEOM_MEN_WIREFRAME</source>
      <translation>Wireframe</translation>
    </message>
    <message>
      <source>GEOM_MEN_X</source>
      <translation>X :</translation>
    </message>
    <message>
      <source>GEOM_MEN_Y</source>
      <translation>Y :</translation>
    </message>
    <message>
      <source>GEOM_MESHING_DEFLECTION</source>
      <translation>Meshing Deflect. :</translation>
    </message>
    <message>
      <source>GEOM_MIN</source>
      <translation>Min :</translation>
    </message>
    <message>
      <source>GEOM_MINDIST_NAME</source>
      <translation>MinDist</translation>
    </message>
    <message>
      <source>GEOM_MINDIST_NO_SOL</source>
      <translation>Nici o soluţie găsită</translation>
    </message>
    <message>
      <source>GEOM_MINDIST_OBJ</source>
      <translation>Obiecte şi rezultate</translation>
    </message>
    <message>
      <source>GEOM_MINDIST_PUBLISH_TITLE</source>
      <translation>Sunt găsite soluţii multiple</translation>
    </message>
    <message>
      <source>GEOM_MINDIST_PUBLISH_TEXT</source>
      <translation>Do you want to publish in the study all found solutions? If No, only the currently selected solution will be published.</translation>
    </message>
    <message>
      <source>GEOM_MINDIST_TITLE</source>
      <translation>Distanţa minimă dintre două obiecte</translation>
    </message>
    <message>
      <source>GEOM_MIRROR</source>
      <translation>Mirror</translation>
    </message>
    <message>
      <source>GEOM_MIRROR_TITLE</source>
      <translation>Oglindirea unui obiect</translation>
    </message>
    <message>
      <source>GEOM_MODE</source>
      <translation>Mod</translation>
    </message>
    <message>
      <source>GEOM_MULTIROTATION</source>
      <translation>Multi-Rotation</translation>
    </message>
    <message>
      <source>GEOM_MULTIROTATION_DOUBLE</source>
      <translation>Multi Rotation Double</translation>
    </message>
    <message>
      <source>GEOM_MULTIROTATION_SIMPLE</source>
      <translation>Multi Rotation Simple</translation>
    </message>
    <message>
      <source>GEOM_MULTIROTATION_TITLE</source>
      <translation>Multi-Rotation</translation>
    </message>
    <message>
      <source>GEOM_MULTITRANSLATION</source>
      <translation>Multi-Translation</translation>
    </message>
    <message>
      <source>GEOM_MULTITRANSLATION_DOUBLE</source>
      <translation>Multi Translation Double</translation>
    </message>
    <message>
      <source>GEOM_MULTITRANSLATION_SIMPLE</source>
      <translation>Multi Translation Simple</translation>
    </message>
    <message>
      <source>GEOM_MULTITRANSLATION_TITLE</source>
      <translation>Multi-Translation</translation>
    </message>
    <message>
      <source>GEOM_NAME_INCORRECT</source>
      <translation>Numele obiectului nu este găsit</translation>
    </message>
    <message>
      <source>GEOM_NB_BLOCKS_NO_OTHERS</source>
      <translation>There are %1 specified blocks and NO other solids</translation>
    </message>
    <message>
      <source>GEOM_NB_BLOCKS_SOME_OTHERS</source>
      <translation>There are %1 specified blocks and some other solids</translation>
    </message>
    <message>
      <source>GEOM_NB_TIMES</source>
      <translation>Nb. Times :</translation>
    </message>
    <message>
      <source>GEOM_NB_TIMES_U</source>
      <translation>Nb. Times U :</translation>
    </message>
    <message>
      <source>GEOM_NB_TIMES_V</source>
      <translation>Nb. Times V :</translation>
    </message>
    <message>
      <source>GEOM_NODES</source>
      <translation>Nodes</translation>
    </message>
    <message>
      <source>GEOM_NUM_SPLIT_POINTS</source>
      <translation>Number of splitting points</translation>
    </message>
    <message>
      <source>GEOM_OBJECT</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>GEOM_OBJECT_TYPE</source>
      <translation>Object Type</translation>
    </message>
    <message>
      <source>GEOM_OBJECTS</source>
      <translation>Objects</translation>
    </message>
    <message>
      <source>GEOM_OBJECT_I</source>
      <translation>Obiect %1</translation>
    </message>
    <message>
      <source>GEOM_OBJECT_RESULT</source>
      <translation>Obiect şi rezultat</translation>
    </message>
    <message>
      <source>GEOM_OFFSET</source>
      <translation>Offset</translation>
    </message>
    <message>
      <source>GEOM_OFFSET_TITLE</source>
      <translation>Offset Surface</translation>
    </message>
    <message>
      <source>GEOM_PATTERN</source>
      <translation>Division pattern</translation>
    </message>
    <message>
      <source>GEOM_PROJECTION</source>
      <translation>Projection</translation>
    </message>
    <message>
      <source>GEOM_PROJECTION_TITLE</source>
      <translation>Projection on Face</translation>
    </message>
    <message>
      <source>GEOM_SOURCE_OBJECT</source>
      <translation>Source vertex, edge or wire</translation>
    </message>
    <message>
      <source>GEOM_SOLUTION</source>
      <translation>Soluţie</translation>
    </message>
    <message>
      <source>GEOM_SOLUTION_I</source>
      <translation>Soluţia %1</translation>
    </message>
    <message>
      <source>GEOM_TARGET_OBJECT</source>
      <translation>Faţa ţintă</translation>
    </message>
    <message>
      <source>GEOM_WITH_CONTACT</source>
      <translation>With contact</translation>
    </message>
    <message>
      <source>GEOM_WITH_CORRECTION</source>
      <translation>Cu correcţie</translation>
    </message>
    <message>
      <source>GEOM_OPERATIONS</source>
      <translation>Operaţii</translation>
    </message>
    <message>
      <source>GEOM_ORIENTATION</source>
      <translation>Orientare</translation>
    </message>
    <message>
      <source>GEOM_ORIENTATION_OPT</source>
      <translation>Reverse orientation with normal vectors simulation</translation>
    </message>
    <message>
      <source>GEOM_ORIENTATION_TITLE</source>
      <translation>Schimbă orientarea</translation>
    </message>
    <message>
      <source>GEOM_PARAMETER</source>
      <translation>Parameter :</translation>
    </message>
    <message>
      <source>GEOM_PARAMETERS</source>
      <translation>Parameters</translation>
    </message>
    <message>
      <source>GEOM_POINT_ON_EDGE</source>
      <translation>Punct pe muchie</translation>
    </message>
    <message>
      <source>GEOM_POINT_ON_FACE</source>
      <translation>Punct pe faţă</translation>
    </message>
    <message>
      <source>GEOM_PARAM_VALUE</source>
      <translation>By parameter</translation>
    </message>
    <message>
      <source>GEOM_COORD_VALUE</source>
      <translation>By coordinate</translation>
    </message>
    <message>
      <source>GEOM_LENGTH_VALUE</source>
      <translation>By length</translation>
    </message>
    <message>
      <source>GEOM_PARTITION</source>
      <translation>Partition</translation>
    </message>
    <message>
      <source>GEOM_WRN_PARTITION_RESULT_EMPTY</source>
      <translation>The partition result is empty, please verify the reconstruction limit parameter.</translation>
    </message>
    <message>
      <source>GEOM_PARTITION_HALFSPACE</source>
      <translation>Half-space partition</translation>
    </message>
    <message>
      <source>GEOM_PARTITION_ORIENTATION</source>
      <translation>Change Orientation</translation>
    </message>
    <message>
      <source>GEOM_PARTITION_TITLE</source>
      <translation>Partition Of Object With Tool</translation>
    </message>
    <message>
      <source>GEOM_PATH_OBJECT</source>
      <translation>Path Object</translation>
    </message>
    <message>
      <source>GEOM_PIPE</source>
      <translation>Pipe</translation>
    </message>
    <message>
      <source>GEOM_PIPE_TITLE</source>
      <translation>Pipe Construction</translation>
    </message>
    <message>
      <source>GEOM_PIPE_PATH</source>
      <translation>Path</translation>
    </message>
    <message>
      <source>GEOM_PIPE_PATH_TITLE</source>
      <translation>Restore Path</translation>
    </message>
    <message>
      <source>GEOM_PIPE_LIKE_SHAPE</source>
      <translation>Pipe-like shell or solid</translation>
    </message>
    <message>
      <source>GEOM_PIPE_BASE1_OBJECT</source>
      <translation>First base face/wire/edges</translation>
    </message>
    <message>
      <source>GEOM_PIPE_BASE2_OBJECT</source>
      <translation>Last base face/wire/edges</translation>
    </message>
    <message>
      <source>GEOM_PROFILE</source>
      <translation>Profile</translation>
    </message>
    <message>
      <source>GEOM_SEGMENT</source>
      <translation>Segment of straight line</translation>
    </message>
    <message>
      <source>GEOM_SELECT_UNPUBLISHED_EDGES</source>
      <translation>Select unpublished edges</translation>
    </message>
    <message>
      <source>GEOM_PLANE</source>
      <translation>Plane</translation>
    </message>
    <message>
      <source>GEOM_PLANE_MIRROR</source>
      <translation>Oglindirea planului</translation>
    </message>
    <message>
      <source>GEOM_PLANE_PV</source>
      <translation>Point + Vector</translation>
    </message>
    <message>
      <source>GEOM_PLANE_PVC</source>
      <translation>Point + Coordinate Vector</translation>
    </message>
    <message>
      <source>GEOM_PLANE_SIZE</source>
      <translation>Mărimea planului :</translation>
    </message>
    <message>
      <source>GEOM_PLANE_TITLE</source>
      <translation>Construirea palnului</translation>
    </message>
    <message>
      <source>GEOM_POINT</source>
      <translation>Point</translation>
    </message>
    <message>
      <source>GEOM_POINT1</source>
      <translation>Point 1</translation>
    </message>
    <message>
      <source>GEOM_POINT2</source>
      <translation>Point 2</translation>
    </message>
    <message>
      <source>GEOM_POINT3</source>
      <translation>Point 3</translation>
    </message>
    <message>
      <source>GEOM_POINTS</source>
      <translation>Points</translation>
    </message>
    <message>
      <source>GEOM_POINT_I</source>
      <translation>Point %1</translation>
    </message>
    <message>
      <source>GEOM_POINT_MIRROR</source>
      <translation>Oglindirea punctului</translation>
    </message>
    <message>
      <source>GEOM_POINT_TITLE</source>
      <translation>Construirea punctului</translation>
    </message>
    <message>
      <source>GEOM_START_POINT</source>
      <translation>Punct de început</translation>
    </message>
    <message>
      <source>GEOM_POLYLINE</source>
      <translation>Polyline</translation>
    </message>
    <message>
      <source>GEOM_POSITION</source>
      <translation>Location</translation>
    </message>
    <message>
      <source>GEOM_POSITION_TITLE</source>
      <translation>Modificarea locaţiei unui obiect</translation>
    </message>
    <message>
      <source>GEOM_PRECISION</source>
      <translation>Precizie :</translation>
    </message>
    <message>
      <source>GEOM_PROPAGATE</source>
      <translation>Propagate</translation>
    </message>
    <message>
      <source>GEOM_PROPAGATE_TITLE</source>
      <translation>Propagate</translation>
    </message>
    <message>
      <source>GEOM_PROPERTIES</source>
      <translation>Basic Properties</translation>
    </message>
    <message>
      <source>GEOM_PROPERTIES_CONSTR</source>
      <translation>Object And Its Properties</translation>
    </message>
    <message>
      <source>GEOM_PROPERTIES_SURFACE</source>
      <translation>Suprafaţa este :</translation>
    </message>
    <message>
      <source>GEOM_PROPERTIES_TITLE</source>
      <translation>Basic Properties Information</translation>
    </message>
    <message>
      <source>GEOM_PROPERTIES_VOLUME</source>
      <translation>Volume is :</translation>
    </message>
    <message>
      <source>GEOM_PRP_ABORT</source>
      <translation>Operaţie abandonată</translation>
    </message>
    <message>
      <source>GEOM_PRP_COMMAND</source>
      <translation>No command associated with this id = %1.</translation>
    </message>
    <message>
      <source>GEOM_PRP_DONE</source>
      <translation>Operaţie terminată</translation>
    </message>
    <message>
      <source>GEOM_PRP_EXPORT</source>
      <translation>Exportarea geometriei către %1 ...</translation>
    </message>
    <message>
      <source>GEOM_PRP_LOADING</source>
      <translation>Loading %1 ...</translation>
    </message>
    <message>
      <source>GEOM_PRP_MIN_DIST</source>
      <translation>Min Distance not computed</translation>
    </message>
    <message>
      <source>GEOM_PRP_NOT_FOR_VTK_VIEWER</source>
      <translation>Not allowed in VTK viewer</translation>
    </message>
    <message>
      <source>GEOM_PRP_NULLSHAPE</source>
      <translation>Error, null or inappropriate shape !</translation>
    </message>
    <message>
      <source>GEOM_PRP_READY</source>
      <translation>Ready</translation>
    </message>
    <message>
      <source>GEOM_PRP_SELECT_EDGE</source>
      <translation>Select edges and click on Apply</translation>
    </message>
    <message>
      <source>GEOM_PRP_SELECT_FACE</source>
      <translation>Select faces to suppress and click on Ok/Apply</translation>
    </message>
    <message>
      <source>GEOM_PRP_SELECT_FIRST</source>
      <translation>Select main shape first</translation>
    </message>
    <message>
      <source>GEOM_PRP_SELECT_SUBSHAPES</source>
      <translation>Select Sub-shapes</translation>
    </message>
    <message>
      <source>GEOM_PRP_SHAPE_IN_STUDY</source>
      <translation>Main shape must be in the study before</translation>
    </message>
    <message>
      <source>GEOM_QUAD_FACE</source>
      <translation>Quadrangle Face</translation>
    </message>
    <message>
      <source>GEOM_QUAD_FACE_TITLE</source>
      <translation>Quadrangle Face Construction</translation>
    </message>
    <message>
      <source>GEOM_RADIUS</source>
      <translation>Raza :</translation>
    </message>
    <message>
      <source>GEOM_RADIUS_I</source>
      <translation>Raza %1 :</translation>
    </message>
    <message>
      <source>GEOM_RADIUS_MAJOR</source>
      <translation>Major radius :</translation>
    </message>
    <message>
      <source>GEOM_RADIUS_MINOR</source>
      <translation>Minor radius :</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT</source>
      <translation>Resulting Type</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT_EDGE</source>
      <translation>Muchie</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT_FACE</source>
      <translation>Faţă</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT_SHAPE</source>
      <translation>Shape</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT_SHELL</source>
      <translation>Membrană</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT_SOLID</source>
      <translation>Solid</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT_VERTEX</source>
      <translation>Vertex</translation>
    </message>
    <message>
      <source>GEOM_RECONSTRUCTION_LIMIT_WIRE</source>
      <translation>Wire</translation>
    </message>
    <message>
      <source>GEOM_REF_POINT</source>
      <translation>Point with reference</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_ALL_HOLES</source>
      <translation>Remove all holes</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_ALL_INT_WIRES</source>
      <translation>Remove all internal wires</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_HOLES_TITLE</source>
      <translation>Suppress holes</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_INTERNAL_WIRES_TITLE</source>
      <translation>Suppress internal wires</translation>
    </message>
    <message>
      <source>GEOM_REQUIRED_DEGREE</source>
      <translation>Required degree</translation>
    </message>
    <message>
      <source>GEOM_REQUIRED_NUM_SEGMENTS</source>
      <translation>Required number of segments</translation>
    </message>
    <message>
      <source>GEOM_REVERSE</source>
      <translation>Reverse</translation>
    </message>
    <message>
      <source>GEOM_REVERSE_DIRECTION</source>
      <translation>Reverse Direction</translation>
    </message>
    <message>
      <source>GEOM_REVERSE_PLANE</source>
      <translation>Reverse the plane normal</translation>
    </message>
    <message>
      <source>GEOM_REVERSE_U</source>
      <translation>Reverse U</translation>
    </message>
    <message>
      <source>GEOM_REVERSE_V</source>
      <translation>Reverse V</translation>
    </message>
    <message>
      <source>GEOM_REVERSE_VECTOR</source>
      <translation>Reverse Vector</translation>
    </message>
    <message>
      <source>GEOM_REVOLUTION</source>
      <translation>Revolution</translation>
    </message>
    <message>
      <source>GEOM_REVOLUTION_TITLE</source>
      <translation>Construction By Revolution</translation>
    </message>
    <message>
      <source>GEOM_ROTATION</source>
      <translation>Rotation</translation>
    </message>
    <message>
      <source>GEOM_ROTATION_TITLE</source>
      <translation>Rotaţia unui obiect</translation>
    </message>
    <message>
      <source>GEOM_SCALE</source>
      <translation>Scale</translation>
    </message>
    <message>
      <source>GEOM_SCALE_FACTOR</source>
      <translation>Scale Factor :</translation>
    </message>
    <message>
      <source>GEOM_SCALE_TITLE</source>
      <translation>Scale An Object</translation>
    </message>
    <message>
      <source>GEOM_SECTION</source>
      <translation>Secţiune</translation>
    </message>
    <message>
      <source>GEOM_SECTION_TITLE</source>
      <translation>Section Of Two Objects</translation>
    </message>
    <message>
      <source>GEOM_SELECTED_FACE</source>
      <translation>Feţele selectate</translation>
    </message>
    <message>
      <source>GEOM_SELECTED_OBJECTS</source>
      <translation>Selected objects</translation>
    </message>
    <message>
      <source>GEOM_SELECTED_SHAPE</source>
      <translation>Selected shape</translation>
    </message>
    <message>
      <source>GEOM_SELECTION</source>
      <translation>Selection</translation>
    </message>
    <message>
      <source>GEOM_SET_MATERIALS</source>
      <translation>Set materials</translation>
    </message>
    <message>
      <source>GEOM_SEWING</source>
      <translation>Sewing</translation>
    </message>
    <message>
      <source>GEOM_SEWING_TITLE</source>
      <translation>Topological sewing</translation>
    </message>
    <message>
      <source>GEOM_ALLOW_NON_MANIFOLD</source>
      <translation>Allow Non Manifold</translation>
    </message>
    <message>
      <source>GEOM_SHAPE</source>
      <translation>Shape</translation>
    </message>
    <message>
      <source>GEOM_SHAPEPROCESS_TITLE</source>
      <translation>Shape Processing</translation>
    </message>
    <message>
      <source>GEOM_SHAPES</source>
      <translation>Shapes</translation>
    </message>
    <message>
      <source>GEOM_SHELL</source>
      <translation>Membrană</translation>
    </message>
    <message>
      <source>GEOM_SHELLS</source>
      <translation>Membrane</translation>
    </message>
    <message>
      <source>GEOM_SHELL_TITLE</source>
      <translation>Construirea membranei</translation>
    </message>
    <message>
      <source>GEOM_SHOW_LENGTH</source>
      <translation>Show length dimensions</translation>
    </message>
    <message>
      <source>GEOM_SHOW_ANGLE</source>
      <translation>Show angle dimensions</translation>
    </message>
    <message>
      <source>GEOM_SHOW_POINTS_COORD</source>
      <translation>Show start/end point coordinates</translation>
    </message>
    <message>
      <source>GEOM_SKETCH</source>
      <translation>Sketch</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_ABS</source>
      <translation>Absolut</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_ADD_PARAMS</source>
      <translation>Parametri adiţionali</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_ANGLE</source>
      <translation>Angle</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_ANGLE2</source>
      <translation>Unghi :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_APPLY</source>
      <translation>Aplică</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_ARC</source>
      <translation>Arc</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_CENTER</source>
      <translation>Centru</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_CENTER2</source>
      <translation>Centru :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_WARNING</source>
      <translation>Warning: End point not on the arc, distance = </translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_CENTER_X</source>
      <translation>X Center :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_CENTER_Y</source>
      <translation>Y Center :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_CENTER_DX</source>
      <translation>DX Center :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_CENTER_DY</source>
      <translation>DY Center :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_DEST</source>
      <translation>Destinaţie</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_DIR</source>
      <translation>Direcţie</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_DX2</source>
      <translation>DX :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_DY2</source>
      <translation>DY :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_DZ2</source>
      <translation>DZ :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_EL</source>
      <translation>Tip de element</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_RESTORE</source>
      <translation>Restaurează</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_LENGTH</source>
      <translation>Length</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_LENGTH2</source>
      <translation>Lungime :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_NONE</source>
      <translation>None (Tangential)</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_PER</source>
      <translation>Perpendicular</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_POINT</source>
      <translation>Point</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_POINT2</source>
      <translation>Punct :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_END_POINT2</source>
      <translation>End Point :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_RADIUS</source>
      <translation>Rază</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_RADIUS2</source>
      <translation>Raza :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_REL</source>
      <translation>Relativ</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_SEGMENT</source>
      <translation>Segment</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_SEL</source>
      <translation>Selection</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_TAN</source>
      <translation>Tangentă</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_TITLE</source>
      <translation>2D Sketch Construction</translation>
    </message>
    <message>
      <source>GEOM_3DSKETCHER_TITLE</source>
      <translation>3D Sketch Construction</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_TYPE</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_UNDO</source>
      <translation>Înapoi</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_VALUES</source>
      <translation>Valori</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_VX2</source>
      <translation>VX :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_VXVY</source>
      <translation>VX-VY</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_WPLANE</source>
      <translation>Selectarea unei feţe planare sau a unui plan</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_VY2</source>
      <translation>VY :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_X</source>
      <translation>X</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_X2</source>
      <translation>X :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_X3</source>
      <translation>DX :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_Y</source>
      <translation>Y</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_Y2</source>
      <translation>Y :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_Y3</source>
      <translation>DY :</translation>
    </message>
    <message>
      <source>GEOM_SKETCHER_Z2</source>
      <translation>Z :</translation>
    </message>
    <message>
      <source>GEOM_3DSKETCHER</source>
      <translation>3D Sketcher</translation>
    </message>
    <message>
      <source>GEOM_COORDINATES_TYPE</source>
      <translation>Tip de coordonate</translation>
    </message>
    <message>
      <source>GEOM_CONTROLS</source>
      <translation>Controls</translation>
    </message>
    <message>
      <source>GEOM_SOLID</source>
      <translation>Solid</translation>
    </message>
    <message>
      <source>GEOM_SOLID_TITLE</source>
      <translation>Solid Construction</translation>
    </message>
    <message>
      <source>GEOM_SPHERE</source>
      <translation>Sferă</translation>
    </message>
    <message>
      <source>GEOM_SPHERE_CR</source>
      <translation>Centru + Raza</translation>
    </message>
    <message>
      <source>GEOM_SPHERE_RO</source>
      <translation>Radius At Origin</translation>
    </message>
    <message>
      <source>GEOM_SPHERE_TITLE</source>
      <translation>Sphere Construction</translation>
    </message>
    <message>
      <source>GEOM_SPLINE</source>
      <translation>Spline</translation>
    </message>
    <message>
      <source>GEOM_SPLINE_TITLE</source>
      <translation>Spline Construction</translation>
    </message>
    <message>
      <source>GEOM_SQUARE</source>
      <translation>Pătrat</translation>
    </message>
    <message>
      <source>GEOM_START</source>
      <translation>Început :</translation>
    </message>
    <message>
      <source>GEOM_END</source>
      <translation>Sfîrşit :</translation>
    </message>
    <message>
      <source>GEOM_START_LCS</source>
      <translation>Start LCS</translation>
    </message>
    <message>
      <source>SELECT_UNPUBLISHED_EDGES</source>
      <translation>Select unpublished edges</translation>
    </message>
    <message>
      <source>GEOM_STEP</source>
      <translation>Pas :</translation>
    </message>
    <message>
      <source>GEOM_STEP_R</source>
      <translation>Radial step :</translation>
    </message>
    <message>
      <source>GEOM_STEP_TITLE</source>
      <translation>Step value for GUI constructions</translation>
    </message>
    <message>
      <source>GEOM_STEP_U</source>
      <translation>Step U :</translation>
    </message>
    <message>
      <source>GEOM_STEP_V</source>
      <translation>Step V :</translation>
    </message>
    <message>
      <source>GEOM_STUDY_LOCKED</source>
      <translation>The active study is locked and therefore cannot be modified</translation>
    </message>
    <message>
      <source>GEOM_SUBSHAPE_SELECT</source>
      <translation>Select Sub-shapes</translation>
    </message>
    <message>
      <source>GEOM_SUBSHAPE_TITLE</source>
      <translation>Sub-shapes Selection</translation>
    </message>
    <message>
      <source>GEOM_SUBSHAPE_TYPE</source>
      <translation>Sub-shapes Type</translation>
    </message>
    <message>
      <source>GEOM_SUB_SHAPE</source>
      <translation>Sub-shapes</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESSHOLE_FACE_SHELL</source>
      <translation>Faţă sau membrană</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESSHOLE_SELECTFACE</source>
      <translation>Selectează faţa cu gaură</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESSHOLE_SELECTFACE_END</source>
      <translation>Select end face (if hole traversing)</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESSHOLE_SELECTWIRE</source>
      <translation>Select wire on face</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESSHOLE_SELECTWIRE_END</source>
      <translation>Select end wire (if hole traversing)</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESSHOLE_SELECT_HOLES_ON_FACE</source>
      <translation>Select hole(s) on the face</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESSHOLE_TITLE</source>
      <translation>Suppress holes</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESS_RESULT</source>
      <translation>Suppress Result</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESS_RESULT_INSIDE</source>
      <translation>Inside</translation>
    </message>
    <message>
      <source>GEOM_SUPPRESS_RESULT_OUTSIDE</source>
      <translation>Outside</translation>
    </message>
    <message>
      <source>GEOM_SUPRESSFACE</source>
      <translation>Supress Face</translation>
    </message>
    <message>
      <source>GEOM_SUPRESSFACE_SELECT</source>
      <translation>Select Faces To Suppress</translation>
    </message>
    <message>
      <source>GEOM_SUPRESSFACE_TITLE</source>
      <translation>Suppress Faces In An Object</translation>
    </message>
    <message>
      <source>GEOM_SURFACE_CONTINUTY</source>
      <translation>Surface continuity</translation>
    </message>
    <message>
      <source>GEOM_SURFACE_MODE</source>
      <translation>Surface mode</translation>
    </message>
    <message>
      <source>GEOM_SURFCONE</source>
      <translation>Conical Face</translation>
    </message>
    <message>
      <source>GEOM_SURFCYLINDER</source>
      <translation>Cylindrical Face</translation>
    </message>
    <message>
      <source>GEOM_SURFSPHERE</source>
      <translation>Spherical Face</translation>
    </message>
    <message>
      <source>GEOM_SURFTORUS</source>
      <translation>Toroidal Face</translation>
    </message>
    <message>
      <source>GEOM_SameParameter</source>
      <translation>SameParameter</translation>
    </message>
    <message>
      <source>GEOM_SplitAngle</source>
      <translation>SplitAngle</translation>
    </message>
    <message>
      <source>GEOM_SplitClosedFaces</source>
      <translation>SplitClosedFaces</translation>
    </message>
    <message>
      <source>GEOM_SplitContinuity</source>
      <translation>SplitContinuity</translation>
    </message>
    <message>
      <source>GEOM_THICKNESS</source>
      <translation>Thickness</translation>
    </message>
    <message>
      <source>GEOM_TOLERANCE</source>
      <translation>Tolerance</translation>
    </message>
    <message>
      <source>GEOM_LINEAR_TOLERANCE</source>
      <translation>Toleranţă liniară</translation>
    </message>
    <message>
      <source>GEOM_ANGULAR_TOLERANCE</source>
      <translation>Toleranţă unghiulară</translation>
    </message>
    <message>
      <source>GEOM_TOLERANCE_CONSTR</source>
      <translation>Object And Its Tolerances</translation>
    </message>
    <message>
      <source>GEOM_TOLERANCE_EDGE</source>
      <translation>Muchie :</translation>
    </message>
    <message>
      <source>GEOM_TOLERANCE_FACE</source>
      <translation>Faţă :</translation>
    </message>
    <message>
      <source>GEOM_TOLERANCE_TITLE</source>
      <translation>Toleranţa maximă</translation>
    </message>
    <message>
      <source>GEOM_TOLERANCE_VERTEX</source>
      <translation>Vertex :</translation>
    </message>
    <message>
      <source>GEOM_TOOL_OBJECTS</source>
      <translation>Tool Objects</translation>
    </message>
    <message>
      <source>GEOM_TORUS</source>
      <translation>Torus</translation>
    </message>
    <message>
      <source>GEOM_TORUS_TITLE</source>
      <translation>Construire tor</translation>
    </message>
    <message>
      <source>GEOM_TRANSLATION</source>
      <translation>Translation</translation>
    </message>
    <message>
      <source>GEOM_TRANSLATION_COOR</source>
      <translation>Translation With Coordinates</translation>
    </message>
    <message>
      <source>GEOM_TRANSLATION_TITLE</source>
      <translation>Translation Of An Object</translation>
    </message>
    <message>
      <source>GEOM_TRANSPARENCY_OPAQUE</source>
      <translation>Opaque</translation>
    </message>
    <message>
      <source>GEOM_TRANSPARENCY_TITLE</source>
      <translation>Transparency</translation>
    </message>
    <message>
      <source>GEOM_TRANSPARENCY_TRANSPARENT</source>
      <translation>Transparent</translation>
    </message>
    <message>
      <source>GEOM_TRIHEDRON</source>
      <translation>Trihedron</translation>
    </message>
    <message>
      <source>GEOM_ToBezier</source>
      <translation>ToBezier</translation>
    </message>
    <message>
      <source>GEOM_VALUE</source>
      <translation>Valoare</translation>
    </message>
    <message>
      <source>GEOM_VECTOR</source>
      <translation>Vector</translation>
    </message>
    <message>
      <source>GEOM_AXIS_DEFAULT</source>
      <translation>(Z axis by default)</translation>
    </message>
    <message>
      <source>GEOM_VECTOR_LENGTH</source>
      <translation>Lungimea vectorului :</translation>
    </message>
    <message>
      <source>GEOM_VECTOR_TITLE</source>
      <translation>Construirea vectorului</translation>
    </message>
    <message>
      <source>GEOM_VECTOR_U</source>
      <translation>Vector U</translation>
    </message>
    <message>
      <source>GEOM_VECTOR_V</source>
      <translation>Vector V</translation>
    </message>
    <message>
      <source>GEOM_VERTEX</source>
      <translation>Vertex</translation>
    </message>
    <message>
      <source>GEOM_VERTEXES</source>
      <translation>Vertexes</translation>
    </message>
    <message>
      <source>GEOM_WATER_DENSITY</source>
      <translation>Densitatea apei :</translation>
    </message>
    <message>
      <source>GEOM_WEIGHT</source>
      <translation>Weight :</translation>
    </message>
    <message>
      <source>GEOM_WIDTH</source>
      <translation>Width :</translation>
    </message>
    <message>
      <source>GEOM_WHATIS</source>
      <translation>Whatis</translation>
    </message>
    <message>
      <source>GEOM_WHATIS_OBJECT</source>
      <translation>Object And Its Topological Information</translation>
    </message>
    <message>
      <source>GEOM_WHATIS_TITLE</source>
      <translation>Whatis Information</translation>
    </message>
    <message>
      <source>GEOM_WIRE</source>
      <translation>Wire</translation>
    </message>
    <message>
      <source>GEOM_WIRES</source>
      <translation>Wire(s)</translation>
    </message>
    <message>
      <source>GEOM_WIRES_TO_REMOVE</source>
      <translation>Wires to remove</translation>
    </message>
    <message>
      <source>GEOM_WIREZ</source>
      <translation>Wires</translation>
    </message>
    <message>
      <source>GEOM_WIRE_CONNECT</source>
      <translation>Wire creation from wires/edges connected</translation>
    </message>
    <message>
      <source>GEOM_WIRE_TITLE</source>
      <translation>Create A Wire</translation>
    </message>
    <message>
      <source>GEOM_WPLANE</source>
      <translation>Working Plane</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_FACE</source>
      <translation>Plane, Planar Face or LCS</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_ORIGIN</source>
      <translation>Selectează un plan</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_OXY</source>
      <translation>OXY</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_OYZ</source>
      <translation>OYZ</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_OZX</source>
      <translation>OZX</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_TITLE</source>
      <translation>Working Plane Selection</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_VECTOR</source>
      <translation>Select 2 vectors</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_VX</source>
      <translation>Vector X</translation>
    </message>
    <message>
      <source>GEOM_WPLANE_VZ</source>
      <translation>Vector Z</translation>
    </message>
    <message>
      <source>GEOM_WRN_RADIUS_NULL</source>
      <translation>Raza este nulă</translation>
    </message>
    <message>
      <source>GEOM_WRN_WARNING</source>
      <translation>Warning</translation>
    </message>
    <message>
      <source>GEOM_WRN_FACES_NOT_SHELL</source>
      <translation>Unable to create a shell. Result is a compound of faces.</translation>
    </message>
    <message>
      <source>WRN_SHAPE_UNCLOSED</source>
      <translation>Unable to create solid from unclosed shape %1</translation>
    </message>
    <message>
      <source>WRN_SHAPE_NOT_SHELL</source>
      <translation>Unable to create solid from shape %1 as it is not a shell</translation>
    </message>
    <message>
      <source>WRN_NULL_OBJECT_OR_SHAPE</source>
      <translation>Shape %1 for solid creation is null</translation>
    </message>
    <message>
      <source>GEOM_X</source>
      <translation>X :</translation>
    </message>
    <message>
      <source>GEOM_Y</source>
      <translation>Y :</translation>
    </message>
    <message>
      <source>GEOM_Z</source>
      <translation>Z :</translation>
    </message>
    <message>
      <source>GLUE_NEW_OBJ_NAME</source>
      <translation>Lipire</translation>
    </message>
    <message>
      <source>LIMIT_TOLERANCE_NEW_OBJ_NAME</source>
      <translation>Limit_tolerance</translation>
    </message>
    <message>
      <source>MEN_CURVE_CREATOR</source>
      <translation>Curve creator</translation>
    </message>
    <message>
      <source>TOP_CURVE_CREATOR</source>
      <translation>TOP_CURVE_CREATOR</translation>
    </message>
    <message>
      <source>STB_CURVE_CREATOR</source>
      <translation>STB_CURVE_CREATOR</translation>
    </message>
    <message>
      <source>MEN_ALL_SEL_ONLY</source>
      <translation>Selectare tot</translation>
    </message>
    <message>
      <source>MEN_ARC</source>
      <translation>Arc</translation>
    </message>
    <message>
      <source>MEN_ARCHIMEDE</source>
      <translation>Archimede</translation>
    </message>
    <message>
      <source>MEN_BASIC</source>
      <translation>Basic</translation>
    </message>
    <message>
      <source>MEN_BASIC_PROPS</source>
      <translation>Basic Properties</translation>
    </message>
    <message>
      <source>MEN_BLOCKS</source>
      <translation>Blocks</translation>
    </message>
    <message>
      <source>MEN_BND_BOX</source>
      <translation>Bounding Box</translation>
    </message>
    <message>
      <source>MEN_BOOLEAN</source>
      <translation>Boolean</translation>
    </message>
    <message>
      <source>MEN_BOX</source>
      <translation>Box</translation>
    </message>
    <message>
      <source>MEN_BUILD</source>
      <translation>Construieşte</translation>
    </message>
    <message>
      <source>MEN_FEATURE_DETECTION</source>
      <translation>Shape recognition</translation>
    </message>
    <message>
      <source>MEN_PICTURE_IMPORT</source>
      <translation>Import picture in viewer</translation>
    </message>
    <message>
      <source>MEN_CHAMFER</source>
      <translation>Chamfer</translation>
    </message>
    <message>
      <source>MEN_CHANGE_ORIENTATION</source>
      <translation>Change Orientation</translation>
    </message>
    <message>
      <source>MEN_CHECK</source>
      <translation>Check Shape</translation>
    </message>
    <message>
      <source>MEN_CHECK_COMPOUND</source>
      <translation>Check Compound of Blocks</translation>
    </message>
    <message>
      <source>MEN_GET_NON_BLOCKS</source>
      <translation>Get Non Blocks</translation>
    </message>
    <message>
      <source>MEN_CHECK_SELF_INTERSECTIONS</source>
      <translation>Detect Self-intersections</translation>
    </message>
    <message>
      <source>MEN_CHECK_FREE_BNDS</source>
      <translation>Verificare frontiere libere</translation>
    </message>
    <message>
      <source>MEN_CHECK_FREE_FACES</source>
      <translation>Check Free Faces</translation>
    </message>
    <message>
      <source>MEN_CHECK_GEOMETRY</source>
      <translation>Verificare geometrie</translation>
    </message>
    <message>
      <source>MEN_CIRCLE</source>
      <translation>Circle</translation>
    </message>
    <message>
      <source>MEN_CLIPPING</source>
      <translation>Clipping Range</translation>
    </message>
    <message>
      <source>MEN_CLOSE_CONTOUR</source>
      <translation>Contur închis</translation>
    </message>
    <message>
      <source>MEN_COMMON</source>
      <translation>Comun</translation>
    </message>
    <message>
      <source>MEN_COMPOUND</source>
      <translation>Compound</translation>
    </message>
    <message>
      <source>MEN_COMPOUND_SEL_ONLY</source>
      <translation>Compound</translation>
    </message>
    <message>
      <source>MEN_CONE</source>
      <translation>Cone</translation>
    </message>
    <message>
      <source>MEN_CURVE</source>
      <translation>Curbă</translation>
    </message>
    <message>
      <source>MEN_CUT</source>
      <translation>Tăiere</translation>
    </message>
    <message>
      <source>MEN_CYLINDER</source>
      <translation>Cylinder</translation>
    </message>
    <message>
      <source>MEN_RECTANGLE</source>
      <translation>Rectangle</translation>
    </message>
    <message>
      <source>MEN_DELETE</source>
      <translation>Şterge</translation>
    </message>
    <message>
      <source>MEN_DIMENSIONS</source>
      <translation>Dimensions</translation>
    </message>
    <message>
      <source>MEN_DISPLAY</source>
      <translation>Show</translation>
    </message>
    <message>
      <source>MEN_DISK</source>
      <translation>Disk</translation>
    </message>
    <message>
      <source>MEN_DISPLAY_ALL</source>
      <translation>Arată tot</translation>
    </message>
    <message>
      <source>MEN_DISPLAY_MODE</source>
      <translation>Display Mode</translation>
    </message>
    <message>
      <source>MEN_DISPLAY_ONLY</source>
      <translation>Arată doar</translation>
    </message>
    <message>
      <source>MEN_SHOW_ONLY_CHILDREN</source>
      <translation>Show Only Children</translation>
    </message>
    <message>
      <source>MEN_BRING_TO_FRONT</source>
      <translation>Bring To Front</translation>
    </message>
    <message>
      <source>TOP_BRING_TO_FRONT</source>
      <translation>Bring To Front</translation>
    </message>
    <message>
      <source>STB_BRING_TO_FRONT</source>
      <translation>Bring To Front</translation>
    </message>
    <message>
      <source>MEN_CLS_BRING_TO_FRONT</source>
      <translation>Clear Top Level State</translation>
    </message>
    <message>
      <source>TOP_CLS_BRING_TO_FRONT</source>
      <translation>Clear Top Level State</translation>
    </message>
    <message>
      <source>STB_CLS_BRING_TO_FRONT</source>
      <translation>Clear Top Level State</translation>
    </message>
    <message>
      <source>MEN_EDGE</source>
      <translation>Muchie</translation>
    </message>
    <message>
      <source>MEN_EDGE_SEL_ONLY</source>
      <translation>Muchie</translation>
    </message>
    <message>
      <source>MEN_EDIT</source>
      <translation>Edit</translation>
    </message>
    <message>
      <source>MEN_ELLIPSE</source>
      <translation>Ellipsă</translation>
    </message>
    <message>
      <source>MEN_ERASE</source>
      <translation>Hide</translation>
    </message>
    <message>
      <source>MEN_ERASE_ALL</source>
      <translation>Ascunde tot</translation>
    </message>
    <message>
      <source>MEN_EXPLODE</source>
      <translation>Explodare</translation>
    </message>
    <message>
      <source>MEN_EXPLODE_BLOCKS</source>
      <translation>Explodare în blocuri</translation>
    </message>
    <message>
      <source>MEN_EXPORT</source>
      <translation>Exportare...</translation>
    </message>
    <message>
      <source>MEN_EXTRUSION</source>
      <translation>Extrusion</translation>
    </message>
    <message>
      <source>MEN_EXTRUDED_CUT</source>
      <translation>Extruded cut</translation>
    </message>
    <message>
      <source>MEN_EXTRUDED_BOSS</source>
      <translation>Extruded boss</translation>
    </message>
    <message>
      <source>MEN_FACE</source>
      <translation>Faţă</translation>
    </message>
    <message>
      <source>MEN_FACE_SEL_ONLY</source>
      <translation>Faţă</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>File</translation>
    </message>
    <message>
      <source>MEN_FILLET</source>
      <translation>Fillet 3D</translation>
    </message>
    <message>
      <source>MEN_FILLET_1D</source>
      <translation>Fillet 1D</translation>
    </message>
    <message>
      <source>MEN_FILLET_2D</source>
      <translation>Fillet 2D</translation>
    </message>
    <message>
      <source>MEN_FILLING</source>
      <translation>Filling</translation>
    </message>
    <message>
      <source>MEN_FUSE</source>
      <translation>Fuse</translation>
    </message>
    <message>
      <source>MEN_GENERATION</source>
      <translation>Generare</translation>
    </message>
    <message>
      <source>MEN_GLUE_FACES</source>
      <translation>Lipire feţe</translation>
    </message>
    <message>
      <source>MEN_GLUE_EDGES</source>
      <translation>Lipire muchii</translation>
    </message>
    <message>
      <source>MEN_GROUP</source>
      <translation>Grupă</translation>
    </message>
    <message>
      <source>MEN_GROUP_CREATE</source>
      <translation>Creare grupă</translation>
    </message>
    <message>
      <source>MEN_GROUP_EDIT</source>
      <translation>Editare grupă</translation>
    </message>
    <message>
      <source>MEN_GROUP_UNION</source>
      <translation>Union Groups</translation>
    </message>
    <message>
      <source>MEN_GROUP_INTERSECT</source>
      <translation>Intersectare grupe</translation>
    </message>
    <message>
      <source>MEN_GROUP_CUT</source>
      <translation>Tăiere grupe</translation>
    </message>
    <message>
      <source>MEN_FIELD</source>
      <translation>Cîmp</translation>
    </message>
    <message>
      <source>MEN_FIELD_CREATE</source>
      <translation>Crează un cîmp</translation>
    </message>
    <message>
      <source>MEN_FIELD_EDIT</source>
      <translation>Adaugă cîmp</translation>
    </message>
    <message>
      <source>MEN_ADD_FIELD_STEP</source>
      <translation>Add Field Step</translation>
    </message>
    <message>
      <source>MEN_RELOAD_IMPORTED</source>
      <translation>Reload From Disk</translation>
    </message>
    <message>
      <source>MEN_HEX_SOLID</source>
      <translation>Hexahedral Solid</translation>
    </message>
    <message>
      <source>MEN_IMPORT</source>
      <translation>Importă...</translation>
    </message>
    <message>
      <source>MEN_INERTIA</source>
      <translation>Inerţia</translation>
    </message>
    <message>
      <source>MEN_ISOS</source>
      <translation>Isos</translation>
    </message>
    <message>
      <source>MEN_LIMIT_TOLERANCE</source>
      <translation>Limitare  toleranţă</translation>
    </message>
    <message>
      <source>MEN_LINE</source>
      <translation>Line</translation>
    </message>
    <message>
      <source>MEN_LOCAL_CS</source>
      <translation>Sistemul local de coordonate</translation>
    </message>
    <message>
      <source>MEN_MASS_CENTER</source>
      <translation>Centru de masă</translation>
    </message>
    <message>
      <source>MEN_MEASURES</source>
      <translation>Măsurări</translation>
    </message>
    <message>
      <source>MEN_MIN_DIST</source>
      <translation>Distanţa min</translation>
    </message>
    <message>
      <source>MEN_MIRROR</source>
      <translation>Mirror Image</translation>
    </message>
    <message>
      <source>MEN_MODIFY_LOCATION</source>
      <translation>Modify Location</translation>
    </message>
    <message>
      <source>MEN_MUL_ROTATION</source>
      <translation>Multi-Rotation</translation>
    </message>
    <message>
      <source>MEN_MUL_TRANSFORM</source>
      <translation>Multi-Transformation</translation>
    </message>
    <message>
      <source>MEN_MUL_TRANSLATION</source>
      <translation>Multi-Translation</translation>
    </message>
    <message>
      <source>MEN_NEW_ENTITY</source>
      <translation>New Entity</translation>
    </message>
    <message>
      <source>MEN_OFFSET</source>
      <translation>Offset Surface</translation>
    </message>
    <message>
      <source>MEN_PROJECTION</source>
      <translation>Projection</translation>
    </message>
    <message>
      <source>MEN_OPERATIONS</source>
      <translation>Operaţii</translation>
    </message>
    <message>
      <source>MEN_ORIGIN_AND_VECTORS</source>
      <translation>Origin and Base Vectors</translation>
    </message>
    <message>
      <source>MEN_PARTITION</source>
      <translation>Partition</translation>
    </message>
    <message>
      <source>MEN_PIPE</source>
      <translation>Extrusion Along Path</translation>
    </message>
    <message>
      <source>MEN_PIPE_PATH</source>
      <translation>Restore Path</translation>
    </message>
    <message>
      <source>MEN_PLANE</source>
      <translation>Plan</translation>
    </message>
    <message>
      <source>MEN_POINT</source>
      <translation>Point</translation>
    </message>
    <message>
      <source>MEN_POINT_COORDS</source>
      <translation>Point Coordinates</translation>
    </message>
    <message>
      <source>MEN_POINT_ON_EDGE</source>
      <translation>Adaugare punc la muchie</translation>
    </message>
    <message>
      <source>MEN_POP_COLOR</source>
      <translation>Color</translation>
    </message>
    <message>
      <source>MEN_POP_CREATE_GROUP</source>
      <translation>Creare grupă</translation>
    </message>
    <message>
      <source>MEN_POP_EDIT_FIELD</source>
      <translation>Editare cîmp</translation>
    </message>
    <message>
      <source>MEN_POP_DISCLOSE_CHILDREN</source>
      <translation>Disclose child items</translation>
    </message>
    <message>
      <source>MEN_POP_CONCEAL_CHILDREN</source>
      <translation>Conceal child items</translation>
    </message>
    <message>
      <source>MEN_POP_UNPUBLISH_OBJ</source>
      <translation>Unpublish</translation>
    </message>
    <message>
      <source>MEN_POP_PUBLISH_OBJ</source>
      <translation>Publish...</translation>
    </message>
    <message>
      <source>MEN_POP_ISOS</source>
      <translation>Isos</translation>
    </message>
    <message>
      <source>MEN_POP_DEFLECTION</source>
      <translation>Deflection Coefficient</translation>
    </message>
    <message>
      <source>MEN_POP_RENAME</source>
      <translation>Redenumeşte</translation>
    </message>
    <message>
      <source>MEN_POP_SHADING</source>
      <translation>Shading</translation>
    </message>
    <message>
      <source>MEN_POP_SHADING_WITH_EDGES</source>
      <translation>Shading With Edges</translation>
    </message>
    <message>
      <source>MEN_POP_TEXTURE</source>
      <translation>Textură</translation>
    </message>
    <message>
      <source>MEN_EDGE_WIDTH</source>
      <translation>Edge Width</translation>
    </message>
    <message>
      <source>TOP_EDGE_WIDTH</source>
      <translation>Edge Width</translation>
    </message>
    <message>
      <source>STB_EDGE_WIDTH</source>
      <translation>Edge Width</translation>
    </message>
    <message>
      <source>MEN_ISOS_WIDTH</source>
      <translation>Isos Width</translation>
    </message>
    <message>
      <source>TOP_ISOS_WIDTH</source>
      <translation>Isos Width</translation>
    </message>
    <message>
      <source>STB_ISOS_WIDTH</source>
      <translation>Isos Width</translation>
    </message>
    <message>
      <source>MEN_LINE_WIDTH</source>
      <translation>Line Width</translation>
    </message>
    <message>
      <source>MEN_POP_SETTEXTURE</source>
      <translation>Textură</translation>
    </message>
    <message>
      <source>MEN_POP_TRANSPARENCY</source>
      <translation>Transparency</translation>
    </message>
    <message>
      <source>MEN_POP_WIREFRAME</source>
      <translation>Wireframe</translation>
    </message>
    <message>
      <source>MEN_POP_VECTORS</source>
      <translation>Show Edge Direction</translation>
    </message>
    <message>
      <source>MEN_POP_VERTICES</source>
      <translation>MEN_POP_VERTICES</translation>
    </message>
    <message>
      <source>MEN_PREFERENCES</source>
      <translation>Preferences</translation>
    </message>
    <message>
      <source>MEN_PREFERENCES_GEOM</source>
      <translation>Geometry</translation>
    </message>
    <message>
      <source>MEN_PRIMITIVES</source>
      <translation>Primitives</translation>
    </message>
    <message>
      <source>MEN_ADVANCED</source>
      <translation>Advansat</translation>
    </message>
    <message>
      <source>MEN_PROPAGATE</source>
      <translation>Propagate</translation>
    </message>
    <message>
      <source>MEN_Q_FACE</source>
      <translation>Quadrangle Face</translation>
    </message>
    <message>
      <source>MEN_REPAIR</source>
      <translation>Repair</translation>
    </message>
    <message>
      <source>MEN_REVOLUTION</source>
      <translation>Revolution</translation>
    </message>
    <message>
      <source>MEN_ROTATION</source>
      <translation>Rotation</translation>
    </message>
    <message>
      <source>MEN_SCALE</source>
      <translation>Scale Transform</translation>
    </message>
    <message>
      <source>MEN_SECTION</source>
      <translation>Selecţie</translation>
    </message>
    <message>
      <source>MEN_SELECT_ONLY</source>
      <translation>Selectare doar</translation>
    </message>
    <message>
      <source>MEN_SEWING</source>
      <translation>Sewing</translation>
    </message>
    <message>
      <source>MEN_SHADING</source>
      <translation>Shading</translation>
    </message>
    <message>
      <source>MEN_SHADING_WITH_EDGES</source>
      <translation>Shading With Edges</translation>
    </message>
    <message>
      <source>MEN_SHADING_COLOR</source>
      <translation>Shading Color</translation>
    </message>
    <message>
      <source>MEN_SHAPE_PROCESS</source>
      <translation>Shape Processing</translation>
    </message>
    <message>
      <source>MEN_SHELL</source>
      <translation>Membrană</translation>
    </message>
    <message>
      <source>MEN_SHELL_SEL_ONLY</source>
      <translation>Membrană</translation>
    </message>
    <message>
      <source>MEN_SKETCH</source>
      <translation>2D Sketch</translation>
    </message>
    <message>
      <source>MEN_3DSKETCH</source>
      <translation>3D Sketch</translation>
    </message>
    <message>
      <source>MEN_ISOLINE</source>
      <translation>Isolinie</translation>
    </message>
    <message>
      <source>MEN_SOLID</source>
      <translation>Solid</translation>
    </message>
    <message>
      <source>MEN_SOLID_SEL_ONLY</source>
      <translation>Solid</translation>
    </message>
    <message>
      <source>MEN_SPHERE</source>
      <translation>Sferă</translation>
    </message>
    <message>
      <source>MEN_STEP_VALUE</source>
      <translation>Step Value</translation>
    </message>
    <message>
      <source>MEN_SUPPERSS_HOLES</source>
      <translation>Suppress Holes</translation>
    </message>
    <message>
      <source>MEN_SUPPRESS_FACES</source>
      <translation>Suppress Faces</translation>
    </message>
    <message>
      <source>MEN_SUPPRESS_INT_WIRES</source>
      <translation>Suppress Internal Wires</translation>
    </message>
    <message>
      <source>MEN_TOLERANCE</source>
      <translation>Tolerance</translation>
    </message>
    <message>
      <source>MEN_TOOLS</source>
      <translation>Tools</translation>
    </message>
    <message>
      <source>MEN_MATERIALS_LIBRARY</source>
      <translation>Materials library</translation>
    </message>
    <message>
      <source>MEN_TEXTURE</source>
      <translation>Textură</translation>
    </message>
    <message>
      <source>MEN_TORUS</source>
      <translation>Torus</translation>
    </message>
    <message>
      <source>MEN_TRANSFORMATION</source>
      <translation>Transformation</translation>
    </message>
    <message>
      <source>MEN_TRANSLATION</source>
      <translation>Translation</translation>
    </message>
    <message>
      <source>MEN_VECTOR</source>
      <translation>Vector</translation>
    </message>
    <message>
      <source>MEN_VERTEX_SEL_ONLY</source>
      <translation>Vertex</translation>
    </message>
    <message>
      <source>MEN_VIEW</source>
      <translation>View</translation>
    </message>
    <message>
      <source>MEN_WHAT_IS</source>
      <translation>What is</translation>
    </message>
    <message>
      <source>MEN_WIRE</source>
      <translation>Wire</translation>
    </message>
    <message>
      <source>MEN_VECTOR_MODE_ON</source>
      <translation>Show Edge Direction</translation>
    </message>
    <message>
      <source>MEN_VECTOR_MODE_OFF</source>
      <translation>Hide Edge Direction</translation>
    </message>
    <message>
      <source>MEN_VERTICES_MODE_ON</source>
      <translation>MEN_VERTICES_MODE_ON</translation>
    </message>
    <message>
      <source>MEN_VERTICES_MODE_OFF</source>
      <translation>MEN_VERTICES_MODE_OFF</translation>
    </message>
    <message>
      <source>MEN_WIREFRAME</source>
      <translation>Wireframe</translation>
    </message>
    <message>
      <source>MEN_WIRE_SEL_ONLY</source>
      <translation>Wire</translation>
    </message>
    <message>
      <source>MEN_WORK_PLANE</source>
      <translation>Working Plane</translation>
    </message>
    <message>
      <source>MEN_POP_POINT_MARKER</source>
      <translation>Point Marker</translation>
    </message>
    <message>
      <source>MEN_POP_MATERIAL_PROPERTIES</source>
      <translation>Material Properties</translation>
    </message>
    <message>
      <source>MEN_POP_PREDEF_MATER_CUSTOM</source>
      <translation>Custom...</translation>
    </message>
    <message>
      <source>NAME_LBL</source>
      <translation>Nume:</translation>
    </message>
    <message>
      <source>NON_GEOM_OBJECTS_SELECTED</source>
      <translation>There are objects selected which do not belong to %1 component.</translation>
    </message>
    <message>
      <source>PREF_DEFLECTION</source>
      <translation>Deflection coefficient</translation>
    </message>
    <message>
      <source>GEOM_PREF_def_precision</source>
      <translation>Default precision</translation>
    </message>
    <message>
      <source>GEOM_PREF_length_precision</source>
      <translation>Length precision</translation>
    </message>
    <message>
      <source>GEOM_PREF_angle_precision</source>
      <translation>Angular precision</translation>
    </message>
    <message>
      <source>GEOM_PREF_len_tol_precision</source>
      <translation>Length tolerance precision</translation>
    </message>
    <message>
      <source>GEOM_PREF_ang_tol_precision</source>
      <translation>Angular tolerance precision</translation>
    </message>
    <message>
      <source>GEOM_PREF_weight_precision</source>
      <translation>Weight precision</translation>
    </message>
    <message>
      <source>GEOM_PREF_density_precision</source>
      <translation>Density precision</translation>
    </message>
    <message>
      <source>GEOM_PREF_parametric_precision</source>
      <translation>Precizie parametrică</translation>
    </message>
    <message>
      <source>GEOM_PREF_param_tol_precision</source>
      <translation>Parametric tolerance precision</translation>
    </message>
    <message>
      <source>PREF_AUTO_CREATE</source>
      <translation>Auto create</translation>
    </message>
    <message>
      <source>PREF_DISPLAY_MODE</source>
      <translation>Default display mode</translation>
    </message>
    <message>
      <source>PREF_TRANSPARENCY</source>
      <translation>PREF_TRANSPARENCY</translation>
    </message>
    <message>
      <source>PREF_FREE_BOUND_COLOR</source>
      <translation>Color of free boundaries</translation>
    </message>
    <message>
      <source>PREF_GROUP_ORIGIN_AND_BASE_VECTORS</source>
      <translation>Origin and base vectors</translation>
    </message>
    <message>
      <source>PREF_GROUP_OPERATIONS</source>
      <translation>Operaţii</translation>
    </message>
    <message>
      <source>PREF_GROUP_GENERAL</source>
      <translation>General</translation>
    </message>
    <message>
      <source>GEOM_PREF_GROUP_PRECISION</source>
      <translation>Input fields precision</translation>
    </message>
    <message>
      <source>PREF_GROUP_VERTEX</source>
      <translation>Marker of Points</translation>
    </message>
    <message>
      <source>PREF_ISOS_COLOR</source>
      <translation>Color of isolines</translation>
    </message>
    <message>
      <source>PREF_TOPLEVEL_COLOR</source>
      <translation>Top level color</translation>
    </message>
    <message>
      <source>PREF_TOPLEVEL_DM</source>
      <translation>Top level display mode</translation>
    </message>
    <message>
      <source>MEN_KEEP_CURRENT_DM</source>
      <translation>Keep current display mode</translation>
    </message>
    <message>
      <source>MEN_SHOW_ADD_WACTOR</source>
      <translation>Show additional wireframe actor</translation>
    </message>
    <message>
      <source>PREF_LINE_COLOR</source>
      <translation>Color of edges, vectors, wires</translation>
    </message>
    <message>
      <source>PREF_MARKER_SCALE</source>
      <translation>Size</translation>
    </message>
    <message>
      <source>PREF_POINT_COLOR</source>
      <translation>Culoarea punctelor</translation>
    </message>
    <message>
      <source>PREF_SHADING_COLOR</source>
      <translation>Default shading color</translation>
    </message>
    <message>
      <source>PREF_EDGES_IN_SHADING</source>
      <translation>Edges in shading</translation>
    </message>
    <message>
      <source>PREF_STEP_VALUE</source>
      <translation>Step value for spin boxes</translation>
    </message>
    <message>
      <source>PREF_TAB_SETTINGS</source>
      <translation>Settings</translation>
    </message>
    <message>
      <source>PREF_TYPE_OF_MARKER</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>PREF_BASE_VECTORS_LENGTH</source>
      <translation>Length of base vectors</translation>
    </message>
    <message>
      <source>PREF_WIREFRAME_COLOR</source>
      <translation>Default wireframe color</translation>
    </message>
    <message>
      <source>PREF_MATERIAL</source>
      <translation>Materialul implicit</translation>
    </message>
    <message>
      <source>PREF_PREDEF_MATERIALS</source>
      <translation>Show predefined materials in popup menu</translation>
    </message>
    <message>
      <source>PREF_EDITGROUP_COLOR</source>
      <translation>Subshapes color for editing a group</translation>
    </message>
    <message>
      <source>PREF_EDGE_WIDTH</source>
      <translation>Edges width</translation>
    </message>
    <message>
      <source>PREF_ISOLINES_WIDTH</source>
      <translation>Iso lines width</translation>
    </message>
    <message>
      <source>PREF_PREVIEW_EDGE_WIDTH</source>
      <translation>Preview edges width</translation>
    </message>
    <message>
      <source>PREF_MEASURES_LINE_WIDTH</source>
      <translation>Measures lines width</translation>
    </message>
    <message>
      <source>PREF_AUTO_BRING_TO_FRONT</source>
      <translation>Automatic bring to front</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS</source>
      <translation>Dimensions (Measurements)</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_COLOR</source>
      <translation>Culoarea</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_LINE_WIDTH</source>
      <translation>Line width</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_FONT_HEIGHT</source>
      <translation>Înălţimea fontului</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_ARROW_LENGTH</source>
      <translation>Length of arrows</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_LENGTH_UNITS</source>
      <translation>Length measurement units</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_ANGLE_UNITS</source>
      <translation>Angle measurement units</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_DEFAULT_FLYOUT</source>
      <translation>Default flyout length</translation>
    </message>
    <message>
      <source>PREF_DIMENSIONS_SHOW_UNITS</source>
      <translation>Show units of measurement</translation>
    </message>
    <message>
      <source>PREF_ISOS</source>
      <translation>Number of isolines</translation>
    </message>
    <message>
      <source>PREF_ISOS_U</source>
      <translation>Along U</translation>
    </message>
    <message>
      <source>PREF_ISOS_V</source>
      <translation>Along V</translation>
    </message>
    <message>
      <source>PREF_GROUP_SCALAR_BAR</source>
      <translation>Scalar bar for field step presentation</translation>
    </message>
    <message>
      <source>PREF_SCALAR_BAR_X_POSITION</source>
      <translation>X position</translation>
    </message>
    <message>
      <source>PREF_SCALAR_BAR_Y_POSITION</source>
      <translation>Y position</translation>
    </message>
    <message>
      <source>PREF_SCALAR_BAR_WIDTH</source>
      <translation>Width</translation>
    </message>
    <message>
      <source>PREF_SCALAR_BAR_HEIGHT</source>
      <translation>Înălţimea</translation>
    </message>
    <message>
      <source>PREF_SCALAR_BAR_TEXT_HEIGHT</source>
      <translation>Înălţimea textului</translation>
    </message>
    <message>
      <source>PREF_SCALAR_BAR_NUMBER_OF_INTERVALS</source>
      <translation>Numărul de intervale</translation>
    </message>
    <message>
      <source>PROCESS_SHAPE_NEW_OBJ_NAME</source>
      <translation>ProcessShape</translation>
    </message>
    <message>
      <source>MATERIAL_LIBRARY_TLT</source>
      <translation>Materials Library</translation>
    </message>
    <message>
      <source>REMOVE_HOLES_NEW_OBJ_NAME</source>
      <translation>SupressHoles</translation>
    </message>
    <message>
      <source>REMOVE_INT_WIRES_NEW_OBJ_NAME</source>
      <translation>RemoveIntWires</translation>
    </message>
    <message>
      <source>SEWING_NEW_OBJ_NAME</source>
      <translation>Sewing</translation>
    </message>
    <message>
      <source>STB_ALL_SEL_ONLY</source>
      <translation>Selectarea la toate obiectele</translation>
    </message>
    <message>
      <source>STB_ARC</source>
      <translation>Creare arc</translation>
    </message>
    <message>
      <source>STB_ARCHIMEDE</source>
      <translation>Archimede operation</translation>
    </message>
    <message>
      <source>STB_BASIC_PROPS</source>
      <translation>Show basic properties of the shape</translation>
    </message>
    <message>
      <source>STB_BND_BOX</source>
      <translation>Compute bounding box of the shape</translation>
    </message>
    <message>
      <source>STB_BOX</source>
      <translation>Create a box</translation>
    </message>
    <message>
      <source>STB_FEATURE_DETECTION</source>
      <translation>Shape recognition</translation>
    </message>
    <message>
      <source>STB_PICTURE_IMPORT</source>
      <translation>Import picture in viewer</translation>
    </message>
    <message>
      <source>STB_CHAMFER</source>
      <translation>Create a chamfer</translation>
    </message>
    <message>
      <source>STB_CHANGE_ORIENTATION</source>
      <translation>Schimbă orientarea</translation>
    </message>
    <message>
      <source>STB_CHECK</source>
      <translation>Check shape validity</translation>
    </message>
    <message>
      <source>STB_CHECK_COMPOUND</source>
      <translation>Check compound of blocks</translation>
    </message>
    <message>
      <source>STB_GET_NON_BLOCKS</source>
      <translation>Get non blocks</translation>
    </message>
    <message>
      <source>STB_CHECK_SELF_INTERSECTIONS</source>
      <translation>Detect Self-intersections</translation>
    </message>
    <message>
      <source>STB_CHECK_FREE_BNDS</source>
      <translation>Check free boundaries</translation>
    </message>
    <message>
      <source>STB_CHECK_FREE_FACES</source>
      <translation>Check free faces</translation>
    </message>
    <message>
      <source>STB_CHECK_GEOMETRY</source>
      <translation>Verificare geometrie</translation>
    </message>
    <message>
      <source>STB_CIRCLE</source>
      <translation>Creare cerc</translation>
    </message>
    <message>
      <source>STB_CLIPPING</source>
      <translation>Clipping range</translation>
    </message>
    <message>
      <source>STB_CLOSE_CONTOUR</source>
      <translation>Perform close contour</translation>
    </message>
    <message>
      <source>STB_COMMON</source>
      <translation>Comun</translation>
    </message>
    <message>
      <source>STB_COMPOUND</source>
      <translation>Build a compound</translation>
    </message>
    <message>
      <source>STB_COMPOUND_SEL_ONLY</source>
      <translation>Select only a Compounds</translation>
    </message>
    <message>
      <source>STB_CONE</source>
      <translation>Creare con</translation>
    </message>
    <message>
      <source>STB_CURVE</source>
      <translation>Creare curbă</translation>
    </message>
    <message>
      <source>STB_CUT</source>
      <translation>Cut</translation>
    </message>
    <message>
      <source>STB_CYLINDER</source>
      <translation>Creare cilindru</translation>
    </message>
    <message>
      <source>STB_RECTANGLE</source>
      <translation>Creare faţă rectangulară</translation>
    </message>
    <message>
      <source>STB_DELETE</source>
      <translation>Şterge obiectul</translation>
    </message>
    <message>
      <source>STB_DISK</source>
      <translation>Create a disk</translation>
    </message>
    <message>
      <source>STB_DISPLAY</source>
      <translation>Arată obiectul(ele)</translation>
    </message>
    <message>
      <source>STB_DISPLAY_ALL</source>
      <translation>Arată tot</translation>
    </message>
    <message>
      <source>STB_DISPLAY_ONLY</source>
      <translation>Show only</translation>
    </message>
    <message>
      <source>STB_SHOW_ONLY_CHILDREN</source>
      <translation>Show Only Children</translation>
    </message>
    <message>
      <source>STB_EDGE</source>
      <translation>Construire muchie</translation>
    </message>
    <message>
      <source>STB_EDGE_SEL_ONLY</source>
      <translation>Select only a Edges</translation>
    </message>
    <message>
      <source>STB_ELLIPSE</source>
      <translation>Creare elipsă</translation>
    </message>
    <message>
      <source>STB_ERASE</source>
      <translation>Ascunde obiectul(le)</translation>
    </message>
    <message>
      <source>STB_ERASE_ALL</source>
      <translation>Ascunde tot</translation>
    </message>
    <message>
      <source>STB_EXPLODE</source>
      <translation>Explodare</translation>
    </message>
    <message>
      <source>STB_EXPLODE_BLOCKS</source>
      <translation>Explode on Blocks</translation>
    </message>
    <message>
      <source>STB_EXTRUSION</source>
      <translation>Create an extrusion</translation>
    </message>
    <message>
      <source>STB_EXTRUDED_CUT</source>
      <translation>Extruded cut</translation>
    </message>
    <message>
      <source>STB_EXTRUDED_BOSS</source>
      <translation>Extruded boss</translation>
    </message>
    <message>
      <source>STB_FACE</source>
      <translation>Construieşte o faţă</translation>
    </message>
    <message>
      <source>STB_FACE_SEL_ONLY</source>
      <translation>Select only a Faces</translation>
    </message>
    <message>
      <source>STB_FILLET</source>
      <translation>Create 3D fillet</translation>
    </message>
    <message>
      <source>STB_FILLET_1D</source>
      <translation>Create 1D fillet</translation>
    </message>
    <message>
      <source>STB_FILLET_2D</source>
      <translation>Create 2D fillet</translation>
    </message>
    <message>
      <source>STB_FILLING</source>
      <translation>Create a filling</translation>
    </message>
    <message>
      <source>STB_FUSE</source>
      <translation>Fuse</translation>
    </message>
    <message>
      <source>STB_GLUE_FACES</source>
      <translation>Perform glue faces</translation>
    </message>
    <message>
      <source>STB_GLUE_EDGES</source>
      <translation>Perform glue edges</translation>
    </message>
    <message>
      <source>STB_GROUP_CREATE</source>
      <translation>Creare grupă</translation>
    </message>
    <message>
      <source>STB_GROUP_EDIT</source>
      <translation>Editare grupă</translation>
    </message>
    <message>
      <source>STB_GROUP_UNION</source>
      <translation>Union Groups</translation>
    </message>
    <message>
      <source>STB_GROUP_INTERSECT</source>
      <translation>Intersectare grupe</translation>
    </message>
    <message>
      <source>STB_GROUP_CUT</source>
      <translation>Tăiere grupe</translation>
    </message>
    <message>
      <source>STB_FIELD_CREATE</source>
      <translation>Create a Field</translation>
    </message>
    <message>
      <source>STB_FIELD_EDIT</source>
      <translation>Edit a Field</translation>
    </message>
    <message>
      <source>STB_RELOAD_IMPORTED</source>
      <translation>Reload imported shape from its original place on disk</translation>
    </message>
    <message>
      <source>STB_HEX_SOLID</source>
      <translation>Hexahedral Solid</translation>
    </message>
    <message>
      <source>STB_INERTIA</source>
      <translation>Compute moments of intertia of the shape</translation>
    </message>
    <message>
      <source>STB_ISOS</source>
      <translation>Set number of isolines</translation>
    </message>
    <message>
      <source>STB_LINE</source>
      <translation>Creare linie</translation>
    </message>
    <message>
      <source>STB_LIMIT_TOLERANCE</source>
      <translation>Limitare toleranţă</translation>
    </message>
    <message>
      <source>STB_LOCAL_CS</source>
      <translation>Creare sistem local de coordonate</translation>
    </message>
    <message>
      <source>STB_MASS_CENTER</source>
      <translation>Compute center of mass of the shape</translation>
    </message>
    <message>
      <source>STB_MIN_DIST</source>
      <translation>Compute minimum distance between two objects</translation>
    </message>
    <message>
      <source>STB_MIRROR</source>
      <translation>Mirror a shape</translation>
    </message>
    <message>
      <source>STB_MODIFY_LOCATION</source>
      <translation>Modify shape's location</translation>
    </message>
    <message>
      <source>STB_MUL_ROTATION</source>
      <translation>Perform multi-rotation</translation>
    </message>
    <message>
      <source>STB_MUL_TRANSFORM</source>
      <translation>Perform multi-transformation</translation>
    </message>
    <message>
      <source>STB_MUL_TRANSLATION</source>
      <translation>Perform multi-translation</translation>
    </message>
    <message>
      <source>STB_OFFSET</source>
      <translation>Offset surface</translation>
    </message>
    <message>
      <source>STB_PROJECTION</source>
      <translation>Project a point, an edge or a wire on a face</translation>
    </message>
    <message>
      <source>STB_ORIGIN_AND_VECTORS</source>
      <translation>Create an origin and base Vectors</translation>
    </message>
    <message>
      <source>STB_PARTITION</source>
      <translation>Make a partition</translation>
    </message>
    <message>
      <source>STB_PIPE</source>
      <translation>Create a shape by extrusion along a path</translation>
    </message>
    <message>
      <source>STB_PIPE_PATH</source>
      <translation>Restore path from a pipe-like shape</translation>
    </message>
    <message>
      <source>STB_PLANE</source>
      <translation>Creare plan</translation>
    </message>
    <message>
      <source>STB_POINT</source>
      <translation>Creare punct</translation>
    </message>
    <message>
      <source>STB_POINT_COORDS</source>
      <translation>Display point coordinates</translation>
    </message>
    <message>
      <source>STB_POINT_ON_EDGE</source>
      <translation>Adaugă punct pe muchie</translation>
    </message>
    <message>
      <source>STB_POP_COLOR</source>
      <translation>Color</translation>
    </message>
    <message>
      <source>STB_POP_CREATE_GROUP</source>
      <translation>Creare grupă</translation>
    </message>
    <message>
      <source>STB_POP_EDIT_FIELD</source>
      <translation>Edit Field</translation>
    </message>
    <message>
      <source>STB_POP_UNPUBLISH_OBJ</source>
      <translation>Unpublish object</translation>
    </message>
    <message>
      <source>STB_POP_PUBLISH_OBJ</source>
      <translation>Publish object</translation>
    </message>
    <message>
      <source>STB_POP_DISCLOSE_CHILDREN</source>
      <translation>Disclose child items</translation>
    </message>
    <message>
      <source>STB_POP_CONCEAL_CHILDREN</source>
      <translation>Conceal child items</translation>
    </message>
    <message>
      <source>STB_POP_ISOS</source>
      <translation>Isolines</translation>
    </message>
    <message>
      <source>STB_POP_DEFLECTION</source>
      <translation>Deflection Coefficient</translation>
    </message>
    <message>
      <source>STB_POP_RENAME</source>
      <translation>Rename</translation>
    </message>
    <message>
      <source>STB_POP_SHADING</source>
      <translation>Shading</translation>
    </message>
    <message>
      <source>STB_POP_SHADING_WITH_EDGES</source>
      <translation>Shading With Edges</translation>
    </message>
    <message>
      <source>STB_POP_TEXTURE</source>
      <translation>Textură</translation>
    </message>
    <message>
      <source>STB_POP_VECTORS</source>
      <translation>Arată direcţia muchiei</translation>
    </message>
    <message>
      <source>STB_POP_VERTICES</source>
      <translation>STB_POP_VERTICES</translation>
    </message>
    <message>
      <source>STB_POP_SETTEXTURE</source>
      <translation>Adaugă textură</translation>
    </message>
    <message>
      <source>STB_POP_TRANSPARENCY</source>
      <translation>Transparency</translation>
    </message>
    <message>
      <source>STB_POP_WIREFRAME</source>
      <translation>Wireframe</translation>
    </message>
    <message>
      <source>STB_MATERIALS_LIBRARY</source>
      <translation>Displays content of Materials library</translation>
    </message>
    <message>
      <source>STB_POP_PREDEF_MATER_CUSTOM</source>
      <translation>Custom...</translation>
    </message>
    <message>
      <source>STB_PROPAGATE</source>
      <translation>Propagate</translation>
    </message>
    <message>
      <source>STB_Q_FACE</source>
      <translation>Quadrangle Face</translation>
    </message>
    <message>
      <source>STB_REVOLUTION</source>
      <translation>Create a revolution</translation>
    </message>
    <message>
      <source>STB_ROTATION</source>
      <translation>Rotate a shape</translation>
    </message>
    <message>
      <source>STB_SCALE</source>
      <translation>Scale a shape</translation>
    </message>
    <message>
      <source>STB_SECTION</source>
      <translation>Secţiune</translation>
    </message>
    <message>
      <source>STB_SEWING</source>
      <translation>Perform sewing</translation>
    </message>
    <message>
      <source>STB_WIREFRAME</source>
      <translation>Wireframe</translation>
    </message>
    <message>
      <source>STB_SHADING</source>
      <translation>Shading</translation>
    </message>
    <message>
      <source>STB_SHADING_WITH_EDGES</source>
      <translation>Shading with edges</translation>
    </message>
    <message>
      <source>STB_VECTOR_MODE</source>
      <translation>Change Edge Presentation Mode</translation>
    </message>
    <message>
      <source>STB_SHADING_COLOR</source>
      <translation>Set shading color</translation>
    </message>
    <message>
      <source>STB_SHAPE_PROCESS</source>
      <translation>Perform shape processing </translation>
    </message>
    <message>
      <source>STB_SHELL</source>
      <translation>Creare membrană</translation>
    </message>
    <message>
      <source>STB_SHELL_SEL_ONLY</source>
      <translation>Select only a Shells</translation>
    </message>
    <message>
      <source>STB_SKETCH</source>
      <translation>Create 2D sketch</translation>
    </message>
    <message>
      <source>STB_3DSKETCH</source>
      <translation>Create 3D sketch</translation>
    </message>
    <message>
      <source>STB_ISOLINE</source>
      <translation>Create U- or V-Isoline</translation>
    </message>
    <message>
      <source>STB_SOLID</source>
      <translation>Build a solid</translation>
    </message>
    <message>
      <source>STB_SOLID_SEL_ONLY</source>
      <translation>Select only a Solids</translation>
    </message>
    <message>
      <source>STB_SPHERE</source>
      <translation>Creare sferă</translation>
    </message>
    <message>
      <source>STB_STEP_VALUE</source>
      <translation>Set step value</translation>
    </message>
    <message>
      <source>STB_SUPPERSS_HOLES</source>
      <translation>Perform suppress holes</translation>
    </message>
    <message>
      <source>STB_SUPPRESS_FACES</source>
      <translation>Perform suppress faces</translation>
    </message>
    <message>
      <source>STB_SUPPRESS_INT_WIRES</source>
      <translation>Perform suppress internal wires</translation>
    </message>
    <message>
      <source>STB_TOLERANCE</source>
      <translation>Compute tolerance of the shape</translation>
    </message>
    <message>
      <source>STB_TORUS</source>
      <translation>Create a torus</translation>
    </message>
    <message>
      <source>STB_TRANSLATION</source>
      <translation>Translate shape</translation>
    </message>
    <message>
      <source>STB_VECTOR</source>
      <translation>Creare vector</translation>
    </message>
    <message>
      <source>STB_VERTEX_SEL_ONLY</source>
      <translation>Selectează doar puncte</translation>
    </message>
    <message>
      <source>STB_WHAT_IS</source>
      <translation>What is</translation>
    </message>
    <message>
      <source>STB_WIRE</source>
      <translation>Build a wire</translation>
    </message>
    <message>
      <source>STB_WIRE_SEL_ONLY</source>
      <translation>Select only a Wires</translation>
    </message>
    <message>
      <source>STB_WORK_PLANE</source>
      <translation>Create a working plane</translation>
    </message>
    <message>
      <source>STB_POP_POINT_MARKER</source>
      <translation>Set Point Marker</translation>
    </message>
    <message>
      <source>STB_POP_MATERIAL_PROPERTIES</source>
      <translation>Set Material Properties</translation>
    </message>
    <message>
      <source>SUPPRESS_RESULT</source>
      <translation>Suppress Result</translation>
    </message>
    <message>
      <source>SUPRESS_FACE_NEW_OBJ_NAME</source>
      <translation>SupressFaces</translation>
    </message>
    <message>
      <source>ShHealOper_ErrorExecution_msg</source>
      <translation>Shape Healing algorithm failed</translation>
    </message>
    <message>
      <source>ShHealOper_InvalidParameters_msg</source>
      <translation>Incorrect parameters for Shape Healing algorithm</translation>
    </message>
    <message>
      <source>ShHealOper_NotError_msg</source>
      <translation>Shape Healing algorithm has done no modification of the original shape</translation>
    </message>
    <message>
      <source>TLT_RENAME</source>
      <translation>Redenumeşte</translation>
    </message>
    <message>
      <source>TOM_O</source>
      <translation>O</translation>
    </message>
    <message>
      <source>TOM_O_PLUS</source>
      <translation>+ in O</translation>
    </message>
    <message>
      <source>TOM_O_POINT</source>
      <translation>. in O</translation>
    </message>
    <message>
      <source>TOM_O_STAR</source>
      <translation>* in O</translation>
    </message>
    <message>
      <source>TOM_O_X</source>
      <translation>X in O</translation>
    </message>
    <message>
      <source>TOM_PLUS</source>
      <translation>+</translation>
    </message>
    <message>
      <source>TOM_POINT</source>
      <translation>.</translation>
    </message>
    <message>
      <source>TOM_STAR</source>
      <translation>*</translation>
    </message>
    <message>
      <source>TOM_X</source>
      <translation>X</translation>
    </message>
    <message>
      <source>TOP_ARC</source>
      <translation>Creare arc</translation>
    </message>
    <message>
      <source>TOP_ARCHIMEDE</source>
      <translation>Archimede</translation>
    </message>
    <message>
      <source>TOP_BASIC_PROPS</source>
      <translation>Basic properties</translation>
    </message>
    <message>
      <source>TOP_BND_BOX</source>
      <translation>Bounding box</translation>
    </message>
    <message>
      <source>TOP_BOX</source>
      <translation>Create a box</translation>
    </message>
    <message>
      <source>TOP_CHAMFER</source>
      <translation>Chamfer</translation>
    </message>
    <message>
      <source>TOP_CHANGE_ORIENTATION</source>
      <translation>Change orientation</translation>
    </message>
    <message>
      <source>TOP_CHECK</source>
      <translation>Check shape</translation>
    </message>
    <message>
      <source>TOP_CHECK_COMPOUND</source>
      <translation>Check compound of blocks</translation>
    </message>
    <message>
      <source>TOP_GET_NON_BLOCKS</source>
      <translation>Get non blocks</translation>
    </message>
    <message>
      <source>TOP_CHECK_SELF_INTERSECTIONS</source>
      <translation>Detect Self-intersections</translation>
    </message>
    <message>
      <source>TOP_CHECK_FREE_BNDS</source>
      <translation>Check free boundaries</translation>
    </message>
    <message>
      <source>TOP_CHECK_FREE_FACES</source>
      <translation>Check free faces</translation>
    </message>
    <message>
      <source>TOP_CHECK_GEOMETRY</source>
      <translation>Verificare geometrie</translation>
    </message>
    <message>
      <source>TOP_CIRCLE</source>
      <translation>Creare cerc</translation>
    </message>
    <message>
      <source>TOP_CLIPPING</source>
      <translation>Clipping range</translation>
    </message>
    <message>
      <source>TOP_CLOSE_CONTOUR</source>
      <translation>Perform close contour</translation>
    </message>
    <message>
      <source>TOP_COMMON</source>
      <translation>Comun</translation>
    </message>
    <message>
      <source>TOP_COMPOUND</source>
      <translation>Build compound</translation>
    </message>
    <message>
      <source>TOP_CONE</source>
      <translation>Creare con</translation>
    </message>
    <message>
      <source>TOP_CURVE</source>
      <translation>Creare curbă</translation>
    </message>
    <message>
      <source>TOP_CUT</source>
      <translation>Cut</translation>
    </message>
    <message>
      <source>TOP_CYLINDER</source>
      <translation>Creare cilindru</translation>
    </message>
    <message>
      <source>TOP_DELETE</source>
      <translation>Şterge obiect</translation>
    </message>
    <message>
      <source>TOP_RECTANGLE</source>
      <translation>Create rectangular face</translation>
    </message>
    <message>
      <source>TOP_DISK</source>
      <translation>Create a disk</translation>
    </message>
    <message>
      <source>TOP_DISPLAY</source>
      <translation>Show</translation>
    </message>
    <message>
      <source>TOP_DISPLAY_ALL</source>
      <translation>Arată tot</translation>
    </message>
    <message>
      <source>TOP_DISPLAY_ONLY</source>
      <translation>Arată doar</translation>
    </message>
    <message>
      <source>TOP_SHOW_ONLY_CHILDREN</source>
      <translation>Show Only Children</translation>
    </message>
    <message>
      <source>TOP_EDGE</source>
      <translation>Construieşte muchie</translation>
    </message>
    <message>
      <source>TOP_ELLIPSE</source>
      <translation>Creare elipsă</translation>
    </message>
    <message>
      <source>TOP_ERASE</source>
      <translation>Hide</translation>
    </message>
    <message>
      <source>TOP_ERASE_ALL</source>
      <translation>Ascunde tot</translation>
    </message>
    <message>
      <source>TOP_EXPLODE</source>
      <translation>Explodare</translation>
    </message>
    <message>
      <source>TOP_EXPLODE_BLOCKS</source>
      <translation>Explodare în blocuri</translation>
    </message>
    <message>
      <source>TOP_EXTRUSION</source>
      <translation>Create an extrusion</translation>
    </message>
    <message>
      <source>TOP_EXTRUDED_BOSS</source>
      <translation>Extruded boss</translation>
    </message>
    <message>
      <source>TOP_EXTRUDED_CUT</source>
      <translation>Extruded cut</translation>
    </message>
    <message>
      <source>TOP_FACE</source>
      <translation>Construire faţă</translation>
    </message>
    <message>
      <source>TOP_FILLET</source>
      <translation>Fillet 3D</translation>
    </message>
    <message>
      <source>TOP_FILLET_1D</source>
      <translation>Fillet 1D</translation>
    </message>
    <message>
      <source>TOP_FILLET_2D</source>
      <translation>Fillet 2D</translation>
    </message>
    <message>
      <source>TOP_FILLING</source>
      <translation>Create a filling</translation>
    </message>
    <message>
      <source>TOP_FUSE</source>
      <translation>Fuse</translation>
    </message>
    <message>
      <source>TOP_GLUE_FACES</source>
      <translation>Perform glue faces</translation>
    </message>
    <message>
      <source>TOP_GLUE_EDGES</source>
      <translation>Perform glue edges</translation>
    </message>
    <message>
      <source>TOP_GROUP_CREATE</source>
      <translation>Creare grupă</translation>
    </message>
    <message>
      <source>TOP_GROUP_EDIT</source>
      <translation>Editare grupă</translation>
    </message>
    <message>
      <source>TOP_GROUP_UNION</source>
      <translation>Union Groups</translation>
    </message>
    <message>
      <source>TOP_GROUP_INTERSECT</source>
      <translation>Intersect Groups</translation>
    </message>
    <message>
      <source>TOP_GROUP_CUT</source>
      <translation>Cut Groups</translation>
    </message>
    <message>
      <source>TOP_FIELD_CREATE</source>
      <translation>Create a Field</translation>
    </message>
    <message>
      <source>TOP_FIELD_EDIT</source>
      <translation>Edit a Field</translation>
    </message>
    <message>
      <source>TOP_HEX_SOLID</source>
      <translation>Hexahedral Solid</translation>
    </message>
    <message>
      <source>TOP_INERTIA</source>
      <translation>Momente de inerţie</translation>
    </message>
    <message>
      <source>TOP_ISOS</source>
      <translation>Set number of isolines</translation>
    </message>
    <message>
      <source>TOP_LINE</source>
      <translation>Creare linie</translation>
    </message>
    <message>
      <source>TOP_LIMIT_TOLERANCE</source>
      <translation>Limitare toleranţă</translation>
    </message>
    <message>
      <source>TOP_LOCAL_CS</source>
      <translation>Crearea unui sistem local de coordonate</translation>
    </message>
    <message>
      <source>TOP_MASS_CENTER</source>
      <translation>Center of mass</translation>
    </message>
    <message>
      <source>TOP_MIN_DIST</source>
      <translation>Minimum distance</translation>
    </message>
    <message>
      <source>TOP_MIRROR</source>
      <translation>Mirror image</translation>
    </message>
    <message>
      <source>TOP_MODIFY_LOCATION</source>
      <translation>Modify location</translation>
    </message>
    <message>
      <source>TOP_MUL_ROTATION</source>
      <translation>Multi-Rotation</translation>
    </message>
    <message>
      <source>TOP_MUL_TRANSFORM</source>
      <translation>Multi-transformation</translation>
    </message>
    <message>
      <source>TOP_MUL_TRANSLATION</source>
      <translation>Multi-Translation</translation>
    </message>
    <message>
      <source>TOP_PICTURE_IMPORT</source>
      <translation>Import picture in viewer</translation>
    </message>
    <message>
      <source>TOP_FEATURE_DETECTION</source>
      <translation>Shape recognition</translation>
    </message>
    <message>
      <source>TOP_OFFSET</source>
      <translation>Offset surface</translation>
    </message>
    <message>
      <source>TOP_PROJECTION</source>
      <translation>Projection</translation>
    </message>
    <message>
      <source>TOP_ORIGIN_AND_VECTORS</source>
      <translation>Create an origin and base Vectors</translation>
    </message>
    <message>
      <source>TOP_PARTITION</source>
      <translation>Partiţie</translation>
    </message>
    <message>
      <source>TOP_PIPE</source>
      <translation>Extrusion along path</translation>
    </message>
    <message>
      <source>TOP_PIPE_PATH</source>
      <translation>Restore path</translation>
    </message>
    <message>
      <source>TOP_PLANE</source>
      <translation>Creare plan</translation>
    </message>
    <message>
      <source>TOP_POINT</source>
      <translation>Creare punct</translation>
    </message>
    <message>
      <source>TOP_POINT_COORDS</source>
      <translation>Coordonatele punctului</translation>
    </message>
    <message>
      <source>TOP_POINT_ON_EDGE</source>
      <translation>Adaugă un punct pe muchie</translation>
    </message>
    <message>
      <source>TOP_POP_COLOR</source>
      <translation>Color</translation>
    </message>
    <message>
      <source>TOP_POP_CREATE_GROUP</source>
      <translation>Creare grupă</translation>
    </message>
    <message>
      <source>TOP_POP_EDIT_FIELD</source>
      <translation>Editare câmp</translation>
    </message>
    <message>
      <source>TOP_POP_UNPUBLISH_OBJ</source>
      <translation>Unpublish object</translation>
    </message>
    <message>
      <source>TOP_POP_PUBLISH_OBJ</source>
      <translation>Publicare obiect</translation>
    </message>
    <message>
      <source>TOP_POP_DISCLOSE_CHILDREN</source>
      <translation>Disclose child items</translation>
    </message>
    <message>
      <source>TOP_POP_CONCEAL_CHILDREN</source>
      <translation>Conceal child items</translation>
    </message>
    <message>
      <source>TOP_POP_ISOS</source>
      <translation>Isolines</translation>
    </message>
    <message>
      <source>TOP_POP_DEFLECTION</source>
      <translation>Deflection Coefficient</translation>
    </message>
    <message>
      <source>TOP_POP_RENAME</source>
      <translation>Rename</translation>
    </message>
    <message>
      <source>TOP_POP_SHADING</source>
      <translation>Shading</translation>
    </message>
    <message>
      <source>TOP_POP_SHADING_WITH_EDGES</source>
      <translation>Shading With Edges</translation>
    </message>
    <message>
      <source>TOP_POP_SETTEXTURE</source>
      <translation>Textură</translation>
    </message>
    <message>
      <source>TOP_POP_TRANSPARENCY</source>
      <translation>Transparency</translation>
    </message>
    <message>
      <source>TOP_POP_WIREFRAME</source>
      <translation>Wireframe</translation>
    </message>
    <message>
      <source>TOP_PROPAGATE</source>
      <translation>Propagate</translation>
    </message>
    <message>
      <source>TOP_Q_FACE</source>
      <translation>Quadrangle Face</translation>
    </message>
    <message>
      <source>TOP_REVOLUTION</source>
      <translation>Create a revolution</translation>
    </message>
    <message>
      <source>TOP_ROTATION</source>
      <translation>Rotation</translation>
    </message>
    <message>
      <source>TOP_SCALE</source>
      <translation>Scale transform</translation>
    </message>
    <message>
      <source>TOP_SECTION</source>
      <translation>Secţiune</translation>
    </message>
    <message>
      <source>TOP_SEWING</source>
      <translation>Perform sewing</translation>
    </message>
    <message>
      <source>TOP_SHADING</source>
      <translation>Shading</translation>
    </message>
    <message>
      <source>TOP_SHADING_COLOR</source>
      <translation>Set shading color</translation>
    </message>
    <message>
      <source>TOP_SHAPE_PROCESS</source>
      <translation>Perform shape processing</translation>
    </message>
    <message>
      <source>TOP_SHELL</source>
      <translation>Build shell</translation>
    </message>
    <message>
      <source>TOP_SKETCH</source>
      <translation>2D sketch</translation>
    </message>
    <message>
      <source>TOP_3DSKETCH</source>
      <translation>3D sketch</translation>
    </message>
    <message>
      <source>TOP_ISOLINE</source>
      <translation>Isoline</translation>
    </message>
    <message>
      <source>TOP_SOLID</source>
      <translation>Build solid</translation>
    </message>
    <message>
      <source>TOP_SPHERE</source>
      <translation>Create a sphere</translation>
    </message>
    <message>
      <source>TOP_STEP_VALUE</source>
      <translation>Set step value</translation>
    </message>
    <message>
      <source>TOP_SUPPERSS_HOLES</source>
      <translation>Perform suppress holes</translation>
    </message>
    <message>
      <source>TOP_SUPPRESS_FACES</source>
      <translation>Perform suppress faces</translation>
    </message>
    <message>
      <source>TOP_SUPPRESS_INT_WIRES</source>
      <translation>Perform suppress internal wires</translation>
    </message>
    <message>
      <source>TOP_TOLERANCE</source>
      <translation>Tolerance</translation>
    </message>
    <message>
      <source>TOP_TORUS</source>
      <translation>Create a torus</translation>
    </message>
    <message>
      <source>TOP_TRANSLATION</source>
      <translation>Translation</translation>
    </message>
    <message>
      <source>TOP_VECTOR</source>
      <translation>Creare vector</translation>
    </message>
    <message>
      <source>TOP_WHAT_IS</source>
      <translation>What is</translation>
    </message>
    <message>
      <source>TOP_WIRE</source>
      <translation>Build wire</translation>
    </message>
    <message>
      <source>TOP_WORK_PLANE</source>
      <translation>Create a working plane</translation>
    </message>
    <message>
      <source>TOP_POP_POINT_MARKER</source>
      <translation>Point Marker</translation>
    </message>
    <message>
      <source>TOP_POP_MATERIAL_PROPERTIES</source>
      <translation>Material Properties</translation>
    </message>
    <message>
      <source>WRN_NOT_IMPLEMENTED</source>
      <translation>Sorry, this functionality is not yet implemented</translation>
    </message>
    <message>
      <source>_S_</source>
      <translation>(s)</translation>
    </message>
    <message>
      <source>NOT_FOUND_ANY</source>
      <translation>Not a single entity has been found</translation>
    </message>
    <message>
      <source>GEOM_FACE_I</source>
      <translation>Faţa %1</translation>
    </message>
    <message>
      <source>GEOM_CONSTANT_RADIUS</source>
      <translation>Radius :</translation>
    </message>
    <message>
      <source>GEOM_R1</source>
      <translation>R1 :</translation>
    </message>
    <message>
      <source>GEOM_R2</source>
      <translation>R2 :</translation>
    </message>
    <message>
      <source>GEOM_BOTHWAY</source>
      <translation>Both Directions</translation>
    </message>
    <message>
      <source>GEOM_NORMALE</source>
      <translation>Normal To A Face</translation>
    </message>
    <message>
      <source>GEOM_VECTOR_NORMALE</source>
      <translation>Vector_Normal</translation>
    </message>
    <message>
      <source>GEOM_LINE1</source>
      <translation>Linie 1</translation>
    </message>
    <message>
      <source>GEOM_LINE2</source>
      <translation>Linie 2</translation>
    </message>
    <message>
      <source>GEOM_D</source>
      <translation>D :</translation>
    </message>
    <message>
      <source>GEOM_CHAMFER_EDGE</source>
      <translation>Chamfer On Edge common with 2 Faces</translation>
    </message>
    <message>
      <source>SELECTED_EDGE</source>
      <translation>Muchiile selectate</translation>
    </message>
    <message>
      <source>GEOM_NORMALE_TITLE</source>
      <translation>Create Normal To A Face</translation>
    </message>
    <message>
      <source>GEOM_MEASURE_ANGLE_TITLE</source>
      <translation>Angle Between Two Straight Edges/Lines/Vectors</translation>
    </message>
    <message>
      <source>GEOM_MEASURE_ANGLE_ANGLE</source>
      <translation>unghi</translation>
    </message>
    <message>
      <source>GEOM_MEASURE_ANGLE_OBJ</source>
      <translation>Obiectele şi rezultatele</translation>
    </message>
    <message>
      <source>GEOM_MEASURE_ANGLE_DEG</source>
      <translation>Unghiul în grade :</translation>
    </message>
    <message>
      <source>GEOM_MEASURE_ANGLE_RAD</source>
      <translation>Unghiul în radiani :</translation>
    </message>
    <message>
      <source>GEOM_LINE_INTERSECTION</source>
      <translation>Point On Lines Intersection</translation>
    </message>
    <message>
      <source>GEOM_KEEP_NONLIMIT_SHAPES</source>
      <translation>Keep shapes of lower type</translation>
    </message>
    <message>
      <source>GEOM_NO_SELF_INTERSECTION</source>
      <translation>No sub-shapes intersection (Compounds only)</translation>
    </message>
    <message>
      <source>GEOM_CENTER_2POINTS</source>
      <translation>Center and two points</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_WEBS_TITLE</source>
      <translation>Remove internal faces</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_WEBS</source>
      <translation>Compound of solids</translation>
    </message>
    <message>
      <source>REMOVE_WEBS_NEW_OBJ_NAME</source>
      <translation>NoInternalFaces</translation>
    </message>
    <message>
      <source>TOP_REMOVE_WEBS</source>
      <translation>Remove internal faces</translation>
    </message>
    <message>
      <source>MEN_REMOVE_WEBS</source>
      <translation>Remove Internal Faces</translation>
    </message>
    <message>
      <source>STB_REMOVE_WEBS</source>
      <translation>Remove internal faces</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_EXTRA_EDGES_TITLE</source>
      <translation>Remove extra edges</translation>
    </message>
    <message>
      <source>GEOM_BOOL_REMOVE_EXTRA_EDGES</source>
      <translation>Remove extra edges</translation>
    </message>
    <message>
      <source>GEOM_REMOVE_EXTRA_EDGES</source>
      <translation>Object to remove extra edges</translation>
    </message>
    <message>
      <source>GEOM_RMEE_UNION_FACES</source>
      <translation>Union faces, laying on common surface</translation>
    </message>
    <message>
      <source>REMOVE_EXTRA_EDGES_NEW_OBJ_NAME</source>
      <translation>NoExtraEdges</translation>
    </message>
    <message>
      <source>TOP_REMOVE_EXTRA_EDGES</source>
      <translation>Remove extra edges</translation>
    </message>
    <message>
      <source>MEN_REMOVE_EXTRA_EDGES</source>
      <translation>Remove Extra Edges</translation>
    </message>
    <message>
      <source>STB_REMOVE_EXTRA_EDGES</source>
      <translation>Remove extra edges</translation>
    </message>
    <message>
      <source>GEOM_FUSE_EDGES_TITLE</source>
      <translation>Fuse Collinear Edges within a Wire</translation>
    </message>
    <message>
      <source>GEOM_FUSE_EDGES</source>
      <translation>Fuse edges</translation>
    </message>
    <message>
      <source>FUSE_EDGES_NEW_OBJ_NAME</source>
      <translation>FuseEdges</translation>
    </message>
    <message>
      <source>TOP_FUSE_EDGES</source>
      <translation>Fuse collinear edges within a wire</translation>
    </message>
    <message>
      <source>MEN_FUSE_EDGES</source>
      <translation>Fuse Collinear Edges within a Wire</translation>
    </message>
    <message>
      <source>STB_FUSE_EDGES</source>
      <translation>Fuse collinear edges within a wire</translation>
    </message>
    <message>
      <source>TOP_UNION_FACES</source>
      <translation>Union faces</translation>
    </message>
    <message>
      <source>MEN_UNION_FACES</source>
      <translation>Union Faces</translation>
    </message>
    <message>
      <source>STB_UNION_FACES</source>
      <translation>Union faces</translation>
    </message>
    <message>
      <source>TOP_NORMALE</source>
      <translation>Normal to a face</translation>
    </message>
    <message>
      <source>MEN_NORMALE</source>
      <translation>Normal to a Face</translation>
    </message>
    <message>
      <source>STB_NORMALE</source>
      <translation>Compute normal to the face</translation>
    </message>
    <message>
      <source>TOP_MEASURE_ANGLE</source>
      <translation>Unghiul</translation>
    </message>
    <message>
      <source>MEN_MEASURE_ANGLE</source>
      <translation>Unghiul</translation>
    </message>
    <message>
      <source>STB_MEASURE_ANGLE</source>
      <translation>Compute angle between two lines or linear edges</translation>
    </message>
    <message>
      <source>TOP_MANAGE_DIMENSIONS</source>
      <translation>Manage dimensions</translation>
    </message>
    <message>
      <source>MEN_MANAGE_DIMENSIONS</source>
      <translation>Manage dimensions</translation>
    </message>
    <message>
      <source>STB_MANAGE_DIMENSIONS</source>
      <translation>Manage measurement dimensions of an object</translation>
    </message>
    <message>
      <source>MEN_POP_SHOW_DEPENDENCY_TREE</source>
      <translation>MEN_POP_SHOW_DEPENDENCY_TREE</translation>
    </message>
    <message>
      <source>MEN_POP_REDUCE_STUDY</source>
      <translation>MEN_POP_REDUCE_STUDY</translation>
    </message>
    <message>
      <source>MEN_POP_SHOW_ALL_DIMENSIONS</source>
      <translation>Show all dimensions</translation>
    </message>
    <message>
      <source>STB_POP_SHOW_ALL_DIMENSIONS</source>
      <translation>Show all hidden measures (dimension) created for the object</translation>
    </message>
    <message>
      <source>TOP_POP_SHOW_ALL_DIMENSIONS</source>
      <translation>Show all hidden measures (dimension) created for the object</translation>
    </message>
    <message>
      <source>MEN_POP_HIDE_ALL_DIMENSIONS</source>
      <translation>Hide all dimensions</translation>
    </message>
    <message>
      <source>STB_POP_HIDE_ALL_DIMENSIONS</source>
      <translation>Show all visible measures (dimension) created for the object</translation>
    </message>
    <message>
      <source>TOP_POP_HIDE_ALL_DIMENSIONS</source>
      <translation>Show all visible measures (dimension) created for the object</translation>
    </message>
    <message>
      <source>TOP_POP_AUTO_COLOR</source>
      <translation>Culoare automată</translation>
    </message>
    <message>
      <source>MEN_POP_AUTO_COLOR</source>
      <translation>Culoare automată</translation>
    </message>
    <message>
      <source>STB_POP_AUTO_COLOR</source>
      <translation>Culoare automată</translation>
    </message>
    <message>
      <source>TOP_POP_DISABLE_AUTO_COLOR</source>
      <translation>Întrerupe culoarea automată</translation>
    </message>
    <message>
      <source>MEN_POP_DISABLE_AUTO_COLOR</source>
      <translation>Întrerupe culoarea automată</translation>
    </message>
    <message>
      <source>STB_POP_DISABLE_AUTO_COLOR</source>
      <translation>Întrerupe culoarea automată</translation>
    </message>
    <message>
      <source>MEN_POP_CREATE_FOLDER</source>
      <translation>Creare fişier</translation>
    </message>
    <message>
      <source>STB_POP_CREATE_FOLDER</source>
      <translation>Crearea unui nou fişier</translation>
    </message>
    <message>
      <source>NEW_FOLDER_NAME</source>
      <translation>FişierNou</translation>
    </message>
    <message>
      <source>MEN_POP_SORT_CHILD_ITEMS</source>
      <translation>Sort children</translation>
    </message>
    <message>
      <source>STB_POP_SORT_CHILD_ITEMS</source>
      <translation>Sort child items</translation>
    </message>
    <message>
      <source>GEOM_RESULT_NAME_GRP</source>
      <translation>Numele rezultat</translation>
    </message>
    <message>
      <source>GEOM_RESULT_NAME_LBL</source>
      <translation>Nume</translation>
    </message>
    <message>
      <source>GEOM_FILLING_APPROX</source>
      <translation>Aproximare</translation>
    </message>
    <message>
      <source>GEOM_FILLING_METHOD</source>
      <translation>Metodă</translation>
    </message>
    <message>
      <source>GEOM_FILLING_DEFAULT</source>
      <translation>Default (standard behaviour)</translation>
    </message>
    <message>
      <source>GEOM_FILLING_USEORI</source>
      <translation>Use edges orientation</translation>
    </message>
    <message>
      <source>GEOM_FILLING_AUTO</source>
      <translation>Auto-correct edges orientation</translation>
    </message>
    <message>
      <source>GEOM_WRN_NO_APPROPRIATE_SELECTION</source>
      <translation>No appropriate objects selected</translation>
    </message>
    <message>
      <source>GEOM_SHAPES_ON_SHAPE</source>
      <translation>Get shapes on shape</translation>
    </message>
    <message>
      <source>GEOM_SHAPES_ON_SHAPE_ESHAPE</source>
      <translation>Shape for exploding</translation>
    </message>
    <message>
      <source>GEOM_SHAPES_ON_SHAPE_CSHAPE</source>
      <translation>Solid for checking</translation>
    </message>
    <message>
      <source>GEOM_SHAPES_ON_SHAPE_STATE</source>
      <translation>State</translation>
    </message>
    <message>
      <source>GEOM_KIND_OF_SHAPE</source>
      <translation>Kind of Shape :</translation>
    </message>
    <message>
      <source>GEOM_CLOSED</source>
      <translation>Closed</translation>
    </message>
    <message>
      <source>GEOM_UNCLOSED</source>
      <translation>Opened</translation>
    </message>
    <message>
      <source>GEOM_CLOSEDUNCLOSED</source>
      <translation>Not defined, Closed or Opened. Possibly, error occured.</translation>
    </message>
    <message>
      <source>GEOM_DISK_CIRCLE</source>
      <translation>Disk</translation>
    </message>
    <message>
      <source>GEOM_DISK_ELLIPSE</source>
      <translation>Elliptical face</translation>
    </message>
    <message>
      <source>GEOM_PLANAR_FACE</source>
      <translation>Planar Face</translation>
    </message>
    <message>
      <source>GEOM_PLANAR_EDGE_WIRE</source>
      <translation>Wire with Planar Edges</translation>
    </message>
    <message>
      <source>GEOM_POLYGON</source>
      <translation>Polygon</translation>
    </message>
    <message>
      <source>GEOM_POLYHEDRON</source>
      <translation>Polyhedron</translation>
    </message>
    <message>
      <source>GEOM_NORMAL</source>
      <translation>Normal direction</translation>
    </message>
    <message>
      <source>GEOM_DIRECTION</source>
      <translation>Direcţie</translation>
    </message>
    <message>
      <source>GEOM_UPARAMETER</source>
      <translation>U-parameter :</translation>
    </message>
    <message>
      <source>GEOM_VPARAMETER</source>
      <translation>V-parameter :</translation>
    </message>
    <message>
      <source>GEOM_X_I</source>
      <translation>X%1 :</translation>
    </message>
    <message>
      <source>GEOM_Y_I</source>
      <translation>Y%1 :</translation>
    </message>
    <message>
      <source>GEOM_Z_I</source>
      <translation>Z%1 :</translation>
    </message>
    <message>
      <source>GEOM_SHAPES_ON_SHAPE_TITLE</source>
      <translation>Get shapes on shape</translation>
    </message>
    <message>
      <source>GEOM_SCALE_FACTOR_X</source>
      <translation>Scale Factor X :</translation>
    </message>
    <message>
      <source>GEOM_SCALE_FACTOR_Y</source>
      <translation>Scale Factor Y :</translation>
    </message>
    <message>
      <source>GEOM_SCALE_FACTOR_Z</source>
      <translation>Scale Factor Z :</translation>
    </message>
    <message>
      <source>GEOM_STATE_IN</source>
      <translation>IN</translation>
    </message>
    <message>
      <source>GEOM_STATE_OUT</source>
      <translation>OUT</translation>
    </message>
    <message>
      <source>GEOM_STATE_ON</source>
      <translation>ON</translation>
    </message>
    <message>
      <source>GEOM_STATE_ONIN</source>
      <translation>ONIN</translation>
    </message>
    <message>
      <source>GEOM_STATE_ONOUT</source>
      <translation>ONOUT</translation>
    </message>
    <message>
      <source>GEOM_STATE_INOUT</source>
      <translation>INOUT</translation>
    </message>
    <message>
      <source>TOP_GET_SHAPES_ON_SHAPE</source>
      <translation>Get shapes on shape</translation>
    </message>
    <message>
      <source>MEN_GET_SHAPES_ON_SHAPE</source>
      <translation>Get Shapes on Shape</translation>
    </message>
    <message>
      <source>STB_GET_SHAPES_ON_SHAPE</source>
      <translation>Get shapes on shape</translation>
    </message>
    <message>
      <source>TOP_GET_SHARED_SHAPES</source>
      <translation>Get shared shapes</translation>
    </message>
    <message>
      <source>MEN_GET_SHARED_SHAPES</source>
      <translation>Get Shared Shapes</translation>
    </message>
    <message>
      <source>STB_GET_SHARED_SHAPES</source>
      <translation>Get shared shapes</translation>
    </message>
    <message>
      <source>GEOM_PUBLISH_RESULT_GRP</source>
      <translation>Advanced options</translation>
    </message>
    <message>
      <source>GEOM_RESTORE_SUB_SHAPES</source>
      <translation>Set presentation parameters and sub-shapes from arguments</translation>
    </message>
    <message>
      <source>GEOM_RSS_ADD_FREFIX</source>
      <translation>Add prefix to names of restored sub-shapes</translation>
    </message>
    <message>
      <source>GEOM_PREVIEW</source>
      <translation>Preview</translation>
    </message>
    <message>
      <source>PREF_TAB_DEPENDENCY_VIEW</source>
      <translation>PREF_TAB_DEPENDENCY_VIEW</translation>
    </message>
    <message>
      <source>PREF_HIERARCHY_TYPE</source>
      <translation>PREF_HIERARCHY_TYPE</translation>
    </message>
    <message>
      <source>MEN_ONLY_ASCENDANTS</source>
      <translation>MEN_ONLY_ASCENDANTS</translation>
    </message>
    <message>
      <source>MEN_ONLY_DESCENDANTS</source>
      <translation>MEN_ONLY_DESCENDANTS</translation>
    </message>
    <message>
      <source>MEN_BOTH_ASCENDANTS_DESCENDANTS</source>
      <translation>MEN_BOTH_ASCENDANTS_DESCENDANTS</translation>
    </message>
    <message>
      <source>GEOM_MOVE_POSSIBILITY</source>
      <translation>GEOM_MOVE_POSSIBILITY</translation>
    </message>
    <message>
      <source>PREF_GROUP_DEPENDENCY_VIEW_COLOR</source>
      <translation>PREF_GROUP_DEPENDENCY_VIEW_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_BACKGROUND_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_BACKGROUND_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_NODE_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_NODE_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_MAIN_NODE_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_MAIN_NODE_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_UNPUBLISH_NODE_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_UNPUBLISH_NODE_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_SELECT_NODE_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_SELECT_NODE_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_ARROW_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_ARROW_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_HIGHLIGHT_ARROW_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_HIGHLIGHT_ARROW_COLOR</translation>
    </message>
    <message>
      <source>PREF_DEPENDENCY_VIEW_SELECT_ARROW_COLOR</source>
      <translation>PREF_DEPENDENCY_VIEW_SELECT_ARROW_COLOR</translation>
    </message>
    <message>
      <source>GEOM_ALL_IMPORT_FILES</source>
      <translation>Toate formatele suportate ( %1 )</translation>
    </message>
    <message>
      <source>GEOM_UNSUPPORTED_TYPE</source>
      <translation>Unsupported format for the file</translation>
    </message>
    <message>
      <source>GEOM_UNKNOWN_IMPORT_ERROR</source>
      <translation>Unknown error</translation>
    </message>
    <message>
      <source>GEOM_IMPORT_ERRORS</source>
      <translation>Import operation has finished with errors:</translation>
    </message>
    <message>
      <source>EXPORT_IGES_HETEROGENEOUS_COMPOUND</source>
      <translation>This compound cannot be exported in IGES format without loss, because it contains entities, that must be saved in different modes. It is vertices, edges and wires on the one hand and shells and solids on the other hand.</translation>
    </message>
    <message>
      <source>GEOM_PUBLISH_NAMED_SHAPES</source>
      <translation>Create groups for named shapes (if there are any)?</translation>
    </message>
    <message>
      <source>GEOM_PRECISION_HINT</source>
      <translation>Input value precision can be adjusted using '%1' parameter in Geometry module preferences.</translation>
    </message>
    <message>
      <source>GEOM_PLUGINS_OTHER</source>
      <translation>Altele</translation>
    </message>
    <message>
      <source>SHOW_ONLY_SELECTED</source>
      <translation>Show only selected</translation>
    </message>
    <message>
      <source>HIDE_SELECTED</source>
      <translation>Hide selected</translation>
    </message>
    <message>
      <source>SHOW_ALL_SUB_SHAPES</source>
      <translation>Show all sub-shapes</translation>
    </message>
    <message>
      <source>TOP_SMOOTHINGSURFACE</source>
      <translation>Smoothing Surface</translation>
    </message>
    <message>
      <source>GEOM_SELECT_IMAGE</source>
      <translation>Select image...</translation>
    </message>
    <message>
      <source>CC_PNT_ITEM_X_Y</source>
      <translation>X=%1, Y=%2</translation>
    </message>
    <message>
      <source>CC_PNT_ITEM_X_Y_Z</source>
      <translation>X=%1, Y=%2, Z=%3</translation>
    </message>
  </context>
  <context>
    <name>GeometryGUI</name>
    <message>
      <source>TOOL_BASIC</source>
      <translation>TOOL_BASIC</translation>
    </message>
    <message>
      <source>TOOL_BLOCKS</source>
      <translation>TOOL_BLOCKS</translation>
    </message>
    <message>
      <source>TOOL_BOOLEAN</source>
      <translation>TOOL_BOOLEAN</translation>
    </message>
    <message>
      <source>TOOL_FEATURES</source>
      <translation>TOOL_FEATURES</translation>
    </message>
    <message>
      <source>TOOL_GENERATION</source>
      <translation>TOOL_GENERATION</translation>
    </message>
    <message>
      <source>TOOL_PRIMITIVES</source>
      <translation>TOOL_PRIMITIVES</translation>
    </message>
    <message>
      <source>TOOL_TRANSFORMATION</source>
      <translation>TOOL_TRANSFORMATION</translation>
    </message>
    <message>
      <source>TOOL_BUILD</source>
      <translation>TOOL_BUILD</translation>
    </message>
    <message>
      <source>TOOL_OPERATIONS</source>
      <translation>TOOL_OPERATIONS</translation>
    </message>
    <message>
      <source>TOOL_PICTURES</source>
      <translation>TOOL_PICTURES</translation>
    </message>
    <message>
      <source>TOOL_ADVANCED</source>
      <translation>TOOL_ADVANCED</translation>
    </message>
    <message>
      <source>TOOL_MEASURES</source>
      <translation>TOOL_MEASURES</translation>
    </message>
    <message>
      <source>TOOL_IMPORTEXPORT</source>
      <translation>TOOL_IMPORTEXPORT</translation>
    </message>
    <message>
      <source>TABLE_SECTION</source>
      <translation>TABLE_SECTION</translation>
    </message>
    <message>
      <source>TABLE_INDEX</source>
      <translation>TABLE_INDEX</translation>
    </message>
    <message>
      <source>TABLE_X</source>
      <translation>TABLE_X</translation>
    </message>
    <message>
      <source>TABLE_Y</source>
      <translation>TABLE_Y</translation>
    </message>
  </context>
  <context>
    <name>BasicGUI_CurveDlg</name>
    <message>
      <source>GEOM_IS_CLOSED</source>
      <translation>Build a closed edge</translation>
    </message>
    <message>
      <source>GEOM_BUILD_CLOSED_WIRE</source>
      <translation>Build a closed wire</translation>
    </message>
    <message>
      <source>GEOM_IS_REORDER</source>
      <translation>Reorder vertices taking into account distances</translation>
    </message>
    <message>
      <source>GEOM_INTERPOL_TANGENTS</source>
      <translation>Tangents</translation>
    </message>
    <message>
      <source>GEOM_INTERPOL_FIRST_VEC</source>
      <translation>First tangent vector</translation>
    </message>
    <message>
      <source>GEOM_INTERPOL_LAST_VEC</source>
      <translation>Last tangent vector</translation>
    </message>
    <message>
      <source>GEOM_BOTH_TANGENTS_REQUIRED</source>
      <translation>Both tangent vectors must be defined</translation>
    </message>
    <message>
      <source>GEOM_CURVE_CRMODE</source>
      <translation>Creation Mode</translation>
    </message>
    <message>
      <source>GEOM_CURVE_SELECTION</source>
      <translation>By Selection</translation>
    </message>
    <message>
      <source>GEOM_CURVE_ANALITICAL</source>
      <translation>Analitic</translation>
    </message>
  </context>
  <context>
    <name>BasicGUI_ParamCurveWidget</name>
    <message>
      <source>GEOM_PCURVE_TITLE</source>
      <translation>Curve parameters</translation>
    </message>
    <message>
      <source>GEOM_PCURVE_X</source>
      <translation>X(t) equation</translation>
    </message>
    <message>
      <source>GEOM_PCURVE_Y</source>
      <translation>Y(t) equation</translation>
    </message>
    <message>
      <source>GEOM_PCURVE_Z</source>
      <translation>Z(t) equation</translation>
    </message>
    <message>
      <source>GEOM_PCURVE_MIN</source>
      <translation>Min t</translation>
    </message>
    <message>
      <source>GEOM_PCURVE_MAX</source>
      <translation>Max t</translation>
    </message>
    <message>
      <source>GEOM_PCURVE_STEP</source>
      <translation>Step</translation>
    </message>
    <message>
      <source>GEOM_PCURVE_NBSTEP</source>
      <translation>Number of steps</translation>
    </message>
  </context>
  <context>
    <name>BasicGUI_EllipseDlg</name>
    <message>
      <source>GEOM_VECTOR_MAJOR</source>
      <translation>Major Axis</translation>
    </message>
    <message>
      <source>ORIGIN_DEFAULT</source>
      <translation>Origin by default</translation>
    </message>
    <message>
      <source>X_AXIS_DEFAULT</source>
      <translation>X axis by default</translation>
    </message>
    <message>
      <source>Z_AXIS_DEFAULT</source>
      <translation>Z axis by default</translation>
    </message>
  </context>
  <context>
    <name>BasicGUI_MarkerDlg</name>
    <message>
      <source>CAPTION</source>
      <translation>Local CS Construction</translation>
    </message>
    <message>
      <source>DX</source>
      <translation>Dx</translation>
    </message>
    <message>
      <source>DY</source>
      <translation>Dy</translation>
    </message>
    <message>
      <source>DZ</source>
      <translation>Dz</translation>
    </message>
    <message>
      <source>LCS_NAME</source>
      <translation>LocalCS</translation>
    </message>
    <message>
      <source>LOCALCS</source>
      <translation>Local coordinate system</translation>
    </message>
    <message>
      <source>ORIGIN</source>
      <translation>Coordinatele de la origine</translation>
    </message>
    <message>
      <source>VEC_PARALLEL</source>
      <translation>Coordinate system axes cannot be parallel</translation>
    </message>
    <message>
      <source>XDIR</source>
      <translation>X axis direction</translation>
    </message>
    <message>
      <source>YDIR</source>
      <translation>Y axis direction</translation>
    </message>
  </context>
  <context>
    <name>BlocksGUI_BlockDlg</name>
    <message>
      <source>FACE_1</source>
      <translation>Faţa 1</translation>
    </message>
    <message>
      <source>FACE_2</source>
      <translation>Faţa 2</translation>
    </message>
    <message>
      <source>FACE_3</source>
      <translation>Faţa 3</translation>
    </message>
    <message>
      <source>FACE_4</source>
      <translation>Faţa 4</translation>
    </message>
    <message>
      <source>FACE_5</source>
      <translation>Face 5</translation>
    </message>
    <message>
      <source>FACE_6</source>
      <translation>Faţa 6</translation>
    </message>
  </context>
  <context>
    <name>BlocksGUI_ExplodeDlg</name>
    <message>
      <source>NB_FACES_MAX</source>
      <translation>Max. nb. faces</translation>
    </message>
    <message>
      <source>NB_FACES_MIN</source>
      <translation>Min. nb. faces</translation>
    </message>
  </context>
  <context>
    <name>BlocksGUI_QuadFaceDlg</name>
    <message>
      <source>EDGE_1</source>
      <translation>Muchia 1</translation>
    </message>
    <message>
      <source>EDGE_2</source>
      <translation>Muchia 2</translation>
    </message>
    <message>
      <source>EDGE_3</source>
      <translation>Muchia 3</translation>
    </message>
    <message>
      <source>EDGE_4</source>
      <translation>Muchia 4</translation>
    </message>
    <message>
      <source>VERTEX_1</source>
      <translation>Vertex 1</translation>
    </message>
    <message>
      <source>VERTEX_2</source>
      <translation>Vertex 2</translation>
    </message>
    <message>
      <source>VERTEX_3</source>
      <translation>Vertex 3</translation>
    </message>
    <message>
      <source>VERTEX_4</source>
      <translation>Vertex 4</translation>
    </message>
  </context>
  <context>
    <name>BlocksGUI_TrsfDlg</name>
    <message>
      <source>FACE_1</source>
      <translation>Faţa 1</translation>
    </message>
    <message>
      <source>FACE_1U</source>
      <translation>Faţa 1 U</translation>
    </message>
    <message>
      <source>FACE_1V</source>
      <translation>Faţa 1 V</translation>
    </message>
    <message>
      <source>FACE_2</source>
      <translation>Faţa 2</translation>
    </message>
    <message>
      <source>FACE_2U</source>
      <translation>Faţa 2 U</translation>
    </message>
    <message>
      <source>FACE_2V</source>
      <translation>Faţa 2 V</translation>
    </message>
  </context>
  <context>
    <name>CurveCreator_NewSectionDlg</name>
    <message>
      <source>SECTION_NAME</source>
      <translation>SECTION_NAME</translation>
    </message>
    <message>
      <source>SECTION_LINE_TYPE</source>
      <translation>SECTION_LINE_TYPE</translation>
    </message>
    <message>
      <source>SECTION_POLYLINE_TYPE</source>
      <translation>SECTION_POLYLINE_TYPE</translation>
    </message>
    <message>
      <source>SECTION_SPLINE_TYPE</source>
      <translation>SECTION_SPLINE_TYPE</translation>
    </message>
    <message>
      <source>SECTION_LINE_CLOSED</source>
      <translation>SECTION_LINE_CLOSED</translation>
    </message>
    <message>
      <source>SECTION_ADD_BTN</source>
      <translation>SECTION_ADD_BTN</translation>
    </message>
    <message>
      <source>SECTION_OK_BTN</source>
      <translation>SECTION_OK_BTN</translation>
    </message>
    <message>
      <source>SECTION_CANCEL_BTN</source>
      <translation>SECTION_CANCEL_BTN</translation>
    </message>
    <message>
      <source>ADD_NEW_SECTION</source>
      <translation>Adaugă o nouă secţiune</translation>
    </message>
    <message>
      <source>SET_SECTION_PARAMETERS</source>
      <translation>Set section parameters</translation>
    </message>
  </context>
  <context>
    <name>CurveCreator_TreeViewModel</name>
    <message>
      <source>X=%1, Y=%2</source>
      <translation>X=%1, Y=%2</translation>
    </message>
    <message>
      <source>X=%1, Y=%2, Z=%3</source>
      <translation>X=%1, Y=%2, Z=%3</translation>
    </message>
  </context>
  <context>
    <name>CurveCreator_Widget</name>
    <message>
      <source>SECTION_GROUP_TITLE</source>
      <translation>SECTION_GROUP_TITLE</translation>
    </message>
    <message>
      <source>UNDO</source>
      <translation>Înapoi</translation>
    </message>
    <message>
      <source>UNDO_TLT</source>
      <translation>Undo</translation>
    </message>
    <message>
      <source>REDO</source>
      <translation>Redo</translation>
    </message>
    <message>
      <source>REDO_TLT</source>
      <translation>Redo</translation>
    </message>
    <message>
      <source>NEW_SECTION</source>
      <translation>New section</translation>
    </message>
    <message>
      <source>NEW_SECTION_TLT</source>
      <translation>Insert new section</translation>
    </message>
    <message>
      <source>ADDITION_MODE</source>
      <translation>Addition mode</translation>
    </message>
    <message>
      <source>ADDITION_MODE_TLT</source>
      <translation>Addition mode</translation>
    </message>
    <message>
      <source>MODIFICATION_MODE</source>
      <translation>Modification mode</translation>
    </message>
    <message>
      <source>MODIFICATION_MODE_TLT</source>
      <translation>Modification mode</translation>
    </message>
    <message>
      <source>DETECTION_MODE</source>
      <translation>Detection mode</translation>
    </message>
    <message>
      <source>DETECTION_MODE_TLT</source>
      <translation>Detection mode</translation>
    </message>
    <message>
      <source>CLOSE_SECTIONS</source>
      <translation>Set closed</translation>
    </message>
    <message>
      <source>CLOSE_SECTIONS_TLT</source>
      <translation>Set selected sections closed</translation>
    </message>
    <message>
      <source>UNCLOSE_SECTIONS</source>
      <translation>Set open</translation>
    </message>
    <message>
      <source>UNCLOSE_SECTIONS_TLT</source>
      <translation>Set selected sections open</translation>
    </message>
    <message>
      <source>SET_SECTIONS_POLYLINE</source>
      <translation>Set polyline</translation>
    </message>
    <message>
      <source>SET_SECTIONS_POLYLINE_TLT</source>
      <translation>Set selected section type to polyline</translation>
    </message>
    <message>
      <source>SET_SECTIONS_SPLINE</source>
      <translation>Set spline</translation>
    </message>
    <message>
      <source>SET_SECTIONS_SPLINE_TLT</source>
      <translation>Set selected section type to spline</translation>
    </message>
    <message>
      <source>REMOVE</source>
      <translation>Remove</translation>
    </message>
    <message>
      <source>REMOVE_TLT</source>
      <translation>Şterge</translation>
    </message>
    <message>
      <source>JOIN</source>
      <translation>Join</translation>
    </message>
    <message>
      <source>JOIN_TLT</source>
      <translation>Join selected sections</translation>
    </message>
    <message>
      <source>CLEAR_ALL</source>
      <translation>Şterge tot</translation>
    </message>
    <message>
      <source>CLEAR_ALL_TLT</source>
      <translation>Şterge toate obiectele</translation>
    </message>
    <message>
      <source>JOIN_ALL</source>
      <translation>Join all sections</translation>
    </message>
    <message>
      <source>JOIN_ALL_TLT</source>
      <translation>Join all sections</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI_PolylineDlg</name>
    <message>
      <source>POLYLINE_DLG_TITLE</source>
      <translation>POLYLINE_DLG_TITLE</translation>
    </message>
    <message>
      <source>POLYLINE_TITLE</source>
      <translation>POLYLINE_TITLE</translation>
    </message>
    <message>
      <source>POLYLINE_NAME</source>
      <translation>POLYLINE_NAME</translation>
    </message>
    <message>
      <source>POLYLINE_IMPORT</source>
      <translation>POLYLINE_IMPORT</translation>
    </message>
    <message>
      <source>POLYLINE_ADD_SECTION</source>
      <translation>POLYLINE_ADD_SECTION</translation>
    </message>
    <message>
      <source>POLYLINE_EDIT_SECTION</source>
      <translation>POLYLINE_EDIT_SECTION</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI_SketcherDlg</name>
    <message>
      <source>CANNOT_CLOSE</source>
      <translation>It is impossible to close sketch Number of sketch points too small</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI_FeatureDetectorDlg</name>
    <message>
      <source>GEOM_DETECT_TITLE</source>
      <translation>Feature Detection</translation>
    </message>
    <message>
      <source>GEOM_SCALING</source>
      <translation>Scaling</translation>
    </message>
    <message>
      <source>GEOM_PNT1</source>
      <translation>Top left corner</translation>
    </message>
    <message>
      <source>GEOM_PNT2</source>
      <translation>Top right corner</translation>
    </message>
    <message>
      <source>GEOM_CORNER</source>
      <translation>Detected_corners</translation>
    </message>
    <message>
      <source>GEOM_CORNERS</source>
      <translation>Corners</translation>
    </message>
    <message>
      <source>GEOM_CONTOURS</source>
      <translation>Contours</translation>
    </message>
    <message>
      <source>GEOM_FEATURES</source>
      <translation>Features</translation>
    </message>
    <message>
      <source>GEOM_DETECT_ZONE</source>
      <translation>Select a detection zone (default is whole picture)</translation>
    </message>
    <message>
      <source>GEOM_DETECT_OUTPUT</source>
      <translation>Output type</translation>
    </message>
    <message>
      <source>GEOM_PICTURE</source>
      <translation>Picture</translation>
    </message>
    <message>
      <source>GEOM_COLOR_FILTER</source>
      <translation>Filtering sample</translation>
    </message>
    <message>
      <source>GEOM_VIEW</source>
      <translation>Vedere</translation>
    </message>
    <message>
      <source>GEOM_FRONT</source>
      <translation>Front (Y-Z)</translation>
    </message>
    <message>
      <source>GEOM_TOP</source>
      <translation>Top (X-Y)</translation>
    </message>
    <message>
      <source>GEOM_LEFT</source>
      <translation>Left (X-Z)</translation>
    </message>
    <message>
      <source>USE_ROI</source>
      <translation>Use region of interest</translation>
    </message>
    <message>
      <source>KERNEL_SIZE</source>
      <translation>Kernel size</translation>
    </message>
    <message>
      <source>QUALITY_LEVEL</source>
      <translation>Quality level</translation>
    </message>
    <message>
      <source>MIN_DISTANCE</source>
      <translation>Min distance</translation>
    </message>
    <message>
      <source>TYPE_CRITERIA</source>
      <translation>Type criteria</translation>
    </message>
    <message>
      <source>CV_TERMCRIT_ITER</source>
      <translation>Max number of iteration</translation>
    </message>
    <message>
      <source>CV_TERMCRIT_EPS</source>
      <translation>Epsilon</translation>
    </message>
    <message>
      <source>CV_TERMCRIT_ITER | CV_TERMCRIT_EPS</source>
      <translation>Max number of iteration or epsilon</translation>
    </message>
    <message>
      <source>MAX_ITER</source>
      <translation>Max iteration</translation>
    </message>
    <message>
      <source>EPSILON</source>
      <translation>Epsilon</translation>
    </message>
    <message>
      <source>L2GRADIENT</source>
      <translation>L2 gradient</translation>
    </message>
    <message>
      <source>LOWTHRESHOLD</source>
      <translation>Low theshold</translation>
    </message>
    <message>
      <source>RATIO</source>
      <translation>Raţie</translation>
    </message>
    <message>
      <source>SMOOTH_SIZE</source>
      <translation>Smooth size</translation>
    </message>
    <message>
      <source>HBINS</source>
      <translation>Hbins</translation>
    </message>
    <message>
      <source>SBINS</source>
      <translation>Sbins</translation>
    </message>
    <message>
      <source>HIST_TYPE</source>
      <translation>Histogram type</translation>
    </message>
    <message>
      <source>CV_HIST_ARRAY</source>
      <translation>Multi-dimensional dense array</translation>
    </message>
    <message>
      <source>CV_HIST_SPARSE</source>
      <translation>Multi-dimensional sparse array</translation>
    </message>
    <message>
      <source>THRESHOLD_VALUE</source>
      <translation>Threshold value</translation>
    </message>
    <message>
      <source>MAX_THRESHOLD</source>
      <translation>Max threshold</translation>
    </message>
    <message>
      <source>FIND_CONTOURS_METHOD</source>
      <translation>Chain approximation method</translation>
    </message>
    <message>
      <source>CV_CHAIN_APPROX_NONE</source>
      <translation>None</translation>
    </message>
    <message>
      <source>CV_CHAIN_APPROX_SIMPLE</source>
      <translation>Simplu</translation>
    </message>
    <message>
      <source>CV_CHAIN_APPROX_TC89_KCOS</source>
      <translation>TC89 KCOS</translation>
    </message>
    <message>
      <source>CV_CHAIN_APPROX_TC89_L1</source>
      <translation>TC89 L1</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI_PictureImportDlg</name>
    <message>
      <source>GEOM_PICTURE</source>
      <translation>Picture</translation>
    </message>
    <message>
      <source>GEOM_FILE</source>
      <translation>Numele fişierului</translation>
    </message>
    <message>
      <source>GEOM_IMPORT_PICT_TITLE</source>
      <translation>Import picture in viewer</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI_SubShapeDlg</name>
    <message>
      <source>NO_SUBSHAPES_SELECTED</source>
      <translation>Please, select one or more sub-shapes</translation>
    </message>
  </context>
  <context>
    <name>GenerationGUI_PrismDlg</name>
    <message>
      <source>GEOM_THICKENING</source>
      <translation>Thickening</translation>
    </message>
    <message>
      <source>GEOM_ADD_THICKNESS</source>
      <translation>Add thickness (edges or wires only)</translation>
    </message>
    <message>
      <source>GEOM_TOWARDS_INSIDE</source>
      <translation>Thicken towards the inside</translation>
    </message>
  </context>
  <context>
    <name>GroupGUI</name>
    <message>
      <source>NO_GROUP</source>
      <translation>Please, select a group to edit</translation>
    </message>
  </context>
  <context>
    <name>GroupGUI_BooleanDlg</name>
    <message>
      <source>GEOM_UNION</source>
      <translation>Unire</translation>
    </message>
    <message>
      <source>GEOM_UNION_TITLE</source>
      <translation>Unire grupe</translation>
    </message>
    <message>
      <source>GEOM_INTERSECT</source>
      <translation>Intersect</translation>
    </message>
    <message>
      <source>GEOM_INTERSECT_TITLE</source>
      <translation>Intersectare grupe</translation>
    </message>
    <message>
      <source>GEOM_CUT</source>
      <translation>Tăiere</translation>
    </message>
    <message>
      <source>GEOM_CUT_TITLE</source>
      <translation>Tăiere grupe</translation>
    </message>
    <message>
      <source>GEOM_GROUPS</source>
      <translation>Grupe</translation>
    </message>
    <message>
      <source>GEOM_MAIN_GROUPS</source>
      <translation>Grupele principale</translation>
    </message>
    <message>
      <source>GEOM_TOOL_GROUPS</source>
      <translation>Tool Groups</translation>
    </message>
  </context>
  <context>
    <name>GroupGUI_GroupDlg</name>
    <message>
      <source>ADD</source>
      <translation>Adaugă</translation>
    </message>
    <message>
      <source>CREATE_GROUP_TITLE</source>
      <translation>Creare grupă</translation>
    </message>
    <message>
      <source>EDIT_GROUP_TITLE</source>
      <translation>Editare grupă</translation>
    </message>
    <message>
      <source>EMPTY_LIST</source>
      <translation>Please, select one or more sub-shapes to put into the group</translation>
    </message>
    <message>
      <source>EMPTY_NAME</source>
      <translation>Please, specify a non-empty group name</translation>
    </message>
    <message>
      <source>GROUP_NAME</source>
      <translation>Numele grupei</translation>
    </message>
    <message>
      <source>GROUP_PREFIX</source>
      <translation>Grupă</translation>
    </message>
    <message>
      <source>MAIN_SHAPE</source>
      <translation>Main Shape</translation>
    </message>
    <message>
      <source>MAIN_SUB_SHAPES</source>
      <translation>Main Shape And Sub-shapes</translation>
    </message>
    <message>
      <source>NO_GROUP</source>
      <translation>Please, select a group to edit</translation>
    </message>
    <message>
      <source>NO_MAIN_OBJ</source>
      <translation>Please, select a main shape</translation>
    </message>
    <message>
      <source>REMOVE</source>
      <translation>Şterge</translation>
    </message>
    <message>
      <source>SELECT_ALL</source>
      <translation>Selectare tot</translation>
    </message>
    <message>
      <source>SHAPE_SEL_RESTR</source>
      <translation>Main Shape Selection restriction</translation>
    </message>
    <message>
      <source>SHAPE_TYPE</source>
      <translation>Shape Type</translation>
    </message>
    <message>
      <source>NO_RESTR</source>
      <translation>Fără restricţii</translation>
    </message>
    <message>
      <source>GEOM_PARTS_OF_SHAPE2</source>
      <translation>Geometrical parts of the Second Shape</translation>
    </message>
    <message>
      <source>SUBSHAPES_OF_SHAPE2</source>
      <translation>Only Sub-shapes of the Second Shape</translation>
    </message>
    <message>
      <source>SECOND_SHAPE</source>
      <translation>Second Shape</translation>
    </message>
    <message>
      <source>WRN_NOT_SUBSHAPE</source>
      <translation>The selected shape is not a sub-shape of the main shape. Hide all extra shapes in the viewer for more suitable selection.</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI</name>
    <message>
      <source>NO_FIELD</source>
      <translation>Please, select a field to edit</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI_FieldDlg</name>
    <message>
      <source>CREATE_FIELD_TITLE</source>
      <translation>Creză cîmp</translation>
    </message>
    <message>
      <source>EDIT_FIELD_TITLE</source>
      <translation>Editare cîmp</translation>
    </message>
    <message>
      <source>FIELD_NAME</source>
      <translation>Numele cîmpului</translation>
    </message>
    <message>
      <source>PROPERTIES</source>
      <translation>Properties</translation>
    </message>
    <message>
      <source>SHAPE</source>
      <translation>Shape</translation>
    </message>
    <message>
      <source>DATA_TYPE</source>
      <translation>Tipe</translation>
    </message>
    <message>
      <source>BOOL</source>
      <translation>Boolean</translation>
    </message>
    <message>
      <source>INT</source>
      <translation>Integer</translation>
    </message>
    <message>
      <source>DOUBLE</source>
      <translation>Double</translation>
    </message>
    <message>
      <source>STRING</source>
      <translation>String</translation>
    </message>
    <message>
      <source>SHAPE_TYPE</source>
      <translation>Sub-shape</translation>
    </message>
    <message>
      <source>VERTEX</source>
      <translation>Nod</translation>
    </message>
    <message>
      <source>EDGE</source>
      <translation>Muchie</translation>
    </message>
    <message>
      <source>FACE</source>
      <translation>Faţă</translation>
    </message>
    <message>
      <source>SOLID</source>
      <translation>Solid</translation>
    </message>
    <message>
      <source>WHOLE</source>
      <translation>Whole shape</translation>
    </message>
    <message>
      <source>NB_COMPS</source>
      <translation>Nb. components</translation>
    </message>
    <message>
      <source>VALUES</source>
      <translation>Valoare</translation>
    </message>
    <message>
      <source>PREV_STEP</source>
      <translation>Previous step</translation>
    </message>
    <message>
      <source>STEP</source>
      <translation>Step</translation>
    </message>
    <message>
      <source>NEXT_STEP</source>
      <translation>Next step</translation>
    </message>
    <message>
      <source>ADD_STEP</source>
      <translation>Adaugă pas</translation>
    </message>
    <message>
      <source>STAMP</source>
      <translation>Stamp</translation>
    </message>
    <message>
      <source>REMOVE_STEP</source>
      <translation>Remove step</translation>
    </message>
    <message>
      <source>FIELD_PREFIX</source>
      <translation>Cîmp</translation>
    </message>
    <message>
      <source>GEOM_NO_STUDY</source>
      <translation>No study available</translation>
    </message>
    <message>
      <source>NO_SHAPE</source>
      <translation>Shape not selected</translation>
    </message>
    <message>
      <source>NO_FIELD</source>
      <translation>Field not selected</translation>
    </message>
    <message>
      <source>EMPTY_NAME</source>
      <translation>Please, specify a non-empty field name</translation>
    </message>
    <message>
      <source>NO_VALUES</source>
      <translation>No steps added to the field</translation>
    </message>
    <message>
      <source>SUB_SHAPE_HEADER</source>
      <translation>Sub-shape</translation>
    </message>
    <message>
      <source>WHOLE_SHAPE_VHEADER</source>
      <translation>Shape</translation>
    </message>
    <message>
      <source>RENAME_COMPONENT</source>
      <translation>Change component name</translation>
    </message>
    <message>
      <source>COMPONENT_NAME</source>
      <translation>Name:</translation>
    </message>
    <message>
      <source>WRN_NOT_SUBSHAPE</source>
      <translation>The selected shape is not a sub-shape of the main shape. Hide all extra shapes in the viewer for more suitable selection.</translation>
    </message>
    <message>
      <source>ERR_STEP_EXISTS</source>
      <translation>Step with such ID already exists.</translation>
    </message>
  </context>
  <context>
    <name>MeasureGUI_1Sel1TextView1Check_QTD</name>
    <message>
      <source>CHECK_SHAPE_GEOMETRY</source>
      <translation>Verifică şi geometria</translation>
    </message>
  </context>
  <context>
    <name>MeasureGUI_PointDlg</name>
    <message>
      <source>CAPTION</source>
      <translation>Coordonatele punctului</translation>
    </message>
    <message>
      <source>COORDINATES</source>
      <translation>Punctul şi coordonatele lui</translation>
    </message>
    <message>
      <source>POINT</source>
      <translation>Point</translation>
    </message>
    <message>
      <source>X</source>
      <translation>X</translation>
    </message>
    <message>
      <source>Y</source>
      <translation>Y</translation>
    </message>
    <message>
      <source>Z</source>
      <translation>Z</translation>
    </message>
  </context>
  <context>
    <name>MeasureGUI_ManageDimensionsDlg</name>
    <message>
      <source>MANAGE_DIMENSIONS_TITLE</source>
      <translation>Manage dimensions</translation>
    </message>
    <message>
      <source>OBJECT_LABEL</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>DIMENSIONS_GROUP</source>
      <translation>Dimensions</translation>
    </message>
    <message>
      <source>ADD_BTN</source>
      <translation>Add</translation>
    </message>
    <message>
      <source>REMOVE_BTN</source>
      <translation>Şterge</translation>
    </message>
    <message>
      <source>SHOW_ALL_BTN</source>
      <translation>Show all</translation>
    </message>
    <message>
      <source>HIDE_ALL_BTN</source>
      <translation>Acunde tot</translation>
    </message>
    <message>
      <source>DISTANCE_ITEM</source>
      <translation>Distanţă</translation>
    </message>
    <message>
      <source>DIAMETER_ITEM</source>
      <translation>Diameter</translation>
    </message>
    <message>
      <source>ANGLE_ITEM</source>
      <translation>Angle</translation>
    </message>
    <message>
      <source>WRN_TITLE_UNSAVED</source>
      <translation>Schimbări nesalvate</translation>
    </message>
    <message>
      <source>WRN_MSG_CHANGES_LOST</source>
      <translation>The unsaved changes will be lost. Do you wish to continue?</translation>
    </message>
    <message>
      <source>WRN_MSG_CHANGES_SAVE</source>
      <translation>The unsaved changes will be lost. Do you wish to save them?</translation>
    </message>
    <message>
      <source>WRN_MSG_UNSAVED</source>
      <translation>The unsaved changes will be lost. Do you want to continue?</translation>
    </message>
  </context>
  <context>
    <name>MeasureGUI_CreateDimensionDlg</name>
    <message>
      <source>CREATE_DIMENSION_TITLE</source>
      <translation>Adaugă dimensiune</translation>
    </message>
    <message>
      <source>DIMENSIONS</source>
      <translation>Dimensions</translation>
    </message>
    <message>
      <source>LENGTH</source>
      <translation>Length</translation>
    </message>
    <message>
      <source>DIAMETER</source>
      <translation>Diameter</translation>
    </message>
    <message>
      <source>ANGLE</source>
      <translation>Angle</translation>
    </message>
    <message>
      <source>ARGUMENTS</source>
      <translation>Arguments</translation>
    </message>
    <message>
      <source>EDGE_LENGTH</source>
      <translation>Edge length</translation>
    </message>
    <message>
      <source>TWO_POINTS</source>
      <translation>Two points</translation>
    </message>
    <message>
      <source>PARALLEL_EDGES</source>
      <translation>Parallel edges</translation>
    </message>
    <message>
      <source>TWO_EDGES</source>
      <translation>Two edges</translation>
    </message>
    <message>
      <source>THREE_POINTS</source>
      <translation>Three points</translation>
    </message>
    <message>
      <source>EDGE</source>
      <translation>Edge</translation>
    </message>
    <message>
      <source>EDGE_1</source>
      <translation>Edge 1</translation>
    </message>
    <message>
      <source>EDGE_2</source>
      <translation>Edge 2</translation>
    </message>
    <message>
      <source>POINT_1</source>
      <translation>Punct 1</translation>
    </message>
    <message>
      <source>POINT_2</source>
      <translation>Punct 2</translation>
    </message>
    <message>
      <source>POINT_3</source>
      <translation>Punct 3</translation>
    </message>
    <message>
      <source>OBJECT</source>
      <translation>Object</translation>
    </message>
    <message>
      <source>NAME_LENGTH</source>
      <translation>Lungimea</translation>
    </message>
    <message>
      <source>NAME_DIAMETER</source>
      <translation>Diameter</translation>
    </message>
    <message>
      <source>NAME_ANGLE</source>
      <translation>Angle</translation>
    </message>
    <message>
      <source>WARNING_TITLE_CANNOT_CREATE_DIMENSION</source>
      <translation>Nu se poate creea dimensiunea</translation>
    </message>
    <message>
      <source>WARNING_MSG_INVALID_ARGUMENTS</source>
      <translation>The dimension can not be created for the specified arguments. Please specify suitable arguments.</translation>
    </message>
  </context>
  <context>
    <name>MeasureGUI_CheckShapeDlg</name>
    <message>
      <source>GEOM_CHECK_TITLE</source>
      <translation>Check Shape Information</translation>
    </message>
    <message>
      <source>GEOM_CHECK_SHAPE</source>
      <translation>Check Shape</translation>
    </message>
    <message>
      <source>GEOM_CHECK_SHAPE_NAME</source>
      <translation>Faulty</translation>
    </message>
    <message>
      <source>GEOM_CHECK_SHAPE_VALID</source>
      <translation>This Shape seems to be valid</translation>
    </message>
    <message>
      <source>GEOM_CHECK_SHAPE_NOT_VALID</source>
      <translation>This Shape has errors:</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_POINT_ON_CURVE</source>
      <translation>Invalid Point on Curve</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_POINT_ON_CURVE_ON_SURFACE</source>
      <translation>Invalid Point on Curve on Surface</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_POINT_ON_SURFACE</source>
      <translation>Invalid Point on Surface</translation>
    </message>
    <message>
      <source>CHECK_ERROR_NO_3D_CURVE</source>
      <translation>No 3D Curve</translation>
    </message>
    <message>
      <source>CHECK_ERROR_MULTIPLE_3D_CURVE</source>
      <translation>Multiple 3D Curve</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_3D_CURVE</source>
      <translation>Invalid 3D Curve</translation>
    </message>
    <message>
      <source>CHECK_ERROR_NO_CURVE_ON_SURFACE</source>
      <translation>No Curve on Surface</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_CURVE_ON_SURFACE</source>
      <translation>Invalid Curve on Surface</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_CURVE_ON_CLOSED_SURFACE</source>
      <translation>Invalid Curve on Closed Surface</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_SAME_RANGE_FLAG</source>
      <translation>Invalid Same Range Flag</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_SAME_PARAMETER_FLAG</source>
      <translation>Invalid Same Parameter Flag</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_DEGENERATED_FLAG</source>
      <translation>Invalid Degenerated Flag</translation>
    </message>
    <message>
      <source>CHECK_ERROR_FREE_EDGE</source>
      <translation>Muchie liberă</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_MULTI_CONNEXITY</source>
      <translation>Invalid Multi Connexity</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_RANGE</source>
      <translation>Invalid Range</translation>
    </message>
    <message>
      <source>CHECK_ERROR_EMPTY_WIRE</source>
      <translation>Empty Wire</translation>
    </message>
    <message>
      <source>CHECK_ERROR_REDUNDANT_EDGE</source>
      <translation>Redundant Edge</translation>
    </message>
    <message>
      <source>CHECK_ERROR_SELF_INTERSECTING_WIRE</source>
      <translation>Self-Intersecting Wire</translation>
    </message>
    <message>
      <source>CHECK_ERROR_NO_SURFACE</source>
      <translation>No Surface</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_WIRE</source>
      <translation>Invalid Wire</translation>
    </message>
    <message>
      <source>CHECK_ERROR_REDUNDANT_WIRE</source>
      <translation>Redundant Wire</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INTERSECTING_WIRES</source>
      <translation>Intersecting Wires</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_IMBRICATION_OF_WIRES</source>
      <translation>Invalid Imbrication of Wires</translation>
    </message>
    <message>
      <source>CHECK_ERROR_EMPTY_SHELL</source>
      <translation>Empty Shell</translation>
    </message>
    <message>
      <source>CHECK_ERROR_REDUNDANT_FACE</source>
      <translation>Redundant Face</translation>
    </message>
    <message>
      <source>CHECK_ERROR_UNORIENTABLE_SHAPE</source>
      <translation>Unorientable Shape</translation>
    </message>
    <message>
      <source>CHECK_ERROR_NOT_CLOSED</source>
      <translation>Not Closed</translation>
    </message>
    <message>
      <source>CHECK_ERROR_NOT_CONNECTED</source>
      <translation>Not Connected</translation>
    </message>
    <message>
      <source>CHECK_ERROR_SUBSHAPE_NOT_IN_SHAPE</source>
      <translation>Subshape not in Shape</translation>
    </message>
    <message>
      <source>CHECK_ERROR_BAD_ORIENTATION</source>
      <translation>Bad Orientation</translation>
    </message>
    <message>
      <source>CHECK_ERROR_BAD_ORIENTATION_OF_SUBSHAPE</source>
      <translation>Bad Orientation of Subshape</translation>
    </message>
    <message>
      <source>CHECK_ERROR_INVALID_TOLERANCE_VALUE</source>
      <translation>Invalid Tolerance Value</translation>
    </message>
    <message>
      <source>CHECK_ERROR_CHECK_FAIL</source>
      <translation>Check Fail</translation>
    </message>
  </context>
  <context>
    <name>OperationGUI_ChamferDlg</name>
    <message>
      <source>D</source>
      <translation>D</translation>
    </message>
    <message>
      <source>FACE_1</source>
      <translation>Faţa 1</translation>
    </message>
    <message>
      <source>FACE_2</source>
      <translation>Faţa 2</translation>
    </message>
    <message>
      <source>SELECTED_FACES</source>
      <translation>Feţe selectate</translation>
    </message>
  </context>
  <context>
    <name>OperationGUI_FilletDlg</name>
    <message>
      <source>SELECTED_EDGES</source>
      <translation>Selectare muchii</translation>
    </message>
    <message>
      <source>SELECTED_FACES</source>
      <translation>Selectare feţe</translation>
    </message>
  </context>
  <context>
    <name>RepairGUI_FreeBoundDlg</name>
    <message>
      <source>CAPTION</source>
      <translation>Check free boundaries</translation>
    </message>
    <message>
      <source>FREE_BOUND</source>
      <translation>Frontiere libere</translation>
    </message>
    <message>
      <source>NUMBER_CLOSED</source>
      <translation>Number of closed free boundaries: </translation>
    </message>
    <message>
      <source>NUMBER_OPEN</source>
      <translation>Number of open free boundaries: </translation>
    </message>
    <message>
      <source>NAME_CLOSED</source>
      <translation>Closed_Free_Boundary_%1</translation>
    </message>
    <message>
      <source>NAME_OPEN</source>
      <translation>Open_Free_Boundary_%1</translation>
    </message>
  </context>
  <context>
    <name>RepairGUI_GlueDlg</name>
    <message>
      <source>FACES_FOR_GLUING_ARE_DETECTED</source>
      <translation>There are %1 face(s) that can be glued. They are coloured on the screen with red colour. Please close this message box and select faces for gluing</translation>
    </message>
    <message>
      <source>EDGES_FOR_GLUING_ARE_DETECTED</source>
      <translation>There are %1 edge(s) that can be glued. They are coloured on the screen with red colour. Please close this message box and select edges for gluing</translation>
    </message>
    <message>
      <source>GLUE_FACES</source>
      <translation>Lipire feţe</translation>
    </message>
    <message>
      <source>GLUE_EDGES</source>
      <translation>Lipire muchii</translation>
    </message>
    <message>
      <source>SELECT_FACES</source>
      <translation>Selectare feţe</translation>
    </message>
    <message>
      <source>SELECT_EDGES</source>
      <translation>Selectare muchii</translation>
    </message>
    <message>
      <source>GLUE_ALL_EDGES</source>
      <translation>Glue all coincident edges</translation>
    </message>
    <message>
      <source>THERE_ARE_NO_FACES_FOR_GLUING</source>
      <translation>There are no faces for gluing</translation>
    </message>
    <message>
      <source>THERE_ARE_NO_EDGES_FOR_GLUING</source>
      <translation>There are no edges for gluing</translation>
    </message>
  </context>
  <context>
    <name>RepairGUI_ShapeProcessDlg</name>
    <message>
      <source>ERROR_NO_OBJECTS</source>
      <translation>Please, select a geometrical object for Shape Processing.</translation>
    </message>
    <message>
      <source>ERROR_NO_OPERATORS</source>
      <translation>Please, select at least one Shape Process operation to proceed.</translation>
    </message>
    <message>
      <source>TIME_CONSUMING</source>
      <translation>Enabling this option may result in a very time-consuming operation for some input shapes. Would you like to continue?</translation>
    </message>
  </context>
  <context>
    <name>GEOMToolsGUI_DeleteDlg</name>
    <message>
      <source>GEOM_REALLY_DELETE</source>
      <translation>Do you really want to delete %1 object(s)?</translation>
    </message>
    <message>
      <source>GEOM_REALLY_DELETE_ALL</source>
      <translation>Do you really want to delete all objects?</translation>
    </message>
    <message>
      <source>GEOM_DELETE_OBJECTS</source>
      <translation>Şterge obiecte</translation>
    </message>
  </context>
  <context>
    <name>GEOMToolsGUI_DeflectionDlg</name>
    <message>
      <source>GEOM_DEFLECTION_TLT</source>
      <translation>Select Deflection of Shape</translation>
    </message>
    <message>
      <source>GEOM_DEFLECTION</source>
      <translation>Deflection :</translation>
    </message>
  </context>
  <context>
    <name>GEOMToolsGUI_LineWidthDlg</name>
    <message>
      <source>GEOM_LINE_WIDTH</source>
      <translation>Line width:</translation>
    </message>
  </context>
  <context>
    <name>GEOMToolsGUI_MarkerDlg</name>
    <message>
      <source>SET_MARKER_TLT</source>
      <translation>Set Point Marker</translation>
    </message>
    <message>
      <source>STANDARD_MARKER</source>
      <translation>Standard</translation>
    </message>
    <message>
      <source>CUSTOM_MARKER</source>
      <translation>Custom</translation>
    </message>
    <message>
      <source>TYPE</source>
      <translation>Type:</translation>
    </message>
    <message>
      <source>SCALE</source>
      <translation>Scale:</translation>
    </message>
    <message>
      <source>CUSTOM</source>
      <translation>Texture:</translation>
    </message>
    <message>
      <source>BROWSE</source>
      <translation>Căutare...</translation>
    </message>
    <message>
      <source>OK_BTN</source>
      <translation>&amp;OK</translation>
    </message>
    <message>
      <source>CANCEL_BTN</source>
      <translation>&amp;Anulare</translation>
    </message>
    <message>
      <source>HELP_BTN</source>
      <translation>Ajutor</translation>
    </message>
    <message>
      <source>LOAD_TEXTURE_TLT</source>
      <translation>Load Texture</translation>
    </message>
  </context>
  <context>
    <name>GEOMToolsGUI_MaterialPropertiesDlg</name>
    <message>
      <source>MATERIAL_PROPERTIES_TLT</source>
      <translation>Culoarea şi proprietăţile materialului</translation>
    </message>
    <message>
      <source>FRONT_FACE</source>
      <translation>Front face</translation>
    </message>
    <message>
      <source>BACK_FACE</source>
      <translation>Back face</translation>
    </message>
    <message>
      <source>REFLECTION_0</source>
      <translation>Ambienţă</translation>
    </message>
    <message>
      <source>REFLECTION_1</source>
      <translation>Difuz</translation>
    </message>
    <message>
      <source>REFLECTION_2</source>
      <translation>Specular</translation>
    </message>
    <message>
      <source>REFLECTION_3</source>
      <translation>Emissive</translation>
    </message>
    <message>
      <source>SHININESS</source>
      <translation>Shininess:</translation>
    </message>
    <message>
      <source>PHYSICAL</source>
      <translation>Physical</translation>
    </message>
    <message>
      <source>ADD_MATERIAL</source>
      <translation>Adaugă materialul</translation>
    </message>
    <message>
      <source>DELETE_MATERIAL</source>
      <translation>Şterge materialul</translation>
    </message>
    <message>
      <source>RENAME_MATERIAL</source>
      <translation>Redenumeşte materialul</translation>
    </message>
    <message>
      <source>CURRENT_MATERIAL</source>
      <translation>[ Current ]</translation>
    </message>
    <message>
      <source>CURRENT_COLOR</source>
      <translation>Color</translation>
    </message>
    <message>
      <source>CUSTOM_MATERIAL</source>
      <translation>Custom material</translation>
    </message>
    <message>
      <source>QUE_CREATE_NEW_MATERIAL</source>
      <translation>Changing properties of pre-defined material is not allowed. Do you want to create new material?</translation>
    </message>
    <message>
      <source>QUE_REMOVE_MATERIAL</source>
      <translation>Şterge materialul %1?</translation>
    </message>
    <message>
      <source>OK_BTN</source>
      <translation>&amp;OK</translation>
    </message>
    <message>
      <source>CANCEL_BTN</source>
      <translation>&amp;Anulare</translation>
    </message>
    <message>
      <source>HELP_BTN</source>
      <translation>&amp;Ajutor</translation>
    </message>
  </context>
  <context>
    <name>OperationGUI_GetSharedShapesDlg</name>
    <message>
      <source>GEOM_SHARED_SHAPES_TITLE</source>
      <translation>Get Shared Shapes</translation>
    </message>
    <message>
      <source>GEOM_GET_SHARED_SHAPES</source>
      <translation>Shared shapes</translation>
    </message>
    <message>
      <source>GEOM_SHARED_SHAPES_INPUT</source>
      <translation>Input data</translation>
    </message>
    <message>
      <source>MSG_SHARED_SHAPES_TOO_FEW_SHAPES</source>
      <translation>To few shapes selected.</translation>
    </message>
    <message>
      <source>GEOM_SHARED_SHAPE</source>
      <translation>Shared_%1</translation>
    </message>
  </context>
  <context>
    <name>GEOMToolsGUI_PublishDlg</name>
    <message>
      <source>GEOM_PUBLISH_OBJECTS_TLT</source>
      <translation>Publică obiectele</translation>
    </message>
    <message>
      <source>OBJECT_NAME</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>OBJECT_ENTRY</source>
      <translation>Entry</translation>
    </message>
    <message>
      <source>UNSELECT_ALL</source>
      <translation>U&amp;nselect All</translation>
    </message>
    <message>
      <source>SELECT_ALL</source>
      <translation>Selectare tot</translation>
    </message>
    <message>
      <source>GEOM_PUBLISH_BTN</source>
      <translation>&amp;Publicare</translation>
    </message>
    <message>
      <source>GEOM_PUBLISH_CLOSE_BTN</source>
      <translation>P&amp;ublish And Close</translation>
    </message>
  </context>
  <context>
    <name>GEOMToolsGUI_ReduceStudyDlg</name>
    <message>
      <source>GEOM_REDUCE_STUDY_TITLE</source>
      <translation>GEOM_REDUCE_STUDY_TITLE</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_KEPT_OBJECTS</source>
      <translation>GEOM_REDUCE_STUDY_KEPT_OBJECTS</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_REMOVE_OBJECTS</source>
      <translation>GEOM_REDUCE_STUDY_REMOVE_OBJECTS</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_NAME</source>
      <translation>GEOM_REDUCE_STUDY_NAME</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_OPTIONS</source>
      <translation>GEOM_REDUCE_STUDY_OPTIONS</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_INTERMEDIATES</source>
      <translation>GEOM_REDUCE_STUDY_INTERMEDIATES</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_SUB_OBJECTS</source>
      <translation>GEOM_REDUCE_STUDY_SUB_OBJECTS</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_KEEP</source>
      <translation>GEOM_REDUCE_STUDY_KEEP</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_UNPUBLISH</source>
      <translation>GEOM_REDUCE_STUDY_UNPUBLISH</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_REMOVE</source>
      <translation>GEOM_REDUCE_STUDY_REMOVE</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_REMOVE_EMPTY_FOLDER</source>
      <translation>GEOM_REDUCE_STUDY_REMOVE_EMPTY_FOLDER</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_SOFT_REMOVAL</source>
      <translation>GEOM_REDUCE_STUDY_SOFT_REMOVAL</translation>
    </message>
    <message>
      <source>GEOM_REDUCE_STUDY_WARNING_DELETE</source>
      <translation>GEOM_REDUCE_STUDY_WARNING_DELETE</translation>
    </message>
  </context>
  <context>
    <name>RepairGUI_UnionFacesDlg</name>
    <message>
      <source>GEOM_UNION_FACES_TITLE</source>
      <translation>Union faces</translation>
    </message>
    <message>
      <source>GEOM_UNION_FACES</source>
      <translation>Object to unite faces</translation>
    </message>
    <message>
      <source>UNION_FACES_NEW_OBJ_NAME</source>
      <translation>UnionFaces</translation>
    </message>
  </context>
  <context>
    <name>GEOMGUI_CreationInfoWdg</name>
    <message>
      <source>CREATION_INFO_TITLE</source>
      <translation>Informaţie</translation>
    </message>
    <message>
      <source>OPERATION</source>
      <translation>Creation operation</translation>
    </message>
    <message>
      <source>PARAMETER</source>
      <translation>Parameter</translation>
    </message>
    <message>
      <source>VALUE</source>
      <translation>Valoare</translation>
    </message>
    <message>
      <source>NO_INFO</source>
      <translation>(Nici o informaţie disponibilă)</translation>
    </message>
  </context>
  <context>
    <name>EntityGUI_IsolineDlg</name>
    <message>
      <source>GEOM_ISOLINE_TITLE</source>
      <translation>Construcţia isoliniei</translation>
    </message>
    <message>
      <source>GEOM_ISOLINE</source>
      <translation>Isolinie</translation>
    </message>
    <message>
      <source>GEOM_ISOLINE_U</source>
      <translation>U-Isolinie</translation>
    </message>
    <message>
      <source>GEOM_ISOLINE_V</source>
      <translation>V-Isolinie</translation>
    </message>
  </context>
</TS>
