<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ro" sourcelanguage="en">
  <context>
    <name>OB_Browser</name>
    <message>
      <source>MEN_EXPAND_ALL</source>
      <translation>Expand All</translation>
    </message>
    <message>
      <source>MEN_COLLAPSE_ALL</source>
      <translation>Collapse All</translation>
    </message>
    <message>
      <source>MEN_FIND</source>
      <translation>Find</translation>
    </message>
  </context>
  <context>
    <name>OB_FindDlg</name>
    <message>
      <source>FIND</source>
      <translation>Find</translation>
    </message>
    <message>
      <source>CLOSE</source>
      <translation>Close</translation>
    </message>
    <message>
      <source>CASE_SENSITIVE</source>
      <translation>Case sensitive</translation>
    </message>
    <message>
      <source>IS_REG_EXP</source>
      <translation>Regular expression</translation>
    </message>
  </context>
</TS>
