<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it" sourcelanguage="en">
  <context>
    <name>LogWindow</name>
    <message>
      <location filename="../LogWindow.cxx" line="293"/>
      <source>EDIT_COPY_CMD</source>
      <translation>&amp; Copia</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="298"/>
      <source>EDIT_CLEAR_CMD</source>
      <translation>Clea &amp; r</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="303"/>
      <source>EDIT_SELECTALL_CMD</source>
      <translation>Selezionare &amp; tutto</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="308"/>
      <source>EDIT_SAVETOFILE_CMD</source>
      <translation>&amp; Salvare il log file...</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_ERROR</source>
      <translation>Errore</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_CANT_SAVE_FILE</source>
      <translation>Impossibile salvare il file</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>BUT_OK</source>
      <translation>&amp; OK</translation>
    </message>
  </context>
</TS>
