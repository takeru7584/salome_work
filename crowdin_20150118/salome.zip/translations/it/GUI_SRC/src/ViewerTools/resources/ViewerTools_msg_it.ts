<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it" sourcelanguage="en">
  <context>
    <name>ViewerTools_CubeAxesDlgBase</name>
    <message>
      <source>X_AXIS</source>
      <translation>Asse x</translation>
    </message>
    <message>
      <source>Y_AXIS</source>
      <translation>Asse Y</translation>
    </message>
    <message>
      <source>Z_AXIS</source>
      <translation>Asse Z</translation>
    </message>
    <message>
      <source>CAPTION</source>
      <translation>Assi graduati</translation>
    </message>
    <message>
      <source>IS_VISIBLE</source>
      <translation>È visibile</translation>
    </message>
    <message>
      <source>FONT</source>
      <translation>Tipo di carattere</translation>
    </message>
    <message>
      <source>NAME</source>
      <translation>Nome</translation>
    </message>
    <message>
      <source>TICK_MARKS</source>
      <translation>Segni di graduazione</translation>
    </message>
    <message>
      <source>LABELS</source>
      <translation>Etichette</translation>
    </message>
    <message>
      <source>LENGTH</source>
      <translation>Lunghezza</translation>
    </message>
    <message>
      <source>NUMBER</source>
      <translation>Numero</translation>
    </message>
    <message>
      <source>OFFSET</source>
      <translation>Offset</translation>
    </message>
    <message>
      <source>AXIS_NAME</source>
      <translation>Nome di asse</translation>
    </message>
  </context>
  <context>
    <name>ViewerTools_FontWidgetBase</name>
    <message>
      <source>BOLD</source>
      <translation>Grassetto</translation>
    </message>
    <message>
      <source>ITALIC</source>
      <translation>Corsivo</translation>
    </message>
    <message>
      <source>SHADOW</source>
      <translation>Ombra</translation>
    </message>
  </context>
</TS>
