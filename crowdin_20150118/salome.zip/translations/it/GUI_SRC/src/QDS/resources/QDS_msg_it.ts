<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it" sourcelanguage="en">
  <context>
    <name>QDS_Datum</name>
    <message>
      <source>DATA_ERR_TITLE</source>
      <translation>Valore del parametro non corretto</translation>
    </message>
    <message>
      <source>DATA_STRING</source>
      <translation> stringa non vuota</translation>
    </message>
    <message>
      <source>DATA_NON_EMPTY</source>
      <translation> non-vuoto</translation>
    </message>
    <message>
      <source>DATA_MIN_LIMIT</source>
      <translation> maggiore di%1</translation>
    </message>
    <message>
      <source>DATA_FLOAT</source>
      <translation> Real</translation>
    </message>
    <message>
      <source>DATA_RANGE</source>
      <translation> nell'intervallo [%1,%2]</translation>
    </message>
    <message>
      <source>DATA_SHOULD_BE_VALUE</source>
      <translation>Dovrebbe essere il%1 valore</translation>
    </message>
    <message>
      <source>DATA_INTEGER</source>
      <translation> Integer</translation>
    </message>
    <message>
      <source>DATA_INCORRECT_VALUE</source>
      <translation>Valore del parametro "%1" non è corretto.</translation>
    </message>
    <message>
      <source>DATA_MAX_LIMIT</source>
      <translation> meno di%1</translation>
    </message>
    <message>
      <source>DATA_INPUT_VALUE</source>
      <translation>Per favore, inserire il valore corretto.</translation>
    </message>
  </context>
</TS>
