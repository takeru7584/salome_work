<?xml version="1.0"?>
<!DOCTYPE TS>
<TS language="it" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>TOOL_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>TLT_MY_NEW_ITEM</source>
      <translation>Mia voce di menu</translation>
    </message>
    <message>
      <source>TLT_LOAD_DXF</source>
      <translation>Carica file DXF</translation>
    </message>
    <message>
      <source>MEN_LOAD_DXF</source>
      <translation>Carica file DXF</translation>
    </message>
    <message>
      <source>STS_LOAD_DXF</source>
      <translation>Carica file DXF</translation>
    </message>
    <message>
      <source>TLT_GET_BANNER</source>
      <translation>Ottenere banner XMED</translation>
    </message>
    <message>
      <source>STS_MY_NEW_ITEM</source>
      <translation>Chiamare la mia voce di menu</translation>
    </message>
    <message>
      <source>MEN_FILE_XMED</source>
      <translation>Xmed</translation>
    </message>
    <message>
      <source>MEN_GET_BANNER</source>
      <translation>Ottenere banner</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>&amp; File</translation>
    </message>
    <message>
      <source>STS_GET_BANNER</source>
      <translation>Ottenere banner XMED</translation>
    </message>
    <message>
      <source>TLT_BUILDER1</source>
      <translation>Creare base vettori Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>TLT_BUILDER2</source>
      <translation>Creare i bordi collegati (linee e archi)</translation>
    </message>
    <message>
      <source>TLT_BUILDER3</source>
      <translation>Caricare uno script in python</translation>
    </message>
    <message>
      <source>STS_BUILDER1</source>
      <translation>Creare base vettori Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>STS_BUILDER2</source>
      <translation>Creare i bordi collegati (linee e archi)</translation>
    </message>
    <message>
      <source>STS_BUILDER3</source>
      <translation>Caricare uno script in python</translation>
    </message>
    <message>
      <source>MEN_BUILDER1</source>
      <translation>Creare base vettori Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>MEN_BUILDER2</source>
      <translation>Creare i bordi collegati (linee e archi)</translation>
    </message>
    <message>
      <source>MEN_BUILDER3</source>
      <translation>Caricare uno script in python</translation>
    </message>
    <message>
      <source>MEN_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>MEN_MY_NEW_ITEM</source>
      <translation>Mia voce di menu</translation>
    </message>
  </context>
  <context>
    <name>XMEDGUI_maquette</name>
    <message>
      <source>BUT_OK</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>QUE_XMED_LABEL</source>
      <translation>Nome importazione</translation>
    </message>
    <message>
      <source>QUE_XMED_NAME</source>
      <translation>Per favore, Inserisci il tuo nome</translation>
    </message>
    <message>
      <source>INF_XMED_BANNER</source>
      <translation>XMED informazioni</translation>
    </message>
    <message>
      <source>INF_XMED_MENU</source>
      <translation>Questo &#xE8; solo un test</translation>
    </message>
  </context>
</TS>
