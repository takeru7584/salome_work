<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="en">
  <context>
    <name>ViewerTools_CubeAxesDlgBase</name>
    <message>
      <source>X_AXIS</source>
      <translation>X axis</translation>
    </message>
    <message>
      <source>Y_AXIS</source>
      <translation>Y axis</translation>
    </message>
    <message>
      <source>Z_AXIS</source>
      <translation>Z axis</translation>
    </message>
    <message>
      <source>CAPTION</source>
      <translation>Graduated axes</translation>
    </message>
    <message>
      <source>IS_VISIBLE</source>
      <translation>Is visible</translation>
    </message>
    <message>
      <source>FONT</source>
      <translation>Font</translation>
    </message>
    <message>
      <source>NAME</source>
      <translation>Name</translation>
    </message>
    <message>
      <source>TICK_MARKS</source>
      <translation>Tick marks</translation>
    </message>
    <message>
      <source>LABELS</source>
      <translation>Labels</translation>
    </message>
    <message>
      <source>LENGTH</source>
      <translation>Length</translation>
    </message>
    <message>
      <source>NUMBER</source>
      <translation>Number</translation>
    </message>
    <message>
      <source>OFFSET</source>
      <translation>Offset</translation>
    </message>
    <message>
      <source>AXIS_NAME</source>
      <translation>Axis name</translation>
    </message>
  </context>
  <context>
    <name>ViewerTools_FontWidgetBase</name>
    <message>
      <source>BOLD</source>
      <translation>Bold</translation>
    </message>
    <message>
      <source>ITALIC</source>
      <translation>Italic</translation>
    </message>
    <message>
      <source>SHADOW</source>
      <translation>Shadow</translation>
    </message>
  </context>
</TS>
