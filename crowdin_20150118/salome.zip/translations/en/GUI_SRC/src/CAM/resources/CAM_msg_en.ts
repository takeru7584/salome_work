<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>ERROR_TLT</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>ERROR_ACTIVATE_MODULE_MSG</source>
      <translation>Failed to activate module %1</translation>
    </message>
    <message>
      <source>MODULE_ROOT_OBJECT_TOOLTIP</source>
      <translation>%1 module root object</translation>
    </message>
  </context>
</TS>
