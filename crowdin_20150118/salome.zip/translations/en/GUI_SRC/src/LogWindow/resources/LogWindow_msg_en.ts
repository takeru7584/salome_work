<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="en">
  <context>
    <name>LogWindow</name>
    <message>
      <location filename="../LogWindow.cxx" line="293"/>
      <source>EDIT_COPY_CMD</source>
      <translation>&amp;Copy</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="298"/>
      <source>EDIT_CLEAR_CMD</source>
      <translation>Clea&amp;r</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="303"/>
      <source>EDIT_SELECTALL_CMD</source>
      <translation>Select &amp;All</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="308"/>
      <source>EDIT_SAVETOFILE_CMD</source>
      <translation>&amp;Save log to file...</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_ERROR</source>
      <translation>Error</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_CANT_SAVE_FILE</source>
      <translation>Can't save file</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>BUT_OK</source>
      <translation>&amp;OK</translation>
    </message>
  </context>
</TS>
