<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="en">
  <context>
    <name>DependencyTree_View</name>
    <message>
      <source>DEPENDENCY_TREE</source>
      <translation>Dependency Tree</translation>
    </message>
    <message>
      <source>MOVE_NODES</source>
      <translation>Move nodes</translation>
    </message>
    <message>
      <source>HIERARCHY_DEPTH</source>
      <translation>Hierarchy depth  </translation>
    </message>
    <message>
      <source>DISPLAY_ASCENDANTS</source>
      <translation>Display ascendants</translation>
    </message>
    <message>
      <source>DISPLAY_DESCENDANTS</source>
      <translation>Display descendants</translation>
    </message>
    <message>
      <source>SHOW_ALL</source>
      <translation>Show all</translation>
    </message>
    <message>
      <source>UPDATE</source>
      <translation>Update</translation>
    </message>
    <name>DependencyTree_ViewModel</name>
    <message>
      <source>MEN_REBUILD_THE_TREE</source>
      <translation>Rebuild the tree</translation>
    </message>
    <message>
      <source>MEN_REDUCE_STUDY</source>
      <translation>Reduce study</translation>
    </message>
  </context>
</TS>
