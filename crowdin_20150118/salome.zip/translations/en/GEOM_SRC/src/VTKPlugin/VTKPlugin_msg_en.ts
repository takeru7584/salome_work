<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_EXPORTVTK</source>
      <translation>VTK</translation>
    </message>
    <message>
      <source>TOP_EXPORTVTK</source>
      <translation>Export VTK</translation>
    </message>
    <message>
      <source>STB_EXPORTVTK</source>
      <translation>Export VTK</translation>
    </message>
    <message>
      <source>MEN_IMPORTVTK</source>
      <translation>VTK</translation>
    </message>
    <message>
      <source>TOP_IMPORTVTK</source>
      <translation>Import VTK</translation>
    </message>
    <message>
      <source>STB_IMPORTVTK</source>
      <translation>Import VTK</translation>
    </message>
  </context>
  <context>
    <name>VTKPlugin_GUI</name>
    <message>
      <source>VTK_FILES</source>
      <translation>VTK files( *.vtk )</translation>
    </message>
    <message>
      <source>EXPORT_TITLE</source>
      <translation>Export VTK</translation>
    </message>
  </context>
  <context>
    <name>VTKPlugin_ExportDlg</name>
    <message>
      <source>DEFLECTION</source>
      <translation>Deflection</translation>
    </message>
  </context>
</TS>
