<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_EXPORTSTEP</source>
      <translation>STEP</translation>
    </message>
    <message>
      <source>TOP_EXPORTSTEP</source>
      <translation>Export STEP</translation>
    </message>
    <message>
      <source>STB_EXPORTSTEP</source>
      <translation>Export STEP</translation>
    </message>
    <message>
      <source>MEN_IMPORTSTEP</source>
      <translation>STEP</translation>
    </message>
    <message>
      <source>TOP_IMPORTSTEP</source>
      <translation>Import STEP</translation>
    </message>
    <message>
      <source>STB_IMPORTSTEP</source>
      <translation>Import STEP</translation>
    </message>
  </context>
  <context>
    <name>STEPPlugin_GUI</name>
    <message>
      <source>STEP_FILES</source>
      <translation>STEP Files ( *.step *.stp )</translation>
    </message>
    <message>
      <source>EXPORT_TITLE</source>
      <translation>Export STEP</translation>
    </message>
    <message>
      <source>IMPORT_TITLE</source>
      <translation>Import STEP</translation>
    </message>
    <message>
      <source>SCALE_DIMENSIONS</source>
      <translation>Take into account the units (%1) embedded to the file?
Ignoring units will cause model scaling (as dimensions are supposed to be specified in meters).</translation>
    </message>
  </context>
</TS>
