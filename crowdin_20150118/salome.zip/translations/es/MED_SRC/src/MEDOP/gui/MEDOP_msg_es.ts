<?xml version="1.0"?>
<!DOCTYPE TS>
<TS language="es-ES" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>TOOL_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>TLT_MY_NEW_ITEM</source>
      <translation>Mi men&#xFA;</translation>
    </message>
    <message>
      <source>TLT_LOAD_DXF</source>
      <translation>Cargar archivo DXF</translation>
    </message>
    <message>
      <source>MEN_LOAD_DXF</source>
      <translation>Cargar archivo DXF</translation>
    </message>
    <message>
      <source>STS_LOAD_DXF</source>
      <translation>Cargar archivo DXF</translation>
    </message>
    <message>
      <source>TLT_GET_BANNER</source>
      <translation>Conseguir la bandera XMED</translation>
    </message>
    <message>
      <source>STS_MY_NEW_ITEM</source>
      <translation>Llame a mi men&#xFA;</translation>
    </message>
    <message>
      <source>MEN_FILE_XMED</source>
      <translation>Xmed</translation>
    </message>
    <message>
      <source>MEN_GET_BANNER</source>
      <translation>Conseguir la bandera</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>&amp; Archivo</translation>
    </message>
    <message>
      <source>STS_GET_BANNER</source>
      <translation>Conseguir la bandera XMED</translation>
    </message>
    <message>
      <source>TLT_BUILDER1</source>
      <translation>Crear vectores base Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>TLT_BUILDER2</source>
      <translation>Crear bordes conectados (l&#xED;neas y arcos)</translation>
    </message>
    <message>
      <source>TLT_BUILDER3</source>
      <translation>Cargar un script en python</translation>
    </message>
    <message>
      <source>STS_BUILDER1</source>
      <translation>Crear vectores base Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>STS_BUILDER2</source>
      <translation>Crear bordes conectados (l&#xED;neas y arcos)</translation>
    </message>
    <message>
      <source>STS_BUILDER3</source>
      <translation>Cargar un script en python</translation>
    </message>
    <message>
      <source>MEN_BUILDER1</source>
      <translation>Crear vectores base Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>MEN_BUILDER2</source>
      <translation>Crear bordes conectados (l&#xED;neas y arcos)</translation>
    </message>
    <message>
      <source>MEN_BUILDER3</source>
      <translation>Cargar un script en python</translation>
    </message>
    <message>
      <source>MEN_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>MEN_MY_NEW_ITEM</source>
      <translation>Mi men&#xFA;</translation>
    </message>
  </context>
  <context>
    <name>XMEDGUI_maquette</name>
    <message>
      <source>BUT_OK</source>
      <translation>Vale</translation>
    </message>
    <message>
      <source>QUE_XMED_LABEL</source>
      <translation>Importaci&#xF3;n de nombre</translation>
    </message>
    <message>
      <source>QUE_XMED_NAME</source>
      <translation>Por favor, indique su nombre</translation>
    </message>
    <message>
      <source>INF_XMED_BANNER</source>
      <translation>XMED informaci&#xF3;n</translation>
    </message>
    <message>
      <source>INF_XMED_MENU</source>
      <translation>Esto es s&#xF3;lo una prueba</translation>
    </message>
  </context>
</TS>
