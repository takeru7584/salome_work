<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl" sourcelanguage="en">
  <context>
    <name>QDS_Datum</name>
    <message>
      <source>DATA_ERR_TITLE</source>
      <translation>Nieprawidłowa wartość parametru</translation>
    </message>
    <message>
      <source>DATA_STRING</source>
      <translation> ciąg niepusty</translation>
    </message>
    <message>
      <source>DATA_NON_EMPTY</source>
      <translation> nie jest pusta</translation>
    </message>
    <message>
      <source>DATA_MIN_LIMIT</source>
      <translation> większe niż%1</translation>
    </message>
    <message>
      <source>DATA_FLOAT</source>
      <translation> prawdziwe</translation>
    </message>
    <message>
      <source>DATA_RANGE</source>
      <translation> w zakresie [%1,%2]</translation>
    </message>
    <message>
      <source>DATA_SHOULD_BE_VALUE</source>
      <translation>Powinna być wartość%1</translation>
    </message>
    <message>
      <source>DATA_INTEGER</source>
      <translation> Liczba całkowita</translation>
    </message>
    <message>
      <source>DATA_INCORRECT_VALUE</source>
      <translation>Wartość parametru "%1" jest niepoprawna.</translation>
    </message>
    <message>
      <source>DATA_MAX_LIMIT</source>
      <translation> mniej niż%1</translation>
    </message>
    <message>
      <source>DATA_INPUT_VALUE</source>
      <translation>Proszę, wpisać poprawną wartość.</translation>
    </message>
  </context>
</TS>
