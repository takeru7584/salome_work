<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>APP_OK</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>APP_ERROR</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>APP_UNK_EXCEPTION</source>
      <translation>Nieznany wyjątek</translation>
    </message>
  </context>
</TS>
