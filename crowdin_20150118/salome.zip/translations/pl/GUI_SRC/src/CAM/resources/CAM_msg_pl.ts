<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>ERROR_TLT</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>ERROR_ACTIVATE_MODULE_MSG</source>
      <translation>Nie można uaktywnić moduł%1</translation>
    </message>
    <message>
      <source>MODULE_ROOT_OBJECT_TOOLTIP</source>
      <translation>%1 moduł obiektu głównego</translation>
    </message>
  </context>
</TS>
