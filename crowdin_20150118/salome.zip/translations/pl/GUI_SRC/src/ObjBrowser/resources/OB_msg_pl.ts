<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl" sourcelanguage="en">
  <context>
    <name>OB_Browser</name>
    <message>
      <source>MEN_EXPAND_ALL</source>
      <translation>Rozwiń wszystkie</translation>
    </message>
    <message>
      <source>MEN_COLLAPSE_ALL</source>
      <translation>Zwiń wszystko</translation>
    </message>
    <message>
      <source>MEN_FIND</source>
      <translation>Znajdź</translation>
    </message>
  </context>
  <context>
    <name>OB_FindDlg</name>
    <message>
      <source>FIND</source>
      <translation>Znajdź</translation>
    </message>
    <message>
      <source>CLOSE</source>
      <translation>Zamknij</translation>
    </message>
    <message>
      <source>CASE_SENSITIVE</source>
      <translation>Wielkość liter</translation>
    </message>
    <message>
      <source>IS_REG_EXP</source>
      <translation>Wyrażenie regularne</translation>
    </message>
  </context>
</TS>
