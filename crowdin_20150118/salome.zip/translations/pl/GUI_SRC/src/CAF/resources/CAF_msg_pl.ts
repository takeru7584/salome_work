<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl" sourcelanguage="en">
  <context>
    <name>CAF_Application</name>
    <message>
      <source>MEN_APP_EDIT</source>
      <translation>&amp; Edit</translation>
    </message>
    <message>
      <source>INF_ALL_FILTER</source>
      <translation>Wszystkie pliki (*. *)</translation>
    </message>
    <message>
      <source>INF_ALL_DOCUMENTS_FILTER</source>
      <translation>Wszystkie czytelne dokumenty</translation>
    </message>
    <message>
      <source>MEN_DESK_EDIT</source>
      <translation>&amp; Edit</translation>
    </message>
    <message>
      <source>MEN_APP_EDIT_UNDO</source>
      <translation>&amp; Cofnąć</translation>
    </message>
    <message>
      <source>MEN_APP_EDIT_REDO</source>
      <translation>&amp; Przerobić</translation>
    </message>
    <message>
      <source>PRP_APP_EDIT_REDO</source>
      <translation>Ponawia ostatnią operację</translation>
    </message>
    <message>
      <source>PRP_APP_EDIT_UNDO</source>
      <translation>Cofa ostatnią operację</translation>
    </message>
    <message>
      <source>TOT_APP_EDIT_REDO</source>
      <translation>Wykonaj ponownie</translation>
    </message>
    <message>
      <source>TOT_APP_EDIT_UNDO</source>
      <translation>Cofnij</translation>
    </message>
    <message>
      <source>INF_APP_REDOACTIONS</source>
      <translation> Wykonuje ponownie ostatnio cofniętą akcje%1 </translation>
    </message>
    <message>
      <source>INF_APP_UNDOACTIONS</source>
      <translation> Cofa akcje%1 </translation>
    </message>
    <message>
      <source>ABOUT_INFO</source>
      <translation>KOMPLET aplikacji Caf</translation>
    </message>
  </context>
</TS>
