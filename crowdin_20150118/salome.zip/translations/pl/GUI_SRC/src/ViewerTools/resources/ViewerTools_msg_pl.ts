<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl" sourcelanguage="en">
  <context>
    <name>ViewerTools_CubeAxesDlgBase</name>
    <message>
      <source>X_AXIS</source>
      <translation>Oś x</translation>
    </message>
    <message>
      <source>Y_AXIS</source>
      <translation>Oś Y</translation>
    </message>
    <message>
      <source>Z_AXIS</source>
      <translation>Osi</translation>
    </message>
    <message>
      <source>CAPTION</source>
      <translation>Ukończył osi</translation>
    </message>
    <message>
      <source>IS_VISIBLE</source>
      <translation>Jest widoczne</translation>
    </message>
    <message>
      <source>FONT</source>
      <translation>Czcionki</translation>
    </message>
    <message>
      <source>NAME</source>
      <translation>Nazwa</translation>
    </message>
    <message>
      <source>TICK_MARKS</source>
      <translation>Znaczniki</translation>
    </message>
    <message>
      <source>LABELS</source>
      <translation>Etykiety</translation>
    </message>
    <message>
      <source>LENGTH</source>
      <translation>Długość</translation>
    </message>
    <message>
      <source>NUMBER</source>
      <translation>Numer</translation>
    </message>
    <message>
      <source>OFFSET</source>
      <translation>Przesunięcie</translation>
    </message>
    <message>
      <source>AXIS_NAME</source>
      <translation>Nazwa osi</translation>
    </message>
  </context>
  <context>
    <name>ViewerTools_FontWidgetBase</name>
    <message>
      <source>BOLD</source>
      <translation>Pogrubienie</translation>
    </message>
    <message>
      <source>ITALIC</source>
      <translation>Kursywa</translation>
    </message>
    <message>
      <source>SHADOW</source>
      <translation>Cień</translation>
    </message>
  </context>
</TS>
