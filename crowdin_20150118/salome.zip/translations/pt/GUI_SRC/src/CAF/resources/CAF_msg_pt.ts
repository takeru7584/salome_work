<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt-PT" sourcelanguage="en">
  <context>
    <name>CAF_Application</name>
    <message>
      <source>MEN_APP_EDIT</source>
      <translation>&amp; Editar</translation>
    </message>
    <message>
      <source>INF_ALL_FILTER</source>
      <translation>Todos os arquivos (*. *)</translation>
    </message>
    <message>
      <source>INF_ALL_DOCUMENTS_FILTER</source>
      <translation>Todos os documentos legíveis</translation>
    </message>
    <message>
      <source>MEN_DESK_EDIT</source>
      <translation>&amp; Editar</translation>
    </message>
    <message>
      <source>MEN_APP_EDIT_UNDO</source>
      <translation>&amp; Undo</translation>
    </message>
    <message>
      <source>MEN_APP_EDIT_REDO</source>
      <translation>&amp; Redo</translation>
    </message>
    <message>
      <source>PRP_APP_EDIT_REDO</source>
      <translation>Refaz a última operação</translation>
    </message>
    <message>
      <source>PRP_APP_EDIT_UNDO</source>
      <translation>Desfaz a última operação</translation>
    </message>
    <message>
      <source>TOT_APP_EDIT_REDO</source>
      <translation>Refazer</translation>
    </message>
    <message>
      <source>TOT_APP_EDIT_UNDO</source>
      <translation>Desfazer</translation>
    </message>
    <message>
      <source>INF_APP_REDOACTIONS</source>
      <translation> Refaz a ação (ões%1) </translation>
    </message>
    <message>
      <source>INF_APP_UNDOACTIONS</source>
      <translation> Desfaz as%1 ações </translation>
    </message>
    <message>
      <source>ABOUT_INFO</source>
      <translation>AJUSTAR a aplicação da Caf</translation>
    </message>
  </context>
</TS>
