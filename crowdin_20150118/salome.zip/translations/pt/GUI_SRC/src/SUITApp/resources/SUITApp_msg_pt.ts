<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt-PT" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>APP_OK</source>
      <translation>Razoável</translation>
    </message>
    <message>
      <source>APP_ERROR</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>APP_UNK_EXCEPTION</source>
      <translation>Exceção desconhecida</translation>
    </message>
  </context>
</TS>
