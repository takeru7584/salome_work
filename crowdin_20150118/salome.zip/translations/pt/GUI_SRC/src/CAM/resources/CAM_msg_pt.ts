<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt-PT" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>ERROR_TLT</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>ERROR_ACTIVATE_MODULE_MSG</source>
      <translation>Falha ao ativar o módulo%1</translation>
    </message>
    <message>
      <source>MODULE_ROOT_OBJECT_TOOLTIP</source>
      <translation>%objeto de raiz 1 módulo</translation>
    </message>
  </context>
</TS>
