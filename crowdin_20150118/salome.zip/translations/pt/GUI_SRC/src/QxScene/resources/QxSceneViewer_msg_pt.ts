<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt-PT" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_CHANGE_BACKGROUND</source>
      <translation>Alterar plano de fundo...</translation>
    </message>
    <message>
      <source>MNU_PAN_VIEW</source>
      <translation>Visão panorâmica</translation>
    </message>
    <message>
      <source>DSC_PAN_VIEW</source>
      <translation>Garimpando a vista</translation>
    </message>
    <message>
      <source>MNU_RESET_VIEW</source>
      <translation>Redefinir</translation>
    </message>
    <message>
      <source>DSC_RESET_VIEW</source>
      <translation>Ponto de vista de reset</translation>
    </message>
  </context>
  <context>
    <name>QxScene_ViewWindow</name>
    <message>
      <source>LBL_TOOLBAR_LABEL</source>
      <translation>LBL_TOOLBAR_LABEL</translation>
    </message>
  </context>
  <context>
    <name>QxScene_ViewManager</name>
    <message>
      <source>QXSCENE_VIEW_TITLE</source>
      <translation>Cena de QGraphics:%M - visualizador:%V</translation>
    </message>
  </context>
</TS>
