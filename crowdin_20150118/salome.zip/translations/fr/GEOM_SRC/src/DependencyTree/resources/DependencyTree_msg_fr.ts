<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en">
  <context>
    <name>DependencyTree_View</name>
    <message>
      <source>DEPENDENCY_TREE</source>
      <translation>Arbre des dépendances</translation>
    </message>
    <message>
      <source>MOVE_NODES</source>
      <translation>Déplacer les noeuds</translation>
    </message>
    <message>
      <source>HIERARCHY_DEPTH</source>
      <translation>Niveau hiérarchique</translation>
    </message>
    <message>
      <source>DISPLAY_ASCENDANTS</source>
      <translation>Montrer les liens ascendants</translation>
    </message>
    <message>
      <source>DISPLAY_DESCENDANTS</source>
      <translation>Montrer les liens descendants</translation>
    </message>
    <message>
      <source>SHOW_ALL</source>
      <translation>Montrer tout</translation>
    </message>
    <message>
      <source>UPDATE</source>
      <translation>Mise à jour</translation>
    </message>
    <name>DependencyTree_ViewModel</name>
    <message>
      <source>MEN_REBUILD_THE_TREE</source>
      <translation>Reconstruire l'arbre</translation>
    </message>
    <message>
      <source>MEN_REDUCE_STUDY</source>
      <translation>Réduire l'étude</translation>
    </message>
  </context>
</TS>
