<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_EXPORTBREP</source>
      <translation>BREP</translation>
    </message>
    <message>
      <source>TOP_EXPORTBREP</source>
      <translation>Exporter BREP</translation>
    </message>
    <message>
      <source>STB_EXPORTBREP</source>
      <translation>Exporter BREP</translation>
    </message>
    <message>
      <source>MEN_IMPORTBREP</source>
      <translation>BREP</translation>
    </message>
    <message>
      <source>TOP_IMPORTBREP</source>
      <translation>Importer BREP</translation>
    </message>
    <message>
      <source>STB_IMPORTBREP</source>
      <translation>Importer BREP</translation>
    </message>
  </context>
  <context>
    <name>BREPPlugin_GUI</name>
    <message>
      <source>BREP_FILES</source>
      <translation>BREP Fichiers( *.brep )</translation>
    </message>
    <message>
      <source>EXPORT_TITLE</source>
      <translation>Exporter BREP</translation>
    </message>
    <message>
      <source>IMPORT_TITLE</source>
      <translation>Importer BREP</translation>
    </message>
  </context>
</TS>
