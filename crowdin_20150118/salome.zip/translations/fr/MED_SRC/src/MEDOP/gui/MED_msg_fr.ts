<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en">
  <context>
    <name>DatasourceController</name>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="45"/>
      <source>LAB_ADD_DATA_SOURCE</source>
      <translation>Importer des données MED</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="46"/>
      <source>TIP_ADD_DATA_SOURCE</source>
      <translation>Ajouter des données par import de fichiers MED</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="52"/>
      <source>LAB_ADD_IMAGE_SOURCE</source>
      <translation>Ajouter une image</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="53"/>
      <source>TIP_ADD_IMAGE_SOURCE</source>
      <translation>Ajouter des données par import d'un fichier image</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="62"/>
      <source>LAB_EXPAND_FIELD</source>
      <translation>Étendre les series temporelles du champ</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="69"/>
      <source>LAB_VISUALIZE</source>
      <translation>Visualiser</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="75"/>
      <source>LAB_USE_IN_WORKSPACE</source>
      <translation>Utiliser dans l'espace de travail</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="83"/>
      <source>LAB_CHANGE_MESH</source>
      <translation>Changer le maillage sous-jacent</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="113"/>
      <source>LAB_INTERPOLATE_FIELD</source>
      <translation>Interpoler le champ</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="157"/>
      <source>IMPORT_MED_FIELDS</source>
      <translation>Importer des champs (format MED)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="191"/>
      <source>OPERATION_FAILED</source>
      <translation>L'opération a échoué</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="192"/>
      <source>CREATION_FAILED</source>
      <translation>La création des données MED à partir d'un fichier image a échoué</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="283"/>
      <source>OPERATION_NOT_ALLOWED</source>
      <translation>Opération non autorisée</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="284"/>
      <source>FIELD_ALREADY_DEFINED</source>
      <translation>Ce champ est déjà défini dans l'espace de travail</translation>
    </message>
  </context>
  <context>
    <name>DlgAlias</name>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgAlias.ui" line="14"/>
      <source>SELECT_AN_ALIAS_FOR_THE_FIELD</source>
      <translation>Selectionner un alias pour ce champ</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgAlias.ui" line="401"/>
      <source>DEFINE_AN_ALIAS</source>
      <translation>Vous pouvez définir un alias pour manipuler le champs dans la console:</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgAlias.ui" line="419"/>
      <source>ALIAS</source>
      <translation>Alias</translation>
    </message>
    <message utf8="true">
      <location filename="MEDOP/gui/dialogs/DlgAlias.ui" line="436"/>
      <source>MSG_OPERATION_DEFINES_VARIABLE</source>
      <translation>(cette opération définit une variable nommée &lt;alias&gt; dans la console texte. Tapez "&lt;alias&gt;.help()" pour voir les fonctions disponibles, ou simplement "doc")</translation>
    </message>
  </context>
  <context>
    <name>DlgChangeUnderlyingMesh</name>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgChangeUnderlyingMesh.ui" line="14"/>
      <source>FORM</source>
      <translation>Formulaire</translation>
    </message>
    <message utf8="true">
      <location filename="MEDOP/gui/dialogs/DlgChangeUnderlyingMesh.ui" line="403"/>
      <source>MESH_GT</source>
      <translation>Maillage -&gt;</translation>
    </message>
    <message utf8="true">
      <location filename="MEDOP/gui/dialogs/DlgChangeUnderlyingMesh.ui" line="420"/>
      <source>MSG_EXPLORER</source>
      <translation>(L'explorateur fournit une vue des données MED (maillage et champs) référencées dans l'espace des données)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgChangeUnderlyingMesh.cxx" line="35"/>
      <source>DATA_VERIFICATION</source>
      <translation>Vérification des données</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgChangeUnderlyingMesh.cxx" line="36"/>
      <location filename="MEDOP/gui/dialogs/DlgChangeUnderlyingMesh.ui" line="391"/>
      <source>SELECT_MESH</source>
      <translation>Vous devez sélectionner un maillage dans l'explorateur et cliquer sur le bouton Maillage</translation>
    </message>
  </context>
  <context>
    <name>DlgInterpolateField</name>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="391"/>
      <source>SELECT_MESH</source>
      <translation>Vous devez sélectionner un maillage dans l'explorateur et cliquer sur le bouton Maillage</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="406"/>
      <source>TARGET_MESH_GT</source>
      <translation>Maillage cible -&gt;</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="423"/>
      <source>MSG_EXPLORER</source>
      <translation>(L'explorateur fournit une vue des données MED (maillage et champs) référencées dans l'espace des données)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="450"/>
      <source>LABEL_PRECISION</source>
      <translation>Précision de l'interpolateur</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="493"/>
      <source>LABEL_INTERSECTION_TYPE</source>
      <translation>Type d'intersection</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="520"/>
      <source>LABEL_METHOD</source>
      <translation>Méthode d'interpolation</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="547"/>
      <source>LABEL_DEFAULT_VALUE</source>
      <translation>Valeur par défaut du champ résultant</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="581"/>
      <source>LABEL_REVERSE</source>
      <translation>Interpolation inverse ?</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgInterpolateField.ui" line="612"/>
      <source>LABEL_NATURE</source>
      <translation>Nature du champ</translation>
    </message>
  </context>
  <context>
    <name>DlgImageToMed</name>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.ui" line="14"/>
      <source>FORM</source>
      <translation>Formulaire</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.ui" line="28"/>
      <source>IMAGE_FILE</source>
      <translation>Fichier image :</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.ui" line="35"/>
      <source>MED_FILE</source>
      <translation>Fichier MED :</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.cxx" line="64"/>
      <source>SELECT_IMAGE_FILE</source>
      <translation>Selectionner un fichier image</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.cxx" line="79"/>
      <source>SPECIFY_MED_FILE</source>
      <translation>Spécifier un fichier MED</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.ui" line="82"/>
      <source>LOAD_AUTOMATICALLY</source>
      <translation>Charger automatiquement</translation>
    </message>
  </context>
  <context>
    <name>DlgUseInWorkspace</name>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgUseInWorkspace.ui" line="13"/>
      <source>FORM</source>
      <translation>Formulaire</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgUseInWorkspace.ui" line="49"/>
      <source>PRESSURE</source>
      <translation>Pression :</translation>
    </message>
    <message utf8="true">
      <location filename="MEDOP/gui/dialogs/DlgUseInWorkspace.ui" line="56"/>
      <source>TEMPERATURE</source>
      <translation>Température :</translation>
    </message>
  </context>
  <context>
    <name>GenericDialog</name>
    <message>
      <location filename="MEDOP/gui/dialogs/GenericDialog.ui" line="13"/>
      <source>DIALOG</source>
      <translation>Dialogue</translation>
    </message>
  </context>
  <context>
    <name>MEDOPModule</name>
    <message>
      <location filename="MEDOP/gui/MEDOPModule.cxx" line="68"/>
      <location filename="MEDOP/gui/MEDOPModule.cxx" line="157"/>
      <source>IMPORT_FROM_FILE</source>
      <translation>Importer depuis un fichier</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/MEDOPModule.cxx" line="69"/>
      <source>IMPORT_MED_FILE</source>
      <translation>Importer un fichier MED</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/MEDOPModule.cxx" line="72"/>
      <source>MEN_FILE</source>
      <translation>&amp;Fichier</translation>
    </message>
  </context>
  <context>
    <name>WorkspaceController</name>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="66"/>
      <source>VISUALIZE_SCALAR_MAP</source>
      <translation>Visualiser (carte scalaire)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="67"/>
      <source>USE_IN_CONSOLE</source>
      <translation>Utiliser (dans la console)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="68"/>
      <source>EXPORT_TO_PARAVIS</source>
      <translation>Exporter (vers PARAVIS)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="69"/>
      <source>SAVE_AS_MED</source>
      <translation>Sauvegarder (dans un fichier MED)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="70"/>
      <source>REMOVE_FROM_WORKSPACE</source>
      <translation>Supprimer (de l'espace de travail)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="91"/>
      <source>LAB_SAVE_WORKSPACE</source>
      <translation>Sauvegarder l'espace de travail</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="92"/>
      <source>TIP_SAVE_WORKSPACE</source>
      <translation>Sauvegarder l'espace de travail (champs et maillages) dans un fichier MED</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="97"/>
      <source>LAB_CLEAN_WORKSPACE</source>
      <translation>Nettoyer l'espace de travail</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="98"/>
      <source>TIP_CLEAN_WORKSPACE</source>
      <translation>Effacer toute les données de l'espace de travail</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="271"/>
      <source>SAVE_SELECTED_FIELDS</source>
      <translation>Sauvegarder les champs sélectionnés</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="425"/>
      <source>SAVE_WORKSPACE_DATA</source>
      <translation>Sauvegarder les données de l'espace de travail</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="439"/>
      <source>NOT_IMPLEMENTED_YET</source>
      <translation>Non implémenté</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="440"/>
      <source>FUNCTION_NOT_IMPLEMENTED</source>
      <translation>Cette function n'est pas encore implémentée</translation>
    </message>
  </context>
  <context>
    <name>@default</name>
    <message>
      <location filename="MEDOP/gui/MEDOPModule.cxx" line="151"/>
      <location filename="MEDOP/gui/DatasourceController.cxx" line="152"/>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.cxx" line="75"/>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="267"/>
      <location filename="MEDOP/gui/WorkspaceController.cxx" line="420"/>
      <source>FILE_FILTER_MED</source>
      <translation>Fichiers MED (*.med)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.cxx" line="57"/>
      <source>FILE_FILTER_PNG</source>
      <translation>Image PNG (*.png)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.cxx" line="58"/>
      <source>FILE_FILTER_JPG</source>
      <translation>Image JPG (*.jpg)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.cxx" line="59"/>
      <source>FILE_FILTER_PGM</source>
      <translation>Image PGM (*.jpg)</translation>
    </message>
    <message>
      <location filename="MEDOP/gui/dialogs/DlgImageToMed.cxx" line="60"/>
      <source>FILE_FILTER_ALL</source>
      <translation>Tous les fichiers (*.*)</translation>
    </message>
  </context>
</TS>
