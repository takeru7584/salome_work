<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>APP_OK</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>APP_ERROR</source>
      <translation>Erreur</translation>
    </message>
    <message>
      <source>APP_UNK_EXCEPTION</source>
      <translation>Exception inconnue</translation>
    </message>
  </context>
</TS>
