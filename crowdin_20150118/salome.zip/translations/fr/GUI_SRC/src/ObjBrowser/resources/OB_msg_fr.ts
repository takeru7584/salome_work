<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en">
  <context>
    <name>OB_Browser</name>
    <message>
      <source>MEN_EXPAND_ALL</source>
      <translation>Tout déplier</translation>
    </message>
    <message>
      <source>MEN_COLLAPSE_ALL</source>
      <translation>Tout réduire</translation>
    </message>
    <message>
      <source>MEN_FIND</source>
      <translation>Chercher</translation>
    </message>
  </context>
  <context>
    <name>OB_FindDlg</name>
    <message>
      <source>FIND</source>
      <translation>Chercher</translation>
    </message>
    <message>
      <source>CLOSE</source>
      <translation>Fermer</translation>
    </message>
    <message>
      <source>CASE_SENSITIVE</source>
      <translation>Sensible à la casse</translation>
    </message>
    <message>
      <source>IS_REG_EXP</source>
      <translation>Expression régulière</translation>
    </message>
  </context>
</TS>
