<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en">
  <context>
    <name>LogWindow</name>
    <message>
      <location filename="../LogWindow.cxx" line="293"/>
      <source>EDIT_COPY_CMD</source>
      <translation>&amp;Copier</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="298"/>
      <source>EDIT_CLEAR_CMD</source>
      <translation>&amp;Effacer</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="303"/>
      <source>EDIT_SELECTALL_CMD</source>
      <translation>&amp;Tout sélectionner</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="308"/>
      <source>EDIT_SAVETOFILE_CMD</source>
      <translation>&amp;Sauvegarder le journal dans un fichier...</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_ERROR</source>
      <translation>Erreur</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_CANT_SAVE_FILE</source>
      <translation>Impossible de sauvegarder le fichier</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>BUT_OK</source>
      <translation>&amp;OK</translation>
    </message>
  </context>
</TS>
