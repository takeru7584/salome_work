<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en">
  <context>
    <name>ViewerTools_CubeAxesDlgBase</name>
    <message>
      <source>X_AXIS</source>
      <translation>Axe X</translation>
    </message>
    <message>
      <source>Y_AXIS</source>
      <translation>Axe Y</translation>
    </message>
    <message>
      <source>Z_AXIS</source>
      <translation>Axe Z</translation>
    </message>
    <message>
      <source>CAPTION</source>
      <translation>Axes gradués</translation>
    </message>
    <message>
      <source>IS_VISIBLE</source>
      <translation>Visible</translation>
    </message>
    <message>
      <source>FONT</source>
      <translation>Couleur</translation>
    </message>
    <message>
      <source>NAME</source>
      <translation>Nom</translation>
    </message>
    <message>
      <source>TICK_MARKS</source>
      <translation>Marques de graduation</translation>
    </message>
    <message>
      <source>LABELS</source>
      <translation>Etiquettes</translation>
    </message>
    <message>
      <source>LENGTH</source>
      <translation>Longueur</translation>
    </message>
    <message>
      <source>NUMBER</source>
      <translation>Nombre</translation>
    </message>
    <message>
      <source>OFFSET</source>
      <translation>Décalage</translation>
    </message>
    <message>
      <source>AXIS_NAME</source>
      <translation>Nom de l'axe </translation>
    </message>
  </context>
  <context>
    <name>ViewerTools_FontWidgetBase</name>
    <message>
      <source>BOLD</source>
      <translation>Gras</translation>
    </message>
    <message>
      <source>ITALIC</source>
      <translation>Italique</translation>
    </message>
    <message>
      <source>SHADOW</source>
      <translation>Ombré</translation>
    </message>
  </context>
</TS>
