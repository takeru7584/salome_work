<?xml version="1.0"?>
<!DOCTYPE TS>
<TS language="ja" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>TOOL_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>TLT_MY_NEW_ITEM</source>
      <translation>&#x79C1;&#x30E1;&#x30CB;&#x30E5;&#x30FC;&#x9805;&#x76EE;</translation>
    </message>
    <message>
      <source>TLT_LOAD_DXF</source>
      <translation>DXF &#x30D5;&#x30A1;&#x30A4;&#x30EB;&#x306E;&#x8AAD;&#x307F;&#x8FBC;&#x307F;</translation>
    </message>
    <message>
      <source>MEN_LOAD_DXF</source>
      <translation>DXF &#x30D5;&#x30A1;&#x30A4;&#x30EB;&#x306E;&#x8AAD;&#x307F;&#x8FBC;&#x307F;</translation>
    </message>
    <message>
      <source>STS_LOAD_DXF</source>
      <translation>DXF &#x30D5;&#x30A1;&#x30A4;&#x30EB;&#x306E;&#x8AAD;&#x307F;&#x8FBC;&#x307F;</translation>
    </message>
    <message>
      <source>TLT_GET_BANNER</source>
      <translation>XMED &#x306E;&#x30D0;&#x30CA;&#x30FC;&#x3092;&#x53D6;&#x5F97;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>STS_MY_NEW_ITEM</source>
      <translation>&#x79C1;&#x306E;&#x30E1;&#x30CB;&#x30E5;&#x30FC;&#x3092;&#x547C;&#x3073;&#x51FA;&#x3059;</translation>
    </message>
    <message>
      <source>MEN_FILE_XMED</source>
      <translation>&#x3053;&#x3093;&#x306B;&#x3061;&#x306F;</translation>
    </message>
    <message>
      <source>MEN_GET_BANNER</source>
      <translation>&#x30D0;&#x30CA;&#x30FC;&#x3092;&#x53D6;&#x5F97;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>&#x30D5;&#x30A1;&#x30A4;&#x30EB;(&amp;F)</translation>
    </message>
    <message>
      <source>STS_GET_BANNER</source>
      <translation>XMED &#x306E;&#x30D0;&#x30CA;&#x30FC;&#x3092;&#x53D6;&#x5F97;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>TLT_BUILDER1</source>
      <translation>&#x57FA;&#x672C;&#x30D9;&#x30AF;&#x30C8;&#x30EB; Vx, Vy, Vz &#x3092;&#x4F5C;&#x6210;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>TLT_BUILDER2</source>
      <translation>&#x63A5;&#x7D9A;&#x30A8;&#x30C3;&#x30B8; (&#x5186;&#x5F27;&#x3068;&#x30E9;&#x30A4;&#x30F3;) &#x3092;&#x4F5C;&#x6210;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>TLT_BUILDER3</source>
      <translation>Python &#x30B9;&#x30AF;&#x30EA;&#x30D7;&#x30C8;&#x3092;&#x30ED;&#x30FC;&#x30C9;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>STS_BUILDER1</source>
      <translation>&#x57FA;&#x672C;&#x30D9;&#x30AF;&#x30C8;&#x30EB; Vx, Vy, Vz &#x3092;&#x4F5C;&#x6210;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>STS_BUILDER2</source>
      <translation>&#x63A5;&#x7D9A;&#x30A8;&#x30C3;&#x30B8; (&#x5186;&#x5F27;&#x3068;&#x30E9;&#x30A4;&#x30F3;) &#x3092;&#x4F5C;&#x6210;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>STS_BUILDER3</source>
      <translation>Python &#x30B9;&#x30AF;&#x30EA;&#x30D7;&#x30C8;&#x3092;&#x30ED;&#x30FC;&#x30C9;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>MEN_BUILDER1</source>
      <translation>&#x57FA;&#x672C;&#x30D9;&#x30AF;&#x30C8;&#x30EB; Vx, Vy, Vz &#x3092;&#x4F5C;&#x6210;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>MEN_BUILDER2</source>
      <translation>&#x63A5;&#x7D9A;&#x30A8;&#x30C3;&#x30B8; (&#x5186;&#x5F27;&#x3068;&#x30E9;&#x30A4;&#x30F3;) &#x3092;&#x4F5C;&#x6210;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>MEN_BUILDER3</source>
      <translation>Python &#x30B9;&#x30AF;&#x30EA;&#x30D7;&#x30C8;&#x3092;&#x30ED;&#x30FC;&#x30C9;&#x3057;&#x307E;&#x3059;&#x3002;</translation>
    </message>
    <message>
      <source>MEN_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>MEN_MY_NEW_ITEM</source>
      <translation>&#x79C1;&#x30E1;&#x30CB;&#x30E5;&#x30FC;&#x9805;&#x76EE;</translation>
    </message>
  </context>
  <context>
    <name>XMEDGUI_maquette</name>
    <message>
      <source>BUT_OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>QUE_XMED_LABEL</source>
      <translation>&#x540D;&#x524D;&#x306E;&#x30A4;&#x30F3;&#x30DD;&#x30FC;&#x30C8;</translation>
    </message>
    <message>
      <source>QUE_XMED_NAME</source>
      <translation>&#x3042;&#x306A;&#x305F;&#x306E;&#x540D;&#x524D;&#x3092;&#x5165;&#x529B;&#x3057;&#x3066;&#x304F;&#x3060;&#x3055;&#x3044;&#x3002;</translation>
    </message>
    <message>
      <source>INF_XMED_BANNER</source>
      <translation>XMED &#x60C5;&#x5831;</translation>
    </message>
    <message>
      <source>INF_XMED_MENU</source>
      <translation>&#x3053;&#x308C;&#x306F;&#x305F;&#x3060;&#x306E;&#x30C6;&#x30B9;&#x30C8;&#x3067;&#x3059;&#x3002;</translation>
    </message>
  </context>
</TS>
