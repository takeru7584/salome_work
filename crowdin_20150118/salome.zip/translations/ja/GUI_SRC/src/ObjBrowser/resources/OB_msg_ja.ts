<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ja" sourcelanguage="en">
  <context>
    <name>OB_Browser</name>
    <message>
      <source>MEN_EXPAND_ALL</source>
      <translation>すべて展開します。</translation>
    </message>
    <message>
      <source>MEN_COLLAPSE_ALL</source>
      <translation>すべてを削減します。</translation>
    </message>
    <message>
      <source>MEN_FIND</source>
      <translation>検索</translation>
    </message>
  </context>
  <context>
    <name>OB_FindDlg</name>
    <message>
      <source>FIND</source>
      <translation>検索</translation>
    </message>
    <message>
      <source>CLOSE</source>
      <translation>閉じる</translation>
    </message>
    <message>
      <source>CASE_SENSITIVE</source>
      <translation>大文字小文字を区別</translation>
    </message>
    <message>
      <source>IS_REG_EXP</source>
      <translation>正規表現</translation>
    </message>
  </context>
</TS>
