<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ja" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>ERROR_TLT</source>
      <translation>エラー</translation>
    </message>
    <message>
      <source>ERROR_ACTIVATE_MODULE_MSG</source>
      <translation>%1 のモジュールを有効にできません。</translation>
    </message>
    <message>
      <source>MODULE_ROOT_OBJECT_TOOLTIP</source>
      <translation>%1 module root object</translation>
    </message>
  </context>
</TS>
