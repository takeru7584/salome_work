<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ja" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_CHANGE_BACKGROUND</source>
      <translation>背景を変更</translation>
    </message>
    <message>
      <source>MNU_PAN_VIEW</source>
      <translation>パンニング</translation>
    </message>
    <message>
      <source>DSC_PAN_VIEW</source>
      <translation>ビューを移動します。</translation>
    </message>
    <message>
      <source>MNU_RESET_VIEW</source>
      <translation>復元</translation>
    </message>
    <message>
      <source>DSC_RESET_VIEW</source>
      <translation>ビューのポイントを復元します。</translation>
    </message>
  </context>
  <context>
    <name>QxScene_ViewWindow</name>
    <message>
      <source>LBL_TOOLBAR_LABEL</source>
      <translation>表示操作</translation>
    </message>
  </context>
  <context>
    <name>QxScene_ViewManager</name>
    <message>
      <source>QXSCENE_VIEW_TITLE</source>
      <translation>QGraphics scene:%M - viewer:%V</translation>
    </message>
  </context>
</TS>
