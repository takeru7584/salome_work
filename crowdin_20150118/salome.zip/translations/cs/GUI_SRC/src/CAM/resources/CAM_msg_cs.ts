<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>ERROR_TLT</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>ERROR_ACTIVATE_MODULE_MSG</source>
      <translation>ERROR_ACTIVATE_MODULE_MSG</translation>
    </message>
    <message>
      <source>MODULE_ROOT_OBJECT_TOOLTIP</source>
      <translation>MODULE_ROOT_OBJECT_TOOLTIP</translation>
    </message>
  </context>
</TS>
