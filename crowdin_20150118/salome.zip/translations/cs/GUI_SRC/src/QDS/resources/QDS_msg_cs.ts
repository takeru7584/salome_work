<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>QDS_Datum</name>
    <message>
      <source>DATA_ERR_TITLE</source>
      <translation>DATA_ERR_TITLE</translation>
    </message>
    <message>
      <source>DATA_STRING</source>
      <translation>DATA_STRING</translation>
    </message>
    <message>
      <source>DATA_NON_EMPTY</source>
      <translation>DATA_NON_EMPTY</translation>
    </message>
    <message>
      <source>DATA_MIN_LIMIT</source>
      <translation>je větší než %1</translation>
    </message>
    <message>
      <source>DATA_FLOAT</source>
      <translation>reálné číslo</translation>
    </message>
    <message>
      <source>DATA_RANGE</source>
      <translation>v intervalu [%1, %2]</translation>
    </message>
    <message>
      <source>DATA_SHOULD_BE_VALUE</source>
      <translation>Měl by mít hodnotu %1</translation>
    </message>
    <message>
      <source>DATA_INTEGER</source>
      <translation>celé číslo</translation>
    </message>
    <message>
      <source>DATA_INCORRECT_VALUE</source>
      <translation>DATA_INCORRECT_VALUE</translation>
    </message>
    <message>
      <source>DATA_MAX_LIMIT</source>
      <translation>je menší než %1</translation>
    </message>
    <message>
      <source>DATA_INPUT_VALUE</source>
      <translation>Prosím, vložte správnou hodnotu.</translation>
    </message>
  </context>
</TS>
