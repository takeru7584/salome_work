<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_EXPORTVTK</source>
      <translation>VTK</translation>
    </message>
    <message>
      <source>TOP_EXPORTVTK</source>
      <translation>Exportovat VTK soubor</translation>
    </message>
    <message>
      <source>STB_EXPORTVTK</source>
      <translation>Exportovat VTK soubor</translation>
    </message>
    <message>
      <source>MEN_IMPORTVTK</source>
      <translation>VTK</translation>
    </message>
    <message>
      <source>TOP_IMPORTVTK</source>
      <translation>Importovat VTK soubor</translation>
    </message>
    <message>
      <source>STB_IMPORTVTK</source>
      <translation>Importovat VTK soubor</translation>
    </message>
  </context>
  <context>
    <name>VTKPlugin_GUI</name>
    <message>
      <source>VTK_FILES</source>
      <translation>Soubory VTK (*.vtk)</translation>
    </message>
    <message>
      <source>EXPORT_TITLE</source>
      <translation>Exportování VTK soubor</translation>
    </message>
  </context>
  <context>
    <name>VTKPlugin_ExportDlg</name>
    <message>
      <source>DEFLECTION</source>
      <translation>Odchylka</translation>
    </message>
  </context>
</TS>
