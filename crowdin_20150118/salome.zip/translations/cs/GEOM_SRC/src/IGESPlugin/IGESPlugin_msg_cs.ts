<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_EXPORTIGES</source>
      <translation>IGES</translation>
    </message>
    <message>
      <source>TOP_EXPORTIGES</source>
      <translation>Exportovat IGES soubor</translation>
    </message>
    <message>
      <source>STB_EXPORTIGES</source>
      <translation>Exportovat IGES soubor</translation>
    </message>
    <message>
      <source>MEN_IMPORTIGES</source>
      <translation>IGES</translation>
    </message>
    <message>
      <source>TOP_IMPORTIGES</source>
      <translation>Importovat IGES soubor</translation>
    </message>
    <message>
      <source>STB_IMPORTIGES</source>
      <translation>Importovat IGES soubor</translation>
    </message>
  </context>
  <context>
    <name>IGESPlugin_GUI</name>
    <message>
      <source>IGES_FILES</source>
      <translation>Soubory IGES (*.iges *.igs)</translation>
    </message>
    <message>
      <source>EXPORT_TITLE</source>
      <translation>Exportování IGES souboru</translation>
    </message>
    <message>
      <source>IMPORT_TITLE</source>
      <translation>Importování IGES souboru</translation>
    </message>
    <message>
      <source>SCALE_DIMENSIONS</source>
      <translation>SCALE_DIMENSIONS</translation>
    </message>
  </context>
  <context>
    <name>IGESPlugin_ExportDlg</name>
    <message>
      <source>IGES_VERSION</source>
      <translation>Verze</translation>
    </message>
  </context>
</TS>
