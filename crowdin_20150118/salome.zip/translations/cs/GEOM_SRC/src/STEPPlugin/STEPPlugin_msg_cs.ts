<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_EXPORTSTEP</source>
      <translation>STEP</translation>
    </message>
    <message>
      <source>TOP_EXPORTSTEP</source>
      <translation>Exportovat STEP soubor</translation>
    </message>
    <message>
      <source>STB_EXPORTSTEP</source>
      <translation>Exportovat STEP soubor</translation>
    </message>
    <message>
      <source>MEN_IMPORTSTEP</source>
      <translation>STEP</translation>
    </message>
    <message>
      <source>TOP_IMPORTSTEP</source>
      <translation>Importovat STEP soubor</translation>
    </message>
    <message>
      <source>STB_IMPORTSTEP</source>
      <translation>Importovat STEP soubor</translation>
    </message>
  </context>
  <context>
    <name>STEPPlugin_GUI</name>
    <message>
      <source>STEP_FILES</source>
      <translation>Soubory STEP (*.step *.stp)</translation>
    </message>
    <message>
      <source>EXPORT_TITLE</source>
      <translation>Exportování STEP souboru</translation>
    </message>
    <message>
      <source>IMPORT_TITLE</source>
      <translation>Importování STEP souboru</translation>
    </message>
    <message>
      <source>SCALE_DIMENSIONS</source>
      <translation>SCALE_DIMENSIONS</translation>
    </message>
  </context>
</TS>
