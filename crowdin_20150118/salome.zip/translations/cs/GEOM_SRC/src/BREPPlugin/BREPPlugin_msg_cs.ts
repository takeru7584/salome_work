<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>MEN_EXPORTBREP</source>
      <translation>BREP</translation>
    </message>
    <message>
      <source>TOP_EXPORTBREP</source>
      <translation>Exportovat BREP soubor</translation>
    </message>
    <message>
      <source>STB_EXPORTBREP</source>
      <translation>Exportovat BREP soubor</translation>
    </message>
    <message>
      <source>MEN_IMPORTBREP</source>
      <translation>BREP</translation>
    </message>
    <message>
      <source>TOP_IMPORTBREP</source>
      <translation>Importovat BREP soubor</translation>
    </message>
    <message>
      <source>STB_IMPORTBREP</source>
      <translation>Importovat BREP soubor</translation>
    </message>
  </context>
  <context>
    <name>BREPPlugin_GUI</name>
    <message>
      <source>BREP_FILES</source>
      <translation>Soubory BREP (*.brep)</translation>
    </message>
    <message>
      <source>EXPORT_TITLE</source>
      <translation>Exportováni BREP souboru</translation>
    </message>
    <message>
      <source>IMPORT_TITLE</source>
      <translation>Exportování BREP souboru</translation>
    </message>
  </context>
</TS>
