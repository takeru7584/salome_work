<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>DependencyTree_View</name>
    <message>
      <source>DEPENDENCY_TREE</source>
      <translation>DEPENDENCY_TREE</translation>
    </message>
    <message>
      <source>MOVE_NODES</source>
      <translation>MOVE_NODES</translation>
    </message>
    <message>
      <source>HIERARCHY_DEPTH</source>
      <translation>HIERARCHY_DEPTH</translation>
    </message>
    <message>
      <source>DISPLAY_ASCENDANTS</source>
      <translation>DISPLAY_ASCENDANTS</translation>
    </message>
    <message>
      <source>DISPLAY_DESCENDANTS</source>
      <translation>DISPLAY_DESCENDANTS</translation>
    </message>
    <message>
      <source>SHOW_ALL</source>
      <translation>Ukázat všechno</translation>
    </message>
    <message>
      <source>UPDATE</source>
      <translation>Aktualizovat</translation>
    </message>
    <name>DependencyTree_ViewModel</name>
    <message>
      <source>MEN_REBUILD_THE_TREE</source>
      <translation>Předělat strom</translation>
    </message>
    <message>
      <source>MEN_REDUCE_STUDY</source>
      <translation>Zmenšit studii</translation>
    </message>
  </context>
</TS>
