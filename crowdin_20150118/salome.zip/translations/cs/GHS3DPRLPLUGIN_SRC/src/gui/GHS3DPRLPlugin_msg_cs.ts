<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>GHS3DPRL_3D_HYPOTHESIS</source>
      <translation>GHS3DPRL_3D_HYPOTHESIS</translation>
    </message>
    <message>
      <source>GHS3DPRL_3D_TITLE</source>
      <translation>Vytvoření hypotézy</translation>
    </message>
    <message>
      <source>GHS3DPRL_KeepFiles</source>
      <translation>Nechat prostřední soubory</translation>
    </message>
    <message>
      <source>GHS3DPRL_Background</source>
      <translation>GHS3DPRL_Background</translation>
    </message>
    <message>
      <source>GHS3DPRL_ToMeshHoles</source>
      <translation>Síťovat díry sítě</translation>
    </message>
    <message>
      <source>GHS3DPRL_ToMergeSubdomains</source>
      <translation>GHS3DPRL_ToMergeSubdomains</translation>
    </message>
    <message>
      <source>GHS3DPRL_ToTagSubdomains</source>
      <translation>GHS3DPRL_ToTagSubdomains</translation>
    </message>
    <message>
      <source>GHS3DPRL_ToOutputInterfaces</source>
      <translation>GHS3DPRL_ToOutputInterfaces</translation>
    </message>
    <message>
      <source>GHS3DPRL_ToDiscardSubdomains</source>
      <translation>GHS3DPRL_ToDiscardSubdomains</translation>
    </message>
    <message>
      <source>GHS3DPRL_MEDName</source>
      <translation>MED jméno</translation>
    </message>
    <message>
      <source>GHS3DPRL_NbPart</source>
      <translation>Počet oddílů</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_KeepFiles</source>
      <translation>GHS3DPRL_WhatsThis_KeepFiles</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_Background</source>
      <translation>GHS3DPRL_WhatsThis_Background</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_ToMeshHoles</source>
      <translation>GHS3DPRL_WhatsThis_ToMeshHoles</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_MEDName</source>
      <translation>GHS3DPRL_WhatsThis_MEDName</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_Name</source>
      <translation>Jméno aplikované hypotézy</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_NbPart</source>
      <translation>GHS3DPRL_WhatsThis_NbPart</translation>
    </message>
  </context>
</TS>
