<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="1.1" language="cs" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>ALGO_ERROR</source>
      <translation>ALGO_ERROR</translation>
    </message>
    <message>
      <source>EXPORT_ERROR</source>
      <translation>EXPORT_ERROR</translation>
    </message>
    <message>
      <source>IMPORT_ERROR</source>
      <translation>IMPORT_ERROR</translation>
    </message>
  </context>
  <context>
    <name>ATOMGENGUI</name>
    <message>
      <source>EXPORT_XML</source>
      <translation>Exportování XML souboru</translation>
    </message>
    <message>
      <source>IMPORT_XML</source>
      <translation>Importovat XML soubor</translation>
    </message>
    <message>
      <source>MEN_EXPORT_XML</source>
      <translation>Exportovat...</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>Soubor</translation>
    </message>
    <message>
      <source>MEN_IMPORT_XML</source>
      <translation>Importovat...</translation>
    </message>
    <message>
      <source>STB_EXPORT_XML</source>
      <translation>STB_EXPORT_XML</translation>
    </message>
    <message>
      <source>STB_IMPORT_XML</source>
      <translation>STB_IMPORT_XML</translation>
    </message>
    <message>
      <source>TOP_EXPORT_XML</source>
      <translation>Exportovat XML soubor</translation>
    </message>
    <message>
      <source>TOP_IMPORT_XML</source>
      <translation>Importovat XML soubor</translation>
    </message>
    <message>
      <source>WARNING</source>
      <translation>Upozornění</translation>
    </message>
    <message>
      <source>XML_FILES</source>
      <translation>Soubory XML (*.xml)</translation>
    </message>
  </context>
</TS>
