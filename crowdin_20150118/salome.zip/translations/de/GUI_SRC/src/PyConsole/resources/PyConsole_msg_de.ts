<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de" sourcelanguage="en">
  <context>
    <name>PyConsole_Console</name>
    <message>
      <location filename="../PyConsole_Console.cxx" line="216"/>
      <source>EDIT_COPY_CMD</source>
      <translation>&amp; Kopieren</translation>
    </message>
    <message>
      <location filename="../PyConsole_Console.cxx" line="221"/>
      <source>EDIT_PASTE_CMD</source>
      <translation>&amp; Einfügen</translation>
    </message>
    <message>
      <location filename="../PyConsole_Console.cxx" line="226"/>
      <source>EDIT_CLEAR_CMD</source>
      <translation>Clea &amp; r</translation>
    </message>
    <message>
      <location filename="../PyConsole_Console.cxx" line="231"/>
      <source>EDIT_SELECTALL_CMD</source>
      <translation>Wählen Sie &amp; All</translation>
    </message>
    <message>
      <source>EDIT_DUMPCOMMANDS_CMD</source>
      <translation>D &amp; Ump-Befehle</translation>
    </message>
    <message>
      <source>EDIT_STARTLOG_CMD</source>
      <translation>EDIT_STARTLOG_CMD</translation>
    </message>
    <message>
      <source>EDIT_STOPLOG_CMD</source>
      <translation>EDIT_STOPLOG_CMD</translation>
    </message>
  </context>
  <context>
    <name>PyConsole_Editor</name>
    <message>
      <source>TOT_DUMP_PYCOMMANDS</source>
      <translation>Dump Befehle</translation>
    </message>
    <message>
      <source>TOT_SAVE_PYLOG</source>
      <translation>TOT_SAVE_PYLOG</translation>
    </message>
    <message>
      <source>PYTHON_FILES_FILTER</source>
      <translation>PYTHON-Dateien (*.py)</translation>
    </message>
    <message>
      <source>LOG_FILES_FILTER</source>
      <translation>LOG_FILES_FILTER</translation>
    </message>
    <message>
      <source>ERR_FILE_NOT_WRITABLE</source>
      <translation>ERR_FILE_NOT_WRITABLE</translation>
    </message>
  </context>
</TS>
