<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de" sourcelanguage="en">
  <context>
    <name>OB_Browser</name>
    <message>
      <source>MEN_EXPAND_ALL</source>
      <translation>Erweitern Sie alle</translation>
    </message>
    <message>
      <source>MEN_COLLAPSE_ALL</source>
      <translation>Alle ausblenden</translation>
    </message>
    <message>
      <source>MEN_FIND</source>
      <translation>Finden</translation>
    </message>
  </context>
  <context>
    <name>OB_FindDlg</name>
    <message>
      <source>FIND</source>
      <translation>Finden</translation>
    </message>
    <message>
      <source>CLOSE</source>
      <translation>Schließen</translation>
    </message>
    <message>
      <source>CASE_SENSITIVE</source>
      <translation>Groß-/Kleinschreibung</translation>
    </message>
    <message>
      <source>IS_REG_EXP</source>
      <translation>Regulärer Ausdruck</translation>
    </message>
  </context>
</TS>
