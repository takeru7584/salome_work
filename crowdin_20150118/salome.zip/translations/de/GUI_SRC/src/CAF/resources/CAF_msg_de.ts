<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de" sourcelanguage="en">
  <context>
    <name>CAF_Application</name>
    <message>
      <source>MEN_APP_EDIT</source>
      <translation>&amp; Bearbeiten</translation>
    </message>
    <message>
      <source>INF_ALL_FILTER</source>
      <translation>Alle Dateien (*. *)</translation>
    </message>
    <message>
      <source>INF_ALL_DOCUMENTS_FILTER</source>
      <translation>Alle lesbaren Dokumente</translation>
    </message>
    <message>
      <source>MEN_DESK_EDIT</source>
      <translation>&amp; Bearbeiten</translation>
    </message>
    <message>
      <source>MEN_APP_EDIT_UNDO</source>
      <translation>&amp; Rückgängig machen</translation>
    </message>
    <message>
      <source>MEN_APP_EDIT_REDO</source>
      <translation>&amp; Wiederholen</translation>
    </message>
    <message>
      <source>PRP_APP_EDIT_REDO</source>
      <translation>Wiederholt den letzten Vorgang</translation>
    </message>
    <message>
      <source>PRP_APP_EDIT_UNDO</source>
      <translation>Macht die letzte Aktion rückgängig</translation>
    </message>
    <message>
      <source>TOT_APP_EDIT_REDO</source>
      <translation>Wiederholen</translation>
    </message>
    <message>
      <source>TOT_APP_EDIT_UNDO</source>
      <translation>Rückgängig machen</translation>
    </message>
    <message>
      <source>INF_APP_REDOACTIONS</source>
      <translation> Wiederholt%1 Aktionen </translation>
    </message>
    <message>
      <source>INF_APP_UNDOACTIONS</source>
      <translation> Macht%1 Aktion(en) rückgängig </translation>
    </message>
    <message>
      <source>ABOUT_INFO</source>
      <translation>Anzug-Caf-Anwendung</translation>
    </message>
  </context>
</TS>
