<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>APP_OK</source>
      <translation>Okay</translation>
    </message>
    <message>
      <source>APP_ERROR</source>
      <translation>Fehler</translation>
    </message>
    <message>
      <source>APP_UNK_EXCEPTION</source>
      <translation>Unbekannte Ausnahme</translation>
    </message>
  </context>
</TS>
