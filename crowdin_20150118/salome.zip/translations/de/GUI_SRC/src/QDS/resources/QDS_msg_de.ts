<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de" sourcelanguage="en">
  <context>
    <name>QDS_Datum</name>
    <message>
      <source>DATA_ERR_TITLE</source>
      <translation>Falscher Parameter-Wert</translation>
    </message>
    <message>
      <source>DATA_STRING</source>
      <translation> nicht leere Zeichenfolge</translation>
    </message>
    <message>
      <source>DATA_NON_EMPTY</source>
      <translation> gefüllte</translation>
    </message>
    <message>
      <source>DATA_MIN_LIMIT</source>
      <translation> größer als%1</translation>
    </message>
    <message>
      <source>DATA_FLOAT</source>
      <translation> Real</translation>
    </message>
    <message>
      <source>DATA_RANGE</source>
      <translation> im Bereich [%1,%2]</translation>
    </message>
    <message>
      <source>DATA_SHOULD_BE_VALUE</source>
      <translation>%1 Wert sollte sein</translation>
    </message>
    <message>
      <source>DATA_INTEGER</source>
      <translation> ganze Zahl</translation>
    </message>
    <message>
      <source>DATA_INCORRECT_VALUE</source>
      <translation>Wert des Parameters "%1" ist nicht korrekt.</translation>
    </message>
    <message>
      <source>DATA_MAX_LIMIT</source>
      <translation> weniger als%1</translation>
    </message>
    <message>
      <source>DATA_INPUT_VALUE</source>
      <translation>Bitte, geben Sie richtigen Wert.</translation>
    </message>
  </context>
</TS>
