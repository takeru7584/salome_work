<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source/>
      <translation type="unfinished"/>
    </message>
  </context>
</TS>
