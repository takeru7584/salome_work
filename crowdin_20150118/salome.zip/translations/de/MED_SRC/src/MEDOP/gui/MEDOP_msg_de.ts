<?xml version="1.0"?>
<!DOCTYPE TS>
<TS language="de" sourcelanguage="en">
  <context>
    <name>@default</name>
    <message>
      <source>TOOL_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>TLT_MY_NEW_ITEM</source>
      <translation>Meine Men&#xFC;punkt</translation>
    </message>
    <message>
      <source>TLT_LOAD_DXF</source>
      <translation>DXF-Datei laden</translation>
    </message>
    <message>
      <source>MEN_LOAD_DXF</source>
      <translation>DXF-Datei laden</translation>
    </message>
    <message>
      <source>STS_LOAD_DXF</source>
      <translation>DXF-Datei laden</translation>
    </message>
    <message>
      <source>TLT_GET_BANNER</source>
      <translation>XMED Banner zu erhalten</translation>
    </message>
    <message>
      <source>STS_MY_NEW_ITEM</source>
      <translation>Meine Men&#xFC;punkt aufrufen</translation>
    </message>
    <message>
      <source>MEN_FILE_XMED</source>
      <translation>Xmed</translation>
    </message>
    <message>
      <source>MEN_GET_BANNER</source>
      <translation>Erhalten banner</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>&amp; Datei</translation>
    </message>
    <message>
      <source>STS_GET_BANNER</source>
      <translation>XMED Banner zu erhalten</translation>
    </message>
    <message>
      <source>TLT_BUILDER1</source>
      <translation>Erstellen von base-Vektoren Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>TLT_BUILDER2</source>
      <translation>Erstellen von verbundene Kanten (B&#xF6;gen und Linien)</translation>
    </message>
    <message>
      <source>TLT_BUILDER3</source>
      <translation>Ein Python-Skript zu laden</translation>
    </message>
    <message>
      <source>STS_BUILDER1</source>
      <translation>Erstellen von base-Vektoren Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>STS_BUILDER2</source>
      <translation>Erstellen von verbundene Kanten (B&#xF6;gen und Linien)</translation>
    </message>
    <message>
      <source>STS_BUILDER3</source>
      <translation>Ein Python-Skript zu laden</translation>
    </message>
    <message>
      <source>MEN_BUILDER1</source>
      <translation>Erstellen von base-Vektoren Vx, Vy, Vz</translation>
    </message>
    <message>
      <source>MEN_BUILDER2</source>
      <translation>Erstellen von verbundene Kanten (B&#xF6;gen und Linien)</translation>
    </message>
    <message>
      <source>MEN_BUILDER3</source>
      <translation>Ein Python-Skript zu laden</translation>
    </message>
    <message>
      <source>MEN_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>MEN_MY_NEW_ITEM</source>
      <translation>Meine Men&#xFC;punkt</translation>
    </message>
  </context>
  <context>
    <name>XMEDGUI_maquette</name>
    <message>
      <source>BUT_OK</source>
      <translation>Okay</translation>
    </message>
    <message>
      <source>QUE_XMED_LABEL</source>
      <translation>Name Import</translation>
    </message>
    <message>
      <source>QUE_XMED_NAME</source>
      <translation>Bitte geben Sie Ihren Namen</translation>
    </message>
    <message>
      <source>INF_XMED_BANNER</source>
      <translation>XMED Informationen</translation>
    </message>
    <message>
      <source>INF_XMED_MENU</source>
      <translation>Dies ist nur ein test</translation>
    </message>
  </context>
</TS>
